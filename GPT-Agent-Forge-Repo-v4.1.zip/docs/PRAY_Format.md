# PRAY Format (short)
Each block: type(4), name(128, NUL-term), comp_len(u32), decomp_len(u32), flags(u32), payload.
This writer emits DSAG + FILE blocks (no compression). DSAG payload: int tags then string tags.
