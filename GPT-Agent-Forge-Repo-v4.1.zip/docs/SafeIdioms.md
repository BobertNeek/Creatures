# Safe CAOS Idioms (DS/CE)
- Use `<>` for inequality; avoid `ne`.
- Use `mulv vaXX -1` instead of `neg`.
- Put `part 0` before `anim/anms/pose` calls.
- Prefer Act2 (event 2) for DPAS; avoid event 0 during injection.
