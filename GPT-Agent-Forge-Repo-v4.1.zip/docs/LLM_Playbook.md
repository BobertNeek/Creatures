# LLM Playbook (C3/DS agents)
1) Use uppercase gallery names and filenames (e.g., BALLOON, BALLOON.C16).
2) Normalize CAOS: use `<> null`, avoid `neg` (use `mulv X -1`), avoid `dpas` in event 0, do `part 0` before `anim/anms/pose`.
3) Build with `bin/build_agent.py` to auto-mint DSAG + pack `.agents`.
4) To swap art, run `bin/png_to_c16.py input.png assets/sprites/BALLOON.C16` then rebuild.
