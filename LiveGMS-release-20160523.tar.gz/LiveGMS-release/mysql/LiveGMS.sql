-- phpMyAdmin SQL Dump
-- version 2.6.2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Aug 21, 2005 at 03:05 PM
-- Server version: 4.0.24
-- PHP Version: 4.3.10-15
-- 
-- Database: `LiveGMS`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `SVRules`
-- 

CREATE TABLE `SVRules` (
  `Number` tinyint(3) unsigned NOT NULL default '0',
  `Type` text NOT NULL,
  `Name` text NOT NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `SVRules`
-- 

INSERT INTO `SVRules` VALUES (0, 'Opcodes', 'stop');
INSERT INTO `SVRules` VALUES (1, 'Opcodes', 'blank');
INSERT INTO `SVRules` VALUES (2, 'Opcodes', 'store in');
INSERT INTO `SVRules` VALUES (3, 'Opcodes', 'load from');
INSERT INTO `SVRules` VALUES (4, 'Opcodes', 'if =');
INSERT INTO `SVRules` VALUES (5, 'Opcodes', 'if <>');
INSERT INTO `SVRules` VALUES (6, 'Opcodes', 'if >');
INSERT INTO `SVRules` VALUES (7, 'Opcodes', 'if <');
INSERT INTO `SVRules` VALUES (8, 'Opcodes', 'if >=');
INSERT INTO `SVRules` VALUES (9, 'Opcodes', 'if <=');
INSERT INTO `SVRules` VALUES (10, 'Opcodes', 'if zero');
INSERT INTO `SVRules` VALUES (11, 'Opcodes', 'if non-zero');
INSERT INTO `SVRules` VALUES (12, 'Opcodes', 'if positive');
INSERT INTO `SVRules` VALUES (13, 'Opcodes', 'if negative');
INSERT INTO `SVRules` VALUES (14, 'Opcodes', 'if non-negative');
INSERT INTO `SVRules` VALUES (15, 'Opcodes', 'if non-positive');
INSERT INTO `SVRules` VALUES (16, 'Opcodes', 'add');
INSERT INTO `SVRules` VALUES (17, 'Opcodes', 'substract');
INSERT INTO `SVRules` VALUES (18, 'Opcodes', 'substract from');
INSERT INTO `SVRules` VALUES (19, 'Opcodes', 'multiply by');
INSERT INTO `SVRules` VALUES (20, 'Opcodes', 'divide by');
INSERT INTO `SVRules` VALUES (21, 'Opcodes', 'divide into');
INSERT INTO `SVRules` VALUES (22, 'Opcodes', 'minimum with');
INSERT INTO `SVRules` VALUES (23, 'Opcodes', 'maximum with');
INSERT INTO `SVRules` VALUES (24, 'Opcodes', 'set tend rate');
INSERT INTO `SVRules` VALUES (25, 'Opcodes', 'tend to');
INSERT INTO `SVRules` VALUES (26, 'Opcodes', 'load negation of');
INSERT INTO `SVRules` VALUES (27, 'Opcodes', 'load abs of');
INSERT INTO `SVRules` VALUES (28, 'Opcodes', 'get distance to');
INSERT INTO `SVRules` VALUES (29, 'Opcodes', 'flip around');
INSERT INTO `SVRules` VALUES (30, 'Opcodes', 'no operation');
INSERT INTO `SVRules` VALUES (31, 'Opcodes', 'register as spare');
INSERT INTO `SVRules` VALUES (32, 'Opcodes', 'bound in [0,1]');
INSERT INTO `SVRules` VALUES (33, 'Opcodes', 'bound in [-1,1]');
INSERT INTO `SVRules` VALUES (34, 'Opcodes', 'add and store in');
INSERT INTO `SVRules` VALUES (35, 'Opcodes', 'tend to, store in');
INSERT INTO `SVRules` VALUES (0, 'Operands', 'accumulator');
INSERT INTO `SVRules` VALUES (1, 'Operands', 'input neuron');
INSERT INTO `SVRules` VALUES (2, 'Operands', 'dendrite');
INSERT INTO `SVRules` VALUES (3, 'Operands', 'neuron');
INSERT INTO `SVRules` VALUES (4, 'Operands', 'spare neuron');
INSERT INTO `SVRules` VALUES (5, 'Operands', 'random');
INSERT INTO `SVRules` VALUES (6, 'Operands', 'source chemical');
INSERT INTO `SVRules` VALUES (7, 'Operands', 'chemical');
INSERT INTO `SVRules` VALUES (8, 'Operands', 'destination chemical');
INSERT INTO `SVRules` VALUES (9, 'Operands', 'zero');
INSERT INTO `SVRules` VALUES (10, 'Operands', 'one');
INSERT INTO `SVRules` VALUES (11, 'Operands', 'value');
INSERT INTO `SVRules` VALUES (12, 'Operands', 'negative value');
INSERT INTO `SVRules` VALUES (13, 'Operands', 'value x 10');
INSERT INTO `SVRules` VALUES (14, 'Operands', 'value / 10');
INSERT INTO `SVRules` VALUES (15, 'Operands', 'value integer');

-- --------------------------------------------------------

-- 
-- Table structure for table `Stimuli`
-- 

CREATE TABLE `Stimuli` (
  `Number` tinyint(3) unsigned NOT NULL auto_increment,
  `Name` text NOT NULL,
  KEY `Number` (`Number`)
) TYPE=MyISAM AUTO_INCREMENT=100 ;

-- 
-- Dumping data for table `Stimuli`
-- 

INSERT INTO `Stimuli` VALUES (1, 'Disappointment');
INSERT INTO `Stimuli` VALUES (2, 'Pointer pats me');
INSERT INTO `Stimuli` VALUES (3, 'Creatures pats me');
INSERT INTO `Stimuli` VALUES (4, 'Pointer slaps me');
INSERT INTO `Stimuli` VALUES (5, 'Creature slaps me');
INSERT INTO `Stimuli` VALUES (6, '(It approaches DEPRECATED)');
INSERT INTO `Stimuli` VALUES (7, '(It retreats DEPRECATED)');
INSERT INTO `Stimuli` VALUES (8, 'I faump into wall');
INSERT INTO `Stimuli` VALUES (9, '(New object DEPRECATED)');
INSERT INTO `Stimuli` VALUES (10, 'Unrecognised word');
INSERT INTO `Stimuli` VALUES (11, 'Heard user speak');
INSERT INTO `Stimuli` VALUES (12, 'Heard creatures speak');
INSERT INTO `Stimuli` VALUES (13, 'I am quiescent (periodic)');
INSERT INTO `Stimuli` VALUES (14, 'I have activated1');
INSERT INTO `Stimuli` VALUES (15, 'I have activated2');
INSERT INTO `Stimuli` VALUES (16, 'I have deactivated');
INSERT INTO `Stimuli` VALUES (17, 'I am approaching (periodic)');
INSERT INTO `Stimuli` VALUES (18, 'I have retreated');
INSERT INTO `Stimuli` VALUES (19, 'I have got');
INSERT INTO `Stimuli` VALUES (20, 'I have dropped');
INSERT INTO `Stimuli` VALUES (21, 'I have stated need');
INSERT INTO `Stimuli` VALUES (22, 'I am resting (periodic)');
INSERT INTO `Stimuli` VALUES (23, 'I am sleeping (periodic)');
INSERT INTO `Stimuli` VALUES (24, 'I am travelling (periodic)');
INSERT INTO `Stimuli` VALUES (25, 'I have been pushed');
INSERT INTO `Stimuli` VALUES (26, 'I have been hit');
INSERT INTO `Stimuli` VALUES (27, 'I have eaten something');
INSERT INTO `Stimuli` VALUES (28, '(spare)');
INSERT INTO `Stimuli` VALUES (29, 'Involuntary action 0');
INSERT INTO `Stimuli` VALUES (30, 'Involuntary action 1');
INSERT INTO `Stimuli` VALUES (31, 'Involuntary action 2');
INSERT INTO `Stimuli` VALUES (32, 'Involuntary action 3');
INSERT INTO `Stimuli` VALUES (33, 'Involuntary action 4');
INSERT INTO `Stimuli` VALUES (34, 'Involuntary action 5');
INSERT INTO `Stimuli` VALUES (35, 'Involuntary action 6');
INSERT INTO `Stimuli` VALUES (36, 'Involuntary action 7');
INSERT INTO `Stimuli` VALUES (37, '(Approaching edge DEPRECATED)');
INSERT INTO `Stimuli` VALUES (38, '(Retreating from edge DEPRECATED)');
INSERT INTO `Stimuli` VALUES (39, '(Falling through air DEPRECATED)');
INSERT INTO `Stimuli` VALUES (40, 'Impact post fall');
INSERT INTO `Stimuli` VALUES (41, 'Pointer has spoken Yes');
INSERT INTO `Stimuli` VALUES (42, 'Creatures has spoken Yes');
INSERT INTO `Stimuli` VALUES (43, 'Pointer has spoken No');
INSERT INTO `Stimuli` VALUES (44, 'Creature has spoken No');
INSERT INTO `Stimuli` VALUES (45, 'I have performed a hit');
INSERT INTO `Stimuli` VALUES (46, 'I have mated');
INSERT INTO `Stimuli` VALUES (47, 'I have been tickled by the opposite sex');
INSERT INTO `Stimuli` VALUES (48, 'I have been tickled by the same sex');
INSERT INTO `Stimuli` VALUES (49, 'Need to stay');
INSERT INTO `Stimuli` VALUES (50, 'Need to enter');
INSERT INTO `Stimuli` VALUES (51, 'Need to exit');
INSERT INTO `Stimuli` VALUES (52, 'Need to go up');
INSERT INTO `Stimuli` VALUES (53, 'Need to go down');
INSERT INTO `Stimuli` VALUES (54, 'Need to go left');
INSERT INTO `Stimuli` VALUES (55, 'Need to go right');
INSERT INTO `Stimuli` VALUES (56, 'Reached smell 0');
INSERT INTO `Stimuli` VALUES (57, 'Reached smell 1');
INSERT INTO `Stimuli` VALUES (58, 'Reached smell 2');
INSERT INTO `Stimuli` VALUES (59, 'Reached smell 3');
INSERT INTO `Stimuli` VALUES (60, 'Reached smell 4');
INSERT INTO `Stimuli` VALUES (61, 'Reached smell 5');
INSERT INTO `Stimuli` VALUES (62, 'Reached smell 6');
INSERT INTO `Stimuli` VALUES (63, 'Reached smell 7');
INSERT INTO `Stimuli` VALUES (64, 'Reached smell 8');
INSERT INTO `Stimuli` VALUES (65, 'Reached smell 9');
INSERT INTO `Stimuli` VALUES (66, 'Reached smell 10');
INSERT INTO `Stimuli` VALUES (67, 'Reached smell 11');
INSERT INTO `Stimuli` VALUES (68, 'Reached smell 12');
INSERT INTO `Stimuli` VALUES (69, 'Reached smell 13');
INSERT INTO `Stimuli` VALUES (70, 'Reached smell 14');
INSERT INTO `Stimuli` VALUES (71, 'Reached smell 15');
INSERT INTO `Stimuli` VALUES (72, 'Reached smell 16');
INSERT INTO `Stimuli` VALUES (73, 'Reached smell 17');
INSERT INTO `Stimuli` VALUES (74, 'Reached smell 18');
INSERT INTO `Stimuli` VALUES (75, 'Reached smell 19');
INSERT INTO `Stimuli` VALUES (76, 'Patience');
INSERT INTO `Stimuli` VALUES (77, 'Discomfort');
INSERT INTO `Stimuli` VALUES (78, 'Eaten plant');
INSERT INTO `Stimuli` VALUES (79, 'Eaten fruit');
INSERT INTO `Stimuli` VALUES (80, 'Eaten food');
INSERT INTO `Stimuli` VALUES (81, 'Eaten animal');
INSERT INTO `Stimuli` VALUES (82, 'Eaten detritus');
INSERT INTO `Stimuli` VALUES (83, 'Comsume alcohol');
INSERT INTO `Stimuli` VALUES (84, 'Interacted with dangerous plant');
INSERT INTO `Stimuli` VALUES (85, 'Interacted with friendly plant');
INSERT INTO `Stimuli` VALUES (86, 'Played with bug');
INSERT INTO `Stimuli` VALUES (87, 'Played with critter');
INSERT INTO `Stimuli` VALUES (88, 'Hit critter');
INSERT INTO `Stimuli` VALUES (89, 'Played with dangerous animal');
INSERT INTO `Stimuli` VALUES (90, 'Activated button');
INSERT INTO `Stimuli` VALUES (91, 'Activated machine');
INSERT INTO `Stimuli` VALUES (92, 'Got machine');
INSERT INTO `Stimuli` VALUES (93, 'Hit machine');
INSERT INTO `Stimuli` VALUES (94, 'Got creature egg');
INSERT INTO `Stimuli` VALUES (95, 'Travelled in lift');
INSERT INTO `Stimuli` VALUES (96, 'Travelled through external door');
INSERT INTO `Stimuli` VALUES (97, 'Travelled through internal door');
INSERT INTO `Stimuli` VALUES (98, 'Played with toy');
INSERT INTO `Stimuli` VALUES (99, 'Drop everything');

-- --------------------------------------------------------

-- 
-- Table structure for table `actions`
-- 

CREATE TABLE `actions` (
  `Number` tinyint(3) unsigned NOT NULL default '0',
  `Name` text NOT NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `actions`
-- 

INSERT INTO `actions` VALUES (0, 'look');
INSERT INTO `actions` VALUES (1, 'push');
INSERT INTO `actions` VALUES (2, 'pull');
INSERT INTO `actions` VALUES (3, 'deactivate');
INSERT INTO `actions` VALUES (4, 'approach');
INSERT INTO `actions` VALUES (5, 'retreat');
INSERT INTO `actions` VALUES (6, 'get');
INSERT INTO `actions` VALUES (7, 'drop');
INSERT INTO `actions` VALUES (8, 'express');
INSERT INTO `actions` VALUES (9, 'rest');
INSERT INTO `actions` VALUES (10, 'left');
INSERT INTO `actions` VALUES (11, 'right');
INSERT INTO `actions` VALUES (12, 'eat');
INSERT INTO `actions` VALUES (13, 'hit');
INSERT INTO `actions` VALUES (14, 'not used');
INSERT INTO `actions` VALUES (15, 'up');
INSERT INTO `actions` VALUES (16, 'down');
INSERT INTO `actions` VALUES (17, 'exit');

-- --------------------------------------------------------

-- 
-- Table structure for table `brainLobes`
-- 

CREATE TABLE `brainLobes` (
  `Number` tinyint(3) unsigned NOT NULL default '0',
  `Name` text NOT NULL,
  `Quad` text NOT NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `brainLobes`
-- 

INSERT INTO `brainLobes` VALUES (0, 'attention', 'attn');
INSERT INTO `brainLobes` VALUES (1, 'decision', 'decn');
INSERT INTO `brainLobes` VALUES (2, 'verb', 'verb');
INSERT INTO `brainLobes` VALUES (4, 'noun', 'noun');
INSERT INTO `brainLobes` VALUES (5, 'vision', 'visn');
INSERT INTO `brainLobes` VALUES (6, 'smell', 'smel');
INSERT INTO `brainLobes` VALUES (8, 'drive', 'driv');
INSERT INTO `brainLobes` VALUES (9, 'situation', 'sitn');
INSERT INTO `brainLobes` VALUES (10, 'detail', 'detl');
INSERT INTO `brainLobes` VALUES (12, 'response', 'resp');
INSERT INTO `brainLobes` VALUES (13, 'proximity', 'prox');
INSERT INTO `brainLobes` VALUES (14, 'stim source', 'stim');

-- --------------------------------------------------------

-- 
-- Table structure for table `chemicalNames`
-- 

CREATE TABLE `chemicalNames` (
  `Number` tinyint(3) unsigned NOT NULL default '0',
  `Name` text NOT NULL,
  KEY `Number` (`Number`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `chemicalNames`
-- 

INSERT INTO `chemicalNames` VALUES (0, 'None');
INSERT INTO `chemicalNames` VALUES (1, 'Lactate');
INSERT INTO `chemicalNames` VALUES (2, 'Pyruvate');
INSERT INTO `chemicalNames` VALUES (3, 'Glucose');
INSERT INTO `chemicalNames` VALUES (4, 'Glycogen');
INSERT INTO `chemicalNames` VALUES (5, 'Starch');
INSERT INTO `chemicalNames` VALUES (6, 'Fatty Acid');
INSERT INTO `chemicalNames` VALUES (7, 'Cholesterol');
INSERT INTO `chemicalNames` VALUES (8, 'Triglyceride');
INSERT INTO `chemicalNames` VALUES (9, 'Adipose Tissue');
INSERT INTO `chemicalNames` VALUES (10, 'Fat');
INSERT INTO `chemicalNames` VALUES (11, 'Muscle Tissue');
INSERT INTO `chemicalNames` VALUES (12, 'Protein');
INSERT INTO `chemicalNames` VALUES (13, 'Amino Acid');
INSERT INTO `chemicalNames` VALUES (17, 'Downatrophin');
INSERT INTO `chemicalNames` VALUES (18, 'Upatrophin');
INSERT INTO `chemicalNames` VALUES (24, 'Dissolved carbon dioxide');
INSERT INTO `chemicalNames` VALUES (25, 'Urea');
INSERT INTO `chemicalNames` VALUES (26, 'Ammonia');
INSERT INTO `chemicalNames` VALUES (29, 'Air');
INSERT INTO `chemicalNames` VALUES (30, 'Oxygen');
INSERT INTO `chemicalNames` VALUES (33, 'Water');
INSERT INTO `chemicalNames` VALUES (34, 'Energy');
INSERT INTO `chemicalNames` VALUES (35, 'ATP');
INSERT INTO `chemicalNames` VALUES (36, 'ADP');
INSERT INTO `chemicalNames` VALUES (39, 'Arousal Potential');
INSERT INTO `chemicalNames` VALUES (40, 'Libido lowerer');
INSERT INTO `chemicalNames` VALUES (41, 'Opposite Sex Pheromone');
INSERT INTO `chemicalNames` VALUES (46, 'Oestrogen');
INSERT INTO `chemicalNames` VALUES (48, 'Progesterone');
INSERT INTO `chemicalNames` VALUES (53, 'Testosterone');
INSERT INTO `chemicalNames` VALUES (54, 'Inhibin');
INSERT INTO `chemicalNames` VALUES (66, 'Heavy Metals');
INSERT INTO `chemicalNames` VALUES (67, 'Cyanide');
INSERT INTO `chemicalNames` VALUES (68, 'Belladonna');
INSERT INTO `chemicalNames` VALUES (69, 'Geddonase');
INSERT INTO `chemicalNames` VALUES (70, 'Glycotoxin');
INSERT INTO `chemicalNames` VALUES (71, 'Sleep toxin');
INSERT INTO `chemicalNames` VALUES (72, 'Fever toxin');
INSERT INTO `chemicalNames` VALUES (73, 'Histamine A');
INSERT INTO `chemicalNames` VALUES (74, 'Histamine B');
INSERT INTO `chemicalNames` VALUES (75, 'Alcohol');
INSERT INTO `chemicalNames` VALUES (78, 'ATP Decoupler');
INSERT INTO `chemicalNames` VALUES (79, 'Carbon monoxide');
INSERT INTO `chemicalNames` VALUES (80, 'Fear toxin');
INSERT INTO `chemicalNames` VALUES (81, 'Muscle toxin');
INSERT INTO `chemicalNames` VALUES (82, 'Antigen 0');
INSERT INTO `chemicalNames` VALUES (83, 'Antigen 1');
INSERT INTO `chemicalNames` VALUES (84, 'Antigen 2');
INSERT INTO `chemicalNames` VALUES (85, 'Antigen 3');
INSERT INTO `chemicalNames` VALUES (86, 'Antigen 4');
INSERT INTO `chemicalNames` VALUES (87, 'Antigen 5');
INSERT INTO `chemicalNames` VALUES (88, 'Antigen 6');
INSERT INTO `chemicalNames` VALUES (89, 'Antigen 7');
INSERT INTO `chemicalNames` VALUES (92, 'Medicine one');
INSERT INTO `chemicalNames` VALUES (93, 'Anti-oxidant');
INSERT INTO `chemicalNames` VALUES (94, 'Prostaglandin');
INSERT INTO `chemicalNames` VALUES (95, 'EDTA');
INSERT INTO `chemicalNames` VALUES (96, 'Sodium thiosulphite');
INSERT INTO `chemicalNames` VALUES (97, 'Arnica');
INSERT INTO `chemicalNames` VALUES (98, 'Vitamin E');
INSERT INTO `chemicalNames` VALUES (99, 'Vitamin C');
INSERT INTO `chemicalNames` VALUES (100, 'Antihistamine');
INSERT INTO `chemicalNames` VALUES (102, 'Antibody 0');
INSERT INTO `chemicalNames` VALUES (103, 'Antibody 1');
INSERT INTO `chemicalNames` VALUES (104, 'Antibody 2');
INSERT INTO `chemicalNames` VALUES (105, 'Antibody 3');
INSERT INTO `chemicalNames` VALUES (106, 'Antibody 4');
INSERT INTO `chemicalNames` VALUES (107, 'Antibody 5');
INSERT INTO `chemicalNames` VALUES (108, 'Antibody 6');
INSERT INTO `chemicalNames` VALUES (109, 'Antibody 7');
INSERT INTO `chemicalNames` VALUES (112, 'Anabolic steroid');
INSERT INTO `chemicalNames` VALUES (113, 'Pistle');
INSERT INTO `chemicalNames` VALUES (114, 'Insulin');
INSERT INTO `chemicalNames` VALUES (115, 'Glycolase');
INSERT INTO `chemicalNames` VALUES (116, 'Dehydrogenase');
INSERT INTO `chemicalNames` VALUES (117, 'Adrenalin');
INSERT INTO `chemicalNames` VALUES (118, 'Grendel nitrate');
INSERT INTO `chemicalNames` VALUES (119, 'Ettin nitrate');
INSERT INTO `chemicalNames` VALUES (124, 'Activase');
INSERT INTO `chemicalNames` VALUES (125, 'Life');
INSERT INTO `chemicalNames` VALUES (127, 'Injury');
INSERT INTO `chemicalNames` VALUES (128, 'Stress');
INSERT INTO `chemicalNames` VALUES (129, 'Sleepase');
INSERT INTO `chemicalNames` VALUES (131, 'Pain backup');
INSERT INTO `chemicalNames` VALUES (132, 'Hunger for protein backup');
INSERT INTO `chemicalNames` VALUES (133, 'Hunger for carb backup');
INSERT INTO `chemicalNames` VALUES (134, 'Hunger for fat backup');
INSERT INTO `chemicalNames` VALUES (135, 'Coldness backup');
INSERT INTO `chemicalNames` VALUES (136, 'Hotness backup');
INSERT INTO `chemicalNames` VALUES (137, 'Tiredness backup');
INSERT INTO `chemicalNames` VALUES (138, 'Sleepiness backup');
INSERT INTO `chemicalNames` VALUES (139, 'Loneliness backup');
INSERT INTO `chemicalNames` VALUES (140, 'Crowded backup');
INSERT INTO `chemicalNames` VALUES (141, 'Fear backup');
INSERT INTO `chemicalNames` VALUES (142, 'Boredom backup');
INSERT INTO `chemicalNames` VALUES (143, 'Anger backup');
INSERT INTO `chemicalNames` VALUES (144, 'Sex drive backup');
INSERT INTO `chemicalNames` VALUES (145, 'Comfort backup');
INSERT INTO `chemicalNames` VALUES (148, 'Pain');
INSERT INTO `chemicalNames` VALUES (149, 'Hunger for protein');
INSERT INTO `chemicalNames` VALUES (150, 'Hunger for carbohydrate');
INSERT INTO `chemicalNames` VALUES (151, 'Hunger for fat');
INSERT INTO `chemicalNames` VALUES (152, 'Coldness');
INSERT INTO `chemicalNames` VALUES (153, 'Hotness');
INSERT INTO `chemicalNames` VALUES (154, 'Tiredness');
INSERT INTO `chemicalNames` VALUES (155, 'Sleepiness');
INSERT INTO `chemicalNames` VALUES (156, 'Loneliness');
INSERT INTO `chemicalNames` VALUES (157, 'Crowded');
INSERT INTO `chemicalNames` VALUES (158, 'Fear');
INSERT INTO `chemicalNames` VALUES (159, 'Boredom');
INSERT INTO `chemicalNames` VALUES (160, 'Anger');
INSERT INTO `chemicalNames` VALUES (161, 'Sex drive');
INSERT INTO `chemicalNames` VALUES (162, 'Comfort');
INSERT INTO `chemicalNames` VALUES (165, 'Ca smell 0 (sound)');
INSERT INTO `chemicalNames` VALUES (166, 'CA smell 1 (light)');
INSERT INTO `chemicalNames` VALUES (167, 'CA smell 2 (heat)');
INSERT INTO `chemicalNames` VALUES (168, 'Ca smell 3 (water)');
INSERT INTO `chemicalNames` VALUES (169, 'CA smell 4 (nutrient)');
INSERT INTO `chemicalNames` VALUES (170, 'CA smell 5 (water)');
INSERT INTO `chemicalNames` VALUES (171, 'CA smell 6 (protein)');
INSERT INTO `chemicalNames` VALUES (172, 'CA smell 7 (carbohydrate)');
INSERT INTO `chemicalNames` VALUES (173, 'CA smell 8 (fat)');
INSERT INTO `chemicalNames` VALUES (174, 'CA smell 9 (flowers)');
INSERT INTO `chemicalNames` VALUES (175, 'CA smell 10 (machinery)');
INSERT INTO `chemicalNames` VALUES (176, 'CA smell 11');
INSERT INTO `chemicalNames` VALUES (177, 'CA smell 12 (Norn)');
INSERT INTO `chemicalNames` VALUES (178, 'CA smell 13 (Grendel)');
INSERT INTO `chemicalNames` VALUES (179, 'CA smell 14 (Ettin)');
INSERT INTO `chemicalNames` VALUES (180, 'CA smell 15 (Norn home)');
INSERT INTO `chemicalNames` VALUES (181, 'CA smell 16 (Grendel home)');
INSERT INTO `chemicalNames` VALUES (182, 'CA smell 17 (Ettin home)');
INSERT INTO `chemicalNames` VALUES (183, 'CA smell 18');
INSERT INTO `chemicalNames` VALUES (184, 'CA smell 19');
INSERT INTO `chemicalNames` VALUES (187, 'Stress (H4C)');
INSERT INTO `chemicalNames` VALUES (188, 'Stress (H4P)');
INSERT INTO `chemicalNames` VALUES (189, 'Stress (H4F)');
INSERT INTO `chemicalNames` VALUES (190, 'Stress (Anger)');
INSERT INTO `chemicalNames` VALUES (191, 'Stress (Fear)');
INSERT INTO `chemicalNames` VALUES (192, 'Stress (Pain)');
INSERT INTO `chemicalNames` VALUES (193, 'Stress (Sleep)');
INSERT INTO `chemicalNames` VALUES (194, 'Stress (Tired)');
INSERT INTO `chemicalNames` VALUES (195, 'Stress (Crowded)');
INSERT INTO `chemicalNames` VALUES (198, 'Brain chemical 1');
INSERT INTO `chemicalNames` VALUES (199, 'Up');
INSERT INTO `chemicalNames` VALUES (200, 'Down');
INSERT INTO `chemicalNames` VALUES (201, 'Exit');
INSERT INTO `chemicalNames` VALUES (202, 'Enter');
INSERT INTO `chemicalNames` VALUES (203, 'Wait');
INSERT INTO `chemicalNames` VALUES (204, 'Reward');
INSERT INTO `chemicalNames` VALUES (205, 'Punishment');
INSERT INTO `chemicalNames` VALUES (206, 'Brain chemical 9');
INSERT INTO `chemicalNames` VALUES (207, 'Brain chemical 10');
INSERT INTO `chemicalNames` VALUES (208, 'Brain chemical 11');
INSERT INTO `chemicalNames` VALUES (209, 'Brain chemical 12');
INSERT INTO `chemicalNames` VALUES (210, 'Brain chemical 13');
INSERT INTO `chemicalNames` VALUES (211, 'Brain chemical 14');
INSERT INTO `chemicalNames` VALUES (212, 'Pre-REM sleep');
INSERT INTO `chemicalNames` VALUES (213, 'REM sleep');

-- --------------------------------------------------------

-- 
-- Table structure for table `details`
-- 

CREATE TABLE `details` (
  `Number` tinyint(3) unsigned NOT NULL default '0',
  `Name` text NOT NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `details`
-- 

INSERT INTO `details` VALUES (0, 'It is being carried by me');
INSERT INTO `details` VALUES (1, 'It is being carried by someone else');
INSERT INTO `details` VALUES (2, 'It is this close to me');
INSERT INTO `details` VALUES (4, 'It is a creature');
INSERT INTO `details` VALUES (5, 'It is my sibling');
INSERT INTO `details` VALUES (6, 'It is my parent');
INSERT INTO `details` VALUES (7, 'It is my child');
INSERT INTO `details` VALUES (8, 'It is of opposite sex and my genus');
INSERT INTO `details` VALUES (10, 'It is of this size');
INSERT INTO `details` VALUES (11, 'It is smelling this much');
INSERT INTO `details` VALUES (12, 'It is stopped');

-- --------------------------------------------------------

-- 
-- Table structure for table `drives`
-- 

CREATE TABLE `drives` (
  `Number` tinyint(3) unsigned NOT NULL default '0',
  `Name` text NOT NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `drives`
-- 

INSERT INTO `drives` VALUES (0, 'hurt');
INSERT INTO `drives` VALUES (1, 'hungry for protein');
INSERT INTO `drives` VALUES (2, 'hungry for starch');
INSERT INTO `drives` VALUES (3, 'hungry for fat');
INSERT INTO `drives` VALUES (4, 'cold');
INSERT INTO `drives` VALUES (5, 'hot');
INSERT INTO `drives` VALUES (6, 'tired');
INSERT INTO `drives` VALUES (7, 'sleepy');
INSERT INTO `drives` VALUES (8, 'lonely');
INSERT INTO `drives` VALUES (9, 'crowded');
INSERT INTO `drives` VALUES (10, 'scared');
INSERT INTO `drives` VALUES (11, 'bored');
INSERT INTO `drives` VALUES (12, 'angry');
INSERT INTO `drives` VALUES (13, 'friendly');
INSERT INTO `drives` VALUES (14, 'homesick');
INSERT INTO `drives` VALUES (15, 'low down');
INSERT INTO `drives` VALUES (16, 'high up');
INSERT INTO `drives` VALUES (17, 'trapped');
INSERT INTO `drives` VALUES (18, 'trapped');
INSERT INTO `drives` VALUES (19, 'patient');

-- --------------------------------------------------------

-- 
-- Table structure for table `genomes`
-- 

CREATE TABLE `genomes` (
  `Name` text NOT NULL,
  `filename` text NOT NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `genomes`
-- 

INSERT INTO `genomes` VALUES ('ChiChi', 'norn.chichi06.ex47.gen');
INSERT INTO `genomes` VALUES ('Ettin', 'ettn.final46e.gen.brain.gen');
INSERT INTO `genomes` VALUES ('Aqua', 'aqua_17.gen');
INSERT INTO `genomes` VALUES ('Dschungel', 'dsch12.gen');
INSERT INTO `genomes` VALUES ('Grendel', 'gren.final46g.gen.brain.gen');
INSERT INTO `genomes` VALUES ('Indio', 'indio.gen');
INSERT INTO `genomes` VALUES ('Bondi', 'norn.bondi.48.gen');
INSERT INTO `genomes` VALUES ('Magma', 'norn.magma.48.gen');
INSERT INTO `genomes` VALUES ('Toxic', 'norn.toxic.48.gen');
INSERT INTO `genomes` VALUES ('Treehugger', 'norn.treehugger.48.gen');
INSERT INTO `genomes` VALUES ('Hardman', 'norn.hardman.48.gen');
INSERT INTO `genomes` VALUES ('Banshee Grendel', 'gren.banshee.49.gen');

-- --------------------------------------------------------

-- 
-- Table structure for table `myGenome`
-- 

CREATE TABLE `myGenome` (
  `Index` bigint(20) unsigned NOT NULL auto_increment,
  `GeneType` tinyint(3) unsigned NOT NULL default '0',
  `GeneSubType` tinyint(3) unsigned NOT NULL default '0',
  `GeneID` tinyint(3) unsigned NOT NULL default '0',
  `Generation` tinyint(3) unsigned NOT NULL default '0',
  `SwitchOnTime` tinyint(3) unsigned NOT NULL default '0',
  `Flags` tinyint(3) unsigned NOT NULL default '0',
  `MutabilityWeighting` tinyint(3) unsigned NOT NULL default '0',
  `Variant` tinyint(3) unsigned NOT NULL default '0',
  `Body` blob NOT NULL,
  KEY `Index` (`Index`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `myGenome`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `sessions`
-- 

CREATE TABLE `sessions` (
  `ssid` text NOT NULL,
  `timestamp` timestamp(14) NOT NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `sessions`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `situations`
-- 

CREATE TABLE `situations` (
  `Number` tinyint(3) unsigned NOT NULL default '0',
  `Name` text NOT NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `situations`
-- 

INSERT INTO `situations` VALUES (0, 'I am this old');
INSERT INTO `situations` VALUES (1, 'I am inside a vehicle');
INSERT INTO `situations` VALUES (2, 'I am carrying something');
INSERT INTO `situations` VALUES (3, 'I am being carried');
INSERT INTO `situations` VALUES (5, 'I am falling');
INSERT INTO `situations` VALUES (6, 'I am near a creature of the opposite sex any my genus');
INSERT INTO `situations` VALUES (7, 'I am musically at this mood');
INSERT INTO `situations` VALUES (8, 'I am musically at this threat level');
INSERT INTO `situations` VALUES (10, 'I am the selected norn');

-- --------------------------------------------------------

-- 
-- Table structure for table `spriteSlots`
-- 

CREATE TABLE `spriteSlots` (
  `Name` text NOT NULL,
  `Species` char(1) NOT NULL default '',
  `Slot` char(1) NOT NULL default ''
) TYPE=MyISAM;

-- 
-- Dumping data for table `spriteSlots`
-- 

INSERT INTO `spriteSlots` VALUES ('ChiChi', '0', 'd');
INSERT INTO `spriteSlots` VALUES ('Ettin', '2', 'a');
INSERT INTO `spriteSlots` VALUES ('Bruin', '0', 'a');
INSERT INTO `spriteSlots` VALUES ('Bengal', '0', 'b');
INSERT INTO `spriteSlots` VALUES ('Civet', '0', 'c');
INSERT INTO `spriteSlots` VALUES ('Magma', '0', 'e');
INSERT INTO `spriteSlots` VALUES ('Bondi', '0', 'f');
INSERT INTO `spriteSlots` VALUES ('Treehugger', '0', 'h');
INSERT INTO `spriteSlots` VALUES ('Zebra', '0', 'i');
INSERT INTO `spriteSlots` VALUES ('Toxic', '0', 'j');
INSERT INTO `spriteSlots` VALUES ('Fallow', '0', 'k');
INSERT INTO `spriteSlots` VALUES ('Siamese', '0', 'l');
INSERT INTO `spriteSlots` VALUES ('Astro', '0', 'm');
INSERT INTO `spriteSlots` VALUES ('Hardman', '0', 'n');
INSERT INTO `spriteSlots` VALUES ('Harlequin', '0', 'o');
INSERT INTO `spriteSlots` VALUES ('Grendel', '1', 'a');
INSERT INTO `spriteSlots` VALUES ('Banshee Grendel', '1', 'b');
INSERT INTO `spriteSlots` VALUES ('Aqua', '2', 'k');
INSERT INTO `spriteSlots` VALUES ('Alien', '0', 't');
INSERT INTO `spriteSlots` VALUES ('Fire', '2', 'f');
INSERT INTO `spriteSlots` VALUES ('Gargoyle', '3', 'w');
INSERT INTO `spriteSlots` VALUES ('Butterfly', '3', 'a');
INSERT INTO `spriteSlots` VALUES ('Halloween', '3', 'h');
INSERT INTO `spriteSlots` VALUES ('Indio', '0', 'w');
INSERT INTO `spriteSlots` VALUES ('Jungle', '3', 'j');
INSERT INTO `spriteSlots` VALUES ('Plant', '1', 'p');
INSERT INTO `spriteSlots` VALUES ('Sahara', '3', 's');
INSERT INTO `spriteSlots` VALUES ('Shag-a-Delic', '0', 's');
INSERT INTO `spriteSlots` VALUES ('Yellowstone', '3', 'y');
        