<html>
  <head>
    <title>Official LiveGMS documentation center</title>
  </head>
  <body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF">
  <p align="center"><a href="../index.php"><img border="0" src="../logo.jpg"></a></p>
  <h2>Tutorials</h2>
  <h3>Beginners</h3>
  <li><a href="pigment_tutorial/pigmentEN.html">Color editing tutorial</a></li>
  <li><a href="pigment_tutorial/pigmentDE.html">Tutorial zum Farbeditieren</a> (German version)</li>
  <h3>Advanced users</h3>
  <li><a href="simplel/simplelEN.html">Creating a life form from scratch in 12 steps</a></li>
  <br>
  <h2>General information</h2>
  <li><a href="genomes/norngen_e.html">The Norn genome and Creature's dDNA</a></li>
  <li><a href="genomes/ettins_e.html">The Ettin genome</a></li>
  <li><a href="genomes/grndls_e.html">The Grendel genome</a></li>
  <br><br>
  <p align="center"><font size="+2"><a href="../index.php">Back to main page</a></font></p>
  </body>
</html>
