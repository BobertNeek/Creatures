<?
session_start();
?>
<html>
<head>
  <title>LiveGMS</title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF">
<p align="center"><img src="../logo.jpg"></p>
<hr>
<?
  include ("../admin/.mysqlData.php");
  mysql_connect($server,$user,$password);
  @mysql_select_db($database) or die( "Unable to select database");
  extract($_POST, EXTR_PREFIX_ALL, 'p');
  $totalNoError = "true";
  
   echo "Checking total number of genes... ";
  $noError = "true";
  flush();
 
  $query="SELECT * FROM " . session_id();
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  if ($num == 0)
  {
    $noError = "false";
    echo "<font color=\"red\">No genes found:<br> Please load a genome and then try again ;-)<br>";
  }
  else if ($num > 10000)
  {
    $noError = "false";
    echo "<font color=\"red\">More than 10000 genes found:</font> It is very probable that the creature will not be able to live.<br>"; 
  }
  else if ($num > 1000)
  {
    $noError = "false";
    echo "<font color=\"yellow\">More than 1000 genes found:</font> There may be various duplicated genes with unknown effect.<br>"; 
  }
  else if ($num < 500)
  {
    $noError = "false";
    echo "<font color=\"yellow\">Less than 500 genes found:</font> There may be various deleted genes with unknown, but probably bad effect.<br>"; 
  }
    
  if ($noError == "true")
    echo "<font color=\"green\">Ok</font><br>";
  else
    $totalNoError = "false";    

  echo "Checking brain... "; //Check lobes
  $noError = "true";
  flush();
 
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '0' AND `GeneSubType` = '1'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  if ($num == 0)
  {
    $noError = "false";
    echo "<font color=\"red\">No brain organ found:</font> This may lead to an unnatural behavior of the creature.<br>";
  }
  else if ($num > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one brain organ found:</font> This may lead to very high energy consumption.<br>"; 
  }
  
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '0' AND `MutabilityWeighting` != '0'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  if ($num > 0 && ($content.mysql_result($result,0,"Flags") & chr(1)) == chr(1))
  {
    $noError = "false";
    echo "<font color=\"yellow\">Mutable brain genes found:</font> Future mutations in brain genes could crash Creatures.<br>"; 
  }
  
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '0'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  if ($num != 45)
  {
    $noError = "false";
    echo "<font color=\"yellow\">Non-standard number of brain genes:</font> This may be either bad or good. Unfortunately I do not know ;-)<br>"; 
  }
  
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '0' AND `GeneSubType` = '0'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  $i=0;  
  $drivLobe = 0;
  $decnLobe = 0;
  $attnLobe = 0;
  $visnLobe = 0;
  $moveLobe = 0;
  $combLobe = 0;
  $stimLobe = 0;
  $nounLobe = 0;
  $verbLobe = 0;
  $detlLobe = 0;
  $situLobe = 0;
  $respLobe = 0;
  $smelLobe = 0;
  $forfLobe = 0;
  $moodLobe = 0;
  while ($i < $num)
  {
    $Body = $content.mysql_result($result,$i,"Body");
    $LobeId = substr($Body, 0, 4);
    $UpdateTime = ord(substr($Body, 5, 1)) + (ord(substr($Body, 4, 1)) * 256);
    $X = ord(substr($Body, 7, 1)) + (ord(substr($Body, 6, 1)) * 256);
    $Y = ord(substr($Body, 9, 1)) + (ord(substr($Body, 8, 1)) * 256);
    $Width = ord(substr($Body, 10, 1));
    $Height = ord(substr($Body, 11, 1));
    $Red = ord(substr($Body, 12, 1));
    $Green = ord(substr($Body, 13, 1));
    $Blue = ord(substr($Body, 14, 1));
    #$WTA = ord(substr($Body, 15, 1));
    $Tissue = ord(substr($Body, 16, 1));

    if (($LobeId == "driv") && ($Tissue == 5))
      ++$drivLobe;
    if (($LobeId == "decn") && ($Tissue == 10))
      ++$decnLobe;
    if (($LobeId == "attn") && ($Tissue == 9))
      ++$attnLobe;
    if (($LobeId == "visn"))
      ++$visnLobe;
    if (($LobeId == "move"))
      ++$moveLobe;
    if (($LobeId == "comb"))
      ++$combLobe;
    if (($LobeId == "stim") && ($Tissue == 3))
      ++$stimLobe;
    if (($LobeId == "noun") && ($Tissue == 2))
      ++$nounLobe;
    if (($LobeId == "verb") && ($Tissue == 1))
      ++$verbLobe;
    if (($LobeId == "detl") && ($Tissue == 7))
      ++$detlLobe;
    if (($LobeId == "situ") && ($Tissue == 6))
      ++$situLobe;
    if (($LobeId == "resp"))
      ++$respLobe;
    if (($LobeId == "smel"))
      ++$smelLobe;
    if (($LobeId == "forf"))
      ++$forfLobe;
    if (($LobeId == "mood"))
      ++$moodLobe;
    
    ++$i;
  }
  
  if ($drivLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No drive lobe found:</font> The creature will not feel drives.<br>";
  }
  if ($decnLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No decision lobe found:</font> The creature will not be able to do anything!<br>";
  }
  if ($attnLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No attention lobe found:</font> The creature will not be able to use things.<br>";
  }
  if ($visnLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No vision lobe found:</font> The creature will have problems sensing his/her environment.<br>";
  }
  if ($moveLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No move lobe found:</font> The creature will have problems sensing his/her environment.<br>";
  }
  if ($combLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No combination lobe found:</font> The creature will not be able to decide anything. Most creatures just run rightwards.<br>";
  }
  if ($stimLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No stimuli lobe found:</font> The creature will have problems sensing his/her environment.<br>";
  }
  if ($nounLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No noun lobe found:</font> The creature will not fully react to what you tell him/her.<br>";
  }
  if ($verbLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No verb lobe found:</font> The creature will not fully react to what you tell him/her.<br>";
  }
  if ($detlLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No detail lobe found:</font> The creature will have problems sensing his/her environment.<br>";
  }
  if ($situLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No situation lobe found:</font> The creature will have problems sensing his/her environment.<br>";
  }
  if ($respLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No response lobe found:</font> The creature will have problems sensing his/her environment.<br>";
  }
  if ($smelLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No smell lobe found:</font> The creature will have problems sensing his/her environment.<br>";
  }
  if ($forfLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No friend or foe lobe found:</font> The creature will not be able to build social relationships.<br>";
  }
  if ($moodLobe < 1)
  {
    $noError = "false";
    echo "<font color=\"red\">No mood lobe found:</font> The creature will not be able to express his/her mood.<br>";
  }
  
  if ($drivLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one drive lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($decnLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one decision lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($attnLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one attention lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($visnLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one vision lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($moveLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one move lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($combLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one combination lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($stimLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one stimuli lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($nounLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one noun lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($verbLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one verb lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($detlLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one detail lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($situLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one situation lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($respLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one response lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($smelLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one smell lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($forfLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one friend or foe lobe found:</font> Unknown behavioral effects.<br>";
  }
  if ($moodLobe > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one mood lobe found:</font> Unknown behavioral effects.<br>";
  }
    
  if ($noError == "true")
    echo "<font color=\"green\">Ok</font><br>";
  else
    $totalNoError = "false";    
    
  echo "Checking genus... ";
  $noError = "true";
  flush();
 
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '2' AND `GeneSubType` = '1'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  if ($num == 0)
  {
    $noError = "false";
    echo "<font color=\"red\">No genus found:</font> This may crash Creatures. You should consider adding one!<br>";
  }
  else if ($num > 1)
  {
    $noError = "false";
    echo "<font color=\"red\">More than one genus found:</font> This may crash Creatures. You should consider deleting all but one.<br>"; 
  }
  
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '2' AND `GeneSubType` = '1' AND `MutabilityWeighting` != '0'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  if ($num > 0 && ($content.mysql_result($result,0,"Flags") != 0))
  {
    $noError = "false";
    echo "<font color=\"yellow\">Genus is mutable:</font> Future mutations in genus could crash Creatures.<br>"; 
  }
    
  if ($noError == "true")
    echo "<font color=\"green\">Ok</font><br>";
  else
    $totalNoError = "false";    
    
  echo "Checking chemical half live gene... ";
  $noError = "true";
  flush();
 
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '1' AND `GeneSubType` = '3'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  if ($num == 0)
  {
    $noError = "false";
    echo "<font color=\"red\">No half life gene found:</font> The resulting creature will have a low chance to live. Consider adding one.<br>";
  }
  else if ($num > 1)
  {
    $noError = "false";
    echo "<font color=\"yellow\">More than one half life genes found:</font> All but the last are useless. You might want to delete all but one.<br>"; 
  }
  
  $Body = $content.mysql_result($result,0,"Body");
  if (ord(substr($Body, 125, 1)) > 150)
  {
    $noError = "false";
    echo "<font color=\"yellow\">Long living life chemical:</font> The creature may live very long or even forever.<br>";
  }
  else if (ord(substr($Body, 125, 1)) < 75)
  {
    $noError = "false";
    echo "<font color=\"red\">Short living life chemical:</font> The creature will die early.<br>";
  }
  
  if (ord(substr($Body, 34, 1)) != 255)
  {
    $noError = "false";
    echo "<font color=\"red\">Short living energy chemical:</font> The creature may die because of this. Energy half live should be 255.<br>";
  }
  if (ord(substr($Body, 35, 1)) != 255)
  {
    $noError = "false";
    echo "<font color=\"red\">Short living ATP chemical:</font> The creature will probably die early. ATP half live should be 255.<br>";
  }
  if (ord(substr($Body, 36, 1)) != 255)
  {
    $noError = "false";
    echo "<font color=\"red\">Short living ADP chemical:</font> The creature will probably die early. ADP half live should be 255.<br>";
  }
    
  if ($noError == "true")
    echo "<font color=\"green\">Ok</font><br>";
  else
    $totalNoError = "false";    
        
    
  echo "Checking biochemical emitters... ";
  $noError = "true";
  flush();
 
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '1' AND `GeneSubType` = '1'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  $i=0;  
  while ($i < $num)
  {
    $Body = $content.mysql_result($result,$i,"Body");
    $Organ = ord(substr($Body, 0, 1));
    $Tissue = ord(substr($Body, 1, 1));
    $Locus = ord(substr($Body, 2, 1));
    $Chemical = ord(substr($Body, 3, 1));
    $Threshold = ord(substr($Body, 4, 1));
    $Rate = ord(substr($Body, 5, 1));
    $Gain = ord(substr($Body, 6, 1));
    $Flags = ord(substr($Body, 7, 1));
    if (($Organ == 1) && ($Tissue == 4) && ($Locus == 9) && ($Chemical == 29))
      $doesBreath = "true";
    if (($Chemical == 149))
      $doesGetHungryProtein = "true";
    if (($Chemical == 150))
      $doesGetHungryCarbohydrate = "true";
    if (($Chemical == 151))
      $doesGetHungryFat = "true";
    
    ++$i;
  }
  
  if ($doesBreath != "true")
  {
    $noError = "false";
    echo "<font color=\"red\">Creature does not breath air:</font> If the creature lives underwater, this is nothing to worry about. If not, this probably is!<br>";
  }
  if ($doesGetHungryProtein != "true")
  {
    $noError = "false";
    echo "<font color=\"yellow\">Creature does not get hungry for protein:</font> This may reduce the expected lifespan.<br>";
  }
  if ($doesGetHungryCarbohydrate != "true")
  {
    $noError = "false";
    echo "<font color=\"yellow\">Creature does not get hungry for carbohydrate:</font> This may reduce the expected lifespan.<br>";
  }
  if ($doesGetHungryFat != "true")
  {
    $noError = "false";
    echo "<font color=\"yellow\">Creature does not get hungry for fat:</font> This may reduce the expected lifespan.<br>";
  }
  
  if ($noError == "true")
    echo "<font color=\"green\">Ok</font><br>";
  else
    $totalNoError = "false";           
      
  echo "Checking biochemical receptors... ";
  $noError = "true";
  flush();
 
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '1' AND `GeneSubType` = '0'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  $i=0;
  while ($i < $num)
  {
    $Body = $content.mysql_result($result,$i,"Body");
    $Organ = ord(substr($Body, 0, 1));
    $Tissue = ord(substr($Body, 1, 1));
    $Locus = ord(substr($Body, 2, 1));
    $Chemical = ord(substr($Body, 3, 1));
    $Threshold = ord(substr($Body, 4, 1));
    $Nominal = ord(substr($Body, 5, 1));
    $Gain = ord(substr($Body, 6, 1));
    $Flags = ord(substr($Body, 7, 1));
    
    if (($Chemical == 125) && ($Organ == 1) && ($Tissue == 0) && ($Locus == 0))
      $childThreshold = $Threshold;
    if (($Chemical == 125) && ($Organ == 1) && ($Tissue == 0) && ($Locus == 1))
      $adolescentThreshold = $Threshold;
    if (($Chemical == 125) && ($Organ == 1) && ($Tissue == 0) && ($Locus == 2))
      $youngThreshold = $Threshold;
    if (($Chemical == 125) && ($Organ == 1) && ($Tissue == 0) && ($Locus == 3))
      $adultThreshold = $Threshold;
    if (($Chemical == 125) && ($Organ == 1) && ($Tissue == 0) && ($Locus == 4))
      $oldThreshold = $Threshold;
    if (($Chemical == 125) && ($Organ == 1) && ($Tissue == 0) && ($Locus == 5))
      $senileThreshold = $Threshold;
    if (($Chemical == 125) && ($Organ == 1) && ($Tissue == 0) && ($Locus == 6))
      $deadThreshold = $Threshold;
   
    ++$i;
  }
  
  if (!(($childThreshold > $adolescentThreshold) && ($adolescentThreshold > $youngThreshold) && ($youngThreshold > $adultThreshold) && ($adultThreshold > $oldThreshold) && ($oldThreshold > $senileThreshold)))
  {
    $noError = "false";
    echo "<font color=\"red\">Wrong lifestage switching:</font> The creature will not age correctly. This may lead to creatures that never die. Check the ageing receptors and their thresholds.<br>";
  }
  if ((!($senileThreshold > $deadThreshold)) || ($deadThreshold < 3))
  {
    $noError = "false";
    echo "<font color=\"red\">None or incorrect die by old age gene:</font> The creature will not die if it becomes old. Check the ageing receptors and their thresholds.<br>";
  }
  
  if ($noError == "true")
    echo "<font color=\"green\">Ok</font><br>";
  else
    $totalNoError = "false";    
    
  echo "Checking biochemical reactions... ";
  $noError = "true";
  flush();
 
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '1' AND `GeneSubType` = '2'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  $i=0;
  while ($i < $num)
  {
    $Body = $content.mysql_result($result,$i,"Body");
    $Reactant0 = ord(substr($Body, 1, 1));
    $Quantity0 = ord(substr($Body, 0, 1));
    $Reactant1 = ord(substr($Body, 3, 1));
    $Quantity1 = ord(substr($Body, 2, 1));
    $Product2 = ord(substr($Body, 5, 1));
    $Quantity2 = ord(substr($Body, 4, 1));
    $Product3 = ord(substr($Body, 7, 1));
    $Quantity3 = ord(substr($Body, 6, 1));
    $Rate = ord(substr($Body, 8, 1));

    
    if (($Reactant0 == 12) && ($Product2 == 13) && ($Quantity2 > 0) && ($Rate < 100))
      $doesProduceAminoAcid = "true";
    if (($Reactant0 == 5) && ($Product2 == 3) && ($Quantity2 > 0) && ($Rate < 100))
      $doesProduceGlucose = "true";
    if (($Reactant0 == 10) && ($Product2 == 8) && ($Quantity2 > 0) && ($Rate < 100))
      $doesProduceTriglyceride = "true";
    if (($Reactant1 == 35) && ($Product3 == 36) && ($Quantity3 > 0) && ($Rate < 100))
      $doesProduceADP = "true";
    if (($Reactant1 == 36) && ($Product3 == 35) && ($Quantity3 > 0) && ($Rate < 100))
      $doesProduceATP = "true";
    if ((($Product2 == 2) && ($Quantity2 > 0)) || (($Product3 == 2) && ($Quantity3 > 0)) && ($Rate < 100))
      $doesProducePyruvate = "true";
   
    ++$i;
  }
  
  if ($doesProduceAminoAcid != "true")
  {
    $noError = "false";
    echo "<font color=\"red\">Cannot digest proteins into amino acid:</font> Injecting amino acid may keep the creature alive for a while.<br>";
  }
  if ($doesProduceGlucose != "true")
  {
    $noError = "false";
    echo "<font color=\"red\">Cannot digest starch into glucose:</font> Injecting glucose or glycogen may keep the creature alive for a while.<br>";
  }
  if ($doesProduceTriglyceride != "true")
  {
    $noError = "false";
    echo "<font color=\"red\">Cannot digest fat into triglyceride:</font> Injecting triglyceride may keep the creature alive for a while.<br>";
  }
  if ($doesProducePyruvate != "true")
  {
    $noError = "false";
    echo "<font color=\"red\">Does not produce pyruvate:</font> Pyruvate is important for each cells's function. Injecting pyruvate may keep the creature alive for a while.<br>";
  }
  if (($doesProduceATP != "true") || ($doesProduceADP != "true"))
  {
    $noError = "false";
    echo "<font color=\"red\">Incorrect ADP<->ATP cycle:</font> The creature will probably die instantly.<br>";
  }
  
  if ($noError == "true")
    echo "<font color=\"green\">Ok</font><br>";
  else
    $totalNoError = "false";
     
  echo "Checking initial concentrations... ";
  $noError = "true";
  flush();
 
  $query="SELECT * FROM " . session_id() . "  WHERE 1 AND `GeneType` = '1' AND `GeneSubType` = '4' AND `SwitchOnTime` = '0'";
  $result=mysql_query($query);
  @$num=mysql_numrows($result);
  
  $i=0;
  while ($i < $num)
  {
    $Body = $content.mysql_result($result,$i,"Body");
    $Chemical = ord(substr($Body, 0, 1));
    $Amount = ord(substr($Body, 1, 1));
    
    if (($Chemical == 3) && ($Amount > 25))
      $hasGlucose = "true";
    if (($Chemical == 35) && ($Amount > 100))
      $hasATP = "true";
    if (($Chemical == 34) && ($Amount > 100))
      $hasEnergy = "true";
    if (($Chemical == 2) && ($Amount > 25))
      $hasPyruvate = "true";
    if (($Chemical == 30) && ($Amount > 100))
      $hasOxygen = "true"; 
    if (($Chemical == 125) && ($Amount == 255))
      $hasLife = "true"; 
       
    ++$i;
  }
  
  if (($hasGlucose != "true"))
  {
    $noError = "false";
    echo "<font color=\"red\">Too small amount of Glucose:</font> The creature will probably die instantly.<br>";
  }
  if (($hasATP != "true"))
  {
    $noError = "false";
    echo "<font color=\"red\">Too small amount of ATP:</font> The creature will probably die instantly.<br>";
  }
  if (($hasEnergy != "true"))
  {
    $noError = "false";
    echo "<font color=\"red\">Too small amount of Energy:</font> The creature will probably die instantly.<br>";
  }
  if (($hasPyruvate != "true"))
  {
    $noError = "false";
    echo "<font color=\"red\">Small amount of Pyruvate:</font> The creature may die quickly.<br>";
  }
  if (($hasOxygen != "true"))
  {
    $noError = "false";
    echo "<font color=\"red\">Too small amount of Oxygen:</font> The creature will probably die instantly.<br>";
  }
  if (($hasLife != "true"))
  {
    $noError = "false";
    echo "<font color=\"red\">Too small amount of Life chemical:</font> The creature will not age!<br>";
  }
  
  if ($noError == "true")
    echo "<font color=\"green\">Ok</font><br>";
  else
    $totalNoError = "false";
 
  
  if ($totalNoError == "true")
    echo "<br><font color=\"green\">Everything's ok :-)</font><br>";
  else
    echo "<br><font color=\"orange\">Something seems to be wrong with the genome.</font><br>";
    
  mysql_close();
?>
<hr>
<a href="../interface.php"><b>Back to main screen</b></a>
</body>
</html>
