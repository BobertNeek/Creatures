<html>
<head>
</head>
<body bgcolor="black" onload="opener.location.reload(); window.close();">
</body>
</html>
