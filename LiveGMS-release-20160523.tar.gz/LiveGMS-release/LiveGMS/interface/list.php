<?
function getSwitchOnTimeName ($switchOnTime)
{
  if ($switchOnTime == "0")
    return "Baby";
  else if ($switchOnTime == "1")
    return "Child";
  else if ($switchOnTime == "2")
    return "Adolescent";
  else if ($switchOnTime == "3")
    return "Youth";
  else if ($switchOnTime == "4")
    return "Adult";
  else if ($switchOnTime == "5")
    return "Old";
  else if ($switchOnTime == "6")
    return "Senile";
}

function getTypeName ($geneType, $geneSubType)
{
  if (($geneType == "0") & ($geneSubType == "0"))
      return "Brain lobe";
    else if (($geneType == "0") & ($geneSubType == "1"))
      return "Brain organ";
    else if (($geneType == "0") & ($geneSubType == "2"))
      return "Brain tract";
    else if (($geneType == "1") & ($geneSubType == "0"))
      return "Biochemical Receptor";
    else if (($geneType == "1") & ($geneSubType == "1"))
      return "Biochemical Emitter";
    else if (($geneType == "1") & ($geneSubType == "2"))
      return "Biochemical Reaction";
    else if (($geneType == "1") & ($geneSubType == "3"))
      return "Biochemical Half Lifes";
    else if (($geneType == "1") & ($geneSubType == "4"))
      return "Biochemical Initial Concentration";
    else if (($geneType == "1") & ($geneSubType == "5"))
      return "Biochemical Neuro Emitter";
    else if (($geneType == "2") & ($geneSubType == "0"))
      return "Creature Stimulus";
    else if (($geneType == "2") & ($geneSubType == "1"))
      return "Creature Genus";
    else if (($geneType == "2") & ($geneSubType == "2"))
      return "Creature Appearance";
    else if (($geneType == "2") & ($geneSubType == "3"))
      return "Creature Pose";
    else if (($geneType == "2") & ($geneSubType == "4"))
      return "Creature Gait";
    else if (($geneType == "2") & ($geneSubType == "5"))
      return "Creature Instinct";
    else if (($geneType == "2") & ($geneSubType == "6"))
      return "Creature Pigment";
    else if (($geneType == "2") & ($geneSubType == "7"))
      return "Creature Pigment Bleed";
    else if (($geneType == "2") & ($geneSubType == "8"))
      return "Creature Facial Expression";
    else if (($geneType == "3") & ($geneSubType == "0"))
      return "Organ";
}


function listGenome ($dbTable, $orderBy, $startNum)
{
  $orderBy = mysql_real_escape_string($orderBy);
  $startNum = mysql_real_escape_string($startNum);
  if ($orderBy == "GeneType")
    $query="SELECT * FROM `$dbTable` ORDER BY `$orderBy`, `GeneSubType` ASC";
  else
    $query="SELECT * FROM `$dbTable` ORDER BY `$orderBy` ASC";
  $allResult=mysql_query($query);
  if ($allResult === FALSE)
  {
    echo "Please load a genome file first.";
    return;
  }
  $num=mysql_numrows($allResult);
  echo "There are $num genes loaded.<br>
  <hr>
  <b>Page map:</b><br>
  ";
  for ($i = 0; $i < $num; $i += 100)
  {
    $nextI = $i + 99;
    if ($nextI >= $num)
      $nextI = $num - 1;
    echo "<a href=\"interface.php?orderBy=$orderBy&startNum=" . ($i + 1) . "\">Page " . ($i / 100 ) . "</a>: ";
    if ($orderBy == "GeneType")
    {
      echo (getTypeName($content.mysql_result($allResult,$i,"GeneType"), $content.mysql_result($allResult,$i,"GeneSubType")) . " - " . getTypeName($content.mysql_result($allResult,$nextI,"GeneType"), $content.mysql_result($allResult,$nextI,"GeneSubType")));
    }
    else if ($orderBy == "SwitchOnTime")
    {
      echo (getSwitchOnTimeName($content.mysql_result($allResult,$i,"SwitchOnTime")) . " - " . getSwitchOnTimeName($content.mysql_result($allResult,$nextI,"SwitchOnTime")));
    }
    else if ($orderBy == "MutabilityWeighting")
    {
      echo ($content.mysql_result($allResult,$i,"MutabilityWeighting") . " - " . $content.mysql_result($allResult,$nextI,"MutabilityWeighting"));
    }
    else
    {
      echo (($i + 1) . " - " . ($nextI + 1));
    }
    echo "<br>";
  }
  echo "<hr><table border=\"1\">
  <tr>
  <th><a href=\"interface.php?orderBy=Index\">Number</a></th>
  <th><a href=\"interface.php?orderBy=GeneType\">Type</a></th>
  <th>Description</th>
  <th><a href=\"interface.php?orderBy=SwitchOnTime\">Switch on</a></th>
  <th>Sex</th>
  <th><a href=\"interface.php?orderBy=MutabilityWeighting\">Mutability</a></th>
  <th>Modify header</th>
  <th>Modify body</th>
  <th>Delete</th>
  <th>Move</th>
  </tr>";
  $i=$startNum;
  while (($i<$num) && ($i < ($startNum + 100)))
  {
    echo "<tr>";
    $Index = $content.mysql_result($allResult,$i,"Index");
    echo "<td>$Index</td>";

    echo "<td>" . getTypeName($content.mysql_result($allResult,$i,"GeneType"), $content.mysql_result($allResult,$i,"GeneSubType")) . "</td>";
      
    $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '" . mysql_real_escape_string($Index) . "'";
    $result = mysql_query($query);
    $Body = $content.mysql_result($result,0,"Body");
    include ("forms/loadData.php");
    
    echo "<td>$Description</td>";

    echo "<td>" . getSwitchOnTimeName($content.mysql_result($allResult,$i,"SwitchOnTime")) . "</td>";

    if ((chr($content.mysql_result($allResult,$i,"Flags")) & chr(16)) == chr(16))
      echo "<td>Female</td>";
    else if ((chr($content.mysql_result($allResult,$i,"Flags")) & chr(8)) == chr(8))
      echo "<td>Male</td>";
    else
      echo "<td>Both</td>";

    $addStart = "";
    $addEnd = "";
    if ((chr($content.mysql_result($allResult,$i,"Flags")) & chr(32)) == chr(32))
    {
      $addStart = "(";
      $addEnd = ")";
    }

    echo "<td>" . $addStart . $content.mysql_result($allResult,$i,"MutabilityWeighting") . $addEnd . "</td>";

    echo "<td><form action=\"forms/modifyHeaderForm.php\" method=\"post\" target=\"_blank\"><input type=\"hidden\" name=\"Index\" value=\"$Index\"><input type=\"submit\" value=\"Modify header\"></form>";
    echo "<td><form action=\"forms/modifyBodyForm.php\" method=\"post\" target=\"_blank\"><input type=\"hidden\" name=\"Index\" value=\"$Index\"><input type=\"submit\" value=\"Modify body\"></form>";
    echo "<td><form action=\"forms/deleteForm.php\" method=\"post\" target=\"_blank\"><input type=\"hidden\" name=\"Index\" value=\"$Index\"><input type=\"submit\" value=\"Delete\"></form></td>";
    echo "<td><form action=\"forms/moveForm.php\" method=\"post\" target=\"_blank\"><input type=\"hidden\" name=\"Index\" value=\"$Index\"><input type=\"submit\" value=\"Move\"></form></td>";

    echo "</tr>";
    ++$i;
  }
  echo "</table>";
}
?>
