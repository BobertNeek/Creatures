<?
session_start();
?>
<html>
<head>
  <title>LiveGMS - Show watermark</title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF" onLoad="window.resizeTo(600,400); window.menubar.visible = false; window.toolbar.visible = false; window.personalbar.visible = false; window.statusbar.visible = false; window.locationbar.visible = false;">
<p align="center"><img src="../logo.jpg"></p>
<hr>

<?
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$query = "SELECT `Index` FROM `" . session_id() . "` WHERE 1 ORDER BY `Index` ASC";
$result = mysql_query($query);
$num=mysql_numrows($result);

$i = 0;
while ($i < ($num - 4))
{
$Index = $content.mysql_result($result,$i,"Index");

$query = "SELECT `Variant` FROM `" . session_id() . "` WHERE 1 AND `Index` = '" . mysql_real_escape_string($Index) . "'";
$result2 = mysql_query($query);
if ($content.mysql_result($result2,0,"Variant") == 255)
{
++$Index;
$query = "SELECT `Variant` FROM `" . session_id() . "` WHERE 1 AND `Index` = '" . mysql_real_escape_string($Index) . "'";
$result2 = mysql_query($query);
@$Waterbytes = chr($content.mysql_result($result2,0,"Variant"));
$query = "SELECT `Variant` FROM `" . session_id() . "` WHERE 1 AND `Index` = '" . mysql_real_escape_string(($Index + 1)) . "'";
$result2 = mysql_query($query);
@$Waterbytes = $Waterbytes . chr($content.mysql_result($result2,0,"Variant"));
$query = "SELECT `Variant` FROM `" . session_id() . "` WHERE 1 AND `Index` = '" . mysql_real_escape_string(($Index + 2)) . "'";
$result2 = mysql_query($query);
@$Waterbytes = $Waterbytes . chr($content.mysql_result($result2,0,"Variant"));

#echo "<br>" . $Waterbytes;

$Pointer = 0;
while ($Pointer < 16)
{
  if ((ord(substr($Waterbytes, 0, 1)) ^ ord(substr($Waterbytes, 1, 1)) ^ 23 ^ $Pointer) == ord(substr($Waterbytes, 2, 1)))
  {
    #echo "<br>Index: $Index Pointer: $Pointer $Waterbytes";
    eval('$Watermarkh' . $Pointer . ' = substr($Waterbytes, 0, 2);');
  }
  ++$Pointer;
}
}

++$i;
}

$Pointer = 0;
while ($Pointer < 16)
{
  eval('if ($Watermarkh' . $Pointer . ' == "") $Watermarkh' . $Pointer . ' = "??";');
  ++$Pointer;
}

echo "<br>Watermark: " . $Watermarkh0 . $Watermarkh1 . $Watermarkh2 . $Watermarkh3 . $Watermarkh4 . $Watermarkh5 . $Watermarkh6 . $Watermarkh7 . $Watermarkh8 . $Watermarkh9 . $Watermarkh10 . $Watermarkh11 . $Watermarkh12 . $Watermarkh13 . $Watermarkh14 . $Watermarkh15;

mysql_close();
?>
</body>
</html>
