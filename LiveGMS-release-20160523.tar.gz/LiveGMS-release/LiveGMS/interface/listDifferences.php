<?
session_start();
?>
<html>
<head>
  <title>LiveGMS</title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF">
<p align="center"><img src="../logo.jpg"></p>
<hr>
<?
  include ("../ea/readfile.php");
  include ("../admin/.mysqlData.php");
  mysql_connect($server,$user,$password);
  @mysql_select_db($database) or die( "Unable to select database");
  extract($_POST, EXTR_PREFIX_ALL, 'p');

  echo "Reading genome... Please wait<br>";
  flush();
  $query="DROP TABLE `" . session_id() . "_comp`;";
  mysql_query($query);
  $query="CREATE TABLE `" . session_id() . "_comp" . "` (`Index` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `GeneType` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `GeneSubType` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `GeneID` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Generation` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `SwitchOnTime` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Flags` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `MutabilityWeighting` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Variant` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Body` BLOB NOT NULL, INDEX (`Index`));";
  mysql_query($query);
  $errors = readGeneFile($_FILES['geneFile']['tmp_name'], (session_id() . "_comp"));
  if ($errors == -1)
    echo "Genome could not be loaded.";
  else
  {
    echo "Genome loaded. $errors genes have been skipped or corrected because of errors.";

  echo "<br><br>Comparing genome... Please wait<br>";
  flush();
  echo "<br>The following genes taken from the base genome do not exist in the compared genome (differences in gene header have been ignored): <br>";

  $query="SELECT * FROM " . session_id() . " ORDER BY `Index` ASC";
  $allResult=mysql_query($query);
  $query="SELECT * FROM " . session_id() . "_comp" . " ORDER BY `Index` ASC";
  $allResult2=mysql_query($query);


  $num=mysql_numrows($allResult);
  $num2=mysql_numrows($allResult2);
  echo "<table border=\"1\">
  <tr>
  <th>Number</th>
  <th>Type</th>
  <th>Description</th>
  <th>Switch on</th>
  <th>Sex</th>
  <th>Mutability</th>
  <th>Modify header</th>
  <th>Modify body</th>
  <th>Delete</th>
  <th>Move</th>
  </tr>";
  $NumMissing = 0;
  $i=0;
  while ($i<$num)
  {
    $Body = $content.mysql_result($allResult,$i,"Body");
    $Exist = "false";
    $i2 = 0;
    while (((($i + $i2) < $num2) OR (($i - $i2) >= 0)) AND ($Exist == "false"))
    {
      if (($i + $i2) < $num2)
      {
        $Body2 = $content.mysql_result($allResult2,$i + $i2,"Body");
        if ($Body2 == $Body)
          $Exist = "true";
      }
      if ((($i - $i2) >= 0) AND (($i - $i2) < $num2))
      {
        $Body2 = $content.mysql_result($allResult2,$i - $i2,"Body");
        if ($Body2 == $Body)
          $Exist = "true";
      }
      ++$i2;
    }

    if ($Exist == "false")
    {
    ++$NumMissing;
    echo "<tr>";
    $Index = $content.mysql_result($allResult,$i,"Index");
    echo "<td>$Index</td>";

    if (($content.mysql_result($allResult,$i,"GeneType") == "0") & ($content.mysql_result($allResult,$i,"GeneSubType") == "0"))
      echo "<td>Brain lobe</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "0") & ($content.mysql_result($allResult,$i,"GeneSubType") == "1"))
      echo "<td>Brain organ</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "0") & ($content.mysql_result($allResult,$i,"GeneSubType") == "2"))
      echo "<td>Brain tract</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "1") & ($content.mysql_result($allResult,$i,"GeneSubType") == "0"))
      echo "<td>Biochemical Receptor</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "1") & ($content.mysql_result($allResult,$i,"GeneSubType") == "1"))
      echo "<td>Biochemical Emitter</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "1") & ($content.mysql_result($allResult,$i,"GeneSubType") == "2"))
      echo "<td>Biochemical Reaction</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "1") & ($content.mysql_result($allResult,$i,"GeneSubType") == "3"))
      echo "<td>Biochemical Half Lifes</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "1") & ($content.mysql_result($allResult,$i,"GeneSubType") == "4"))
      echo "<td>Biochemical Initial Concentration</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "1") & ($content.mysql_result($allResult,$i,"GeneSubType") == "5"))
      echo "<td>Biochemical Neuro Emitter</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "2") & ($content.mysql_result($allResult,$i,"GeneSubType") == "0"))
      echo "<td>Creature Stimulus</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "2") & ($content.mysql_result($allResult,$i,"GeneSubType") == "1"))
      echo "<td>Creature Genus</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "2") & ($content.mysql_result($allResult,$i,"GeneSubType") == "2"))
      echo "<td>Creature Appearance</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "2") & ($content.mysql_result($allResult,$i,"GeneSubType") == "3"))
      echo "<td>Creature Pose</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "2") & ($content.mysql_result($allResult,$i,"GeneSubType") == "4"))
      echo "<td>Creature Gait</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "2") & ($content.mysql_result($allResult,$i,"GeneSubType") == "5"))
      echo "<td>Creature Instinct</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "2") & ($content.mysql_result($allResult,$i,"GeneSubType") == "6"))
      echo "<td>Creature Pigment</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "2") & ($content.mysql_result($allResult,$i,"GeneSubType") == "7"))
      echo "<td>Creature Pigment Bleed</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "2") & ($content.mysql_result($allResult,$i,"GeneSubType") == "8"))
      echo "<td>Creature Facial Expression</td>";
    else if (($content.mysql_result($allResult,$i,"GeneType") == "3") & ($content.mysql_result($allResult,$i,"GeneSubType") == "0"))
      echo "<td>Organ</td>";
      
    $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '" . mysql_real_escape_string($Index) . "'";
    $result = mysql_query($query);
    $Body = $content.mysql_result($result,0,"Body");
    include ("../forms/loadData.php");
    
    echo "<td>$Description</td>";

    if ($content.mysql_result($allResult,$i,"SwitchOnTime") == "0")
      echo "<td>Baby</td>";
    else if ($content.mysql_result($allResult,$i,"SwitchOnTime") == "1")
      echo "<td>Child</td>";
    else if ($content.mysql_result($allResult,$i,"SwitchOnTime") == "2")
      echo "<td>Adolescent</td>";
    else if ($content.mysql_result($allResult,$i,"SwitchOnTime") == "3")
      echo "<td>Youth</td>";
    else if ($content.mysql_result($allResult,$i,"SwitchOnTime") == "4")
      echo "<td>Adult</td>";
    else if ($content.mysql_result($allResult,$i,"SwitchOnTime") == "5")
      echo "<td>Old</td>";
    else if ($content.mysql_result($allResult,$i,"SwitchOnTime") == "6")
      echo "<td>Senile</td>";

    if ((chr($content.mysql_result($allResult,$i,"Flags")) & chr(16)) == chr(16))
      echo "<td>Female</td>";
    else if ((chr($content.mysql_result($allResult,$i,"Flags")) & chr(8)) == chr(8))
      echo "<td>Male</td>";
    else
      echo "<td>Both</td>";

    $addStart = "";
    $addEnd = "";
    if ((chr($content.mysql_result($allResult,$i,"Flags")) & chr(32)) == chr(32))
    {
      $addStart = "(";
      $addEnd = ")";
    }

    echo "<td>" . $addStart . $content.mysql_result($allResult,$i,"MutabilityWeighting") . $addEnd . "</td>";

    echo "<td><form action=\"../forms/modifyHeaderForm.php\" method=\"post\" target=\"_blank\"><input type=\"hidden\" name=\"Index\" value=\"$Index\"><input type=\"submit\" value=\"Modify header\"></form>";
    echo "<td><form action=\"../forms/modifyBodyForm.php\" method=\"post\" target=\"_blank\"><input type=\"hidden\" name=\"Index\" value=\"$Index\"><input type=\"submit\" value=\"Modify body\"></form>";
    echo "<td><form action=\"../forms/deleteForm.php\" method=\"post\" target=\"_blank\"><input type=\"hidden\" name=\"Index\" value=\"$Index\"><input type=\"submit\" value=\"Delete\"></form></td>";
    echo "<td><form action=\"../forms/moveForm.php\" method=\"post\" target=\"_blank\"><input type=\"hidden\" name=\"Index\" value=\"$Index\"><input type=\"submit\" value=\"Move\"></form></td>";

    echo "</tr>";
    }
    ++$i;
  }
  echo "</table>";
  flush();

  $NumMissing2 = 0;
  $i=0;
  while ($i<$num2)
  {
    $Body = $content.mysql_result($allResult2,$i,"Body");
    $Exist = "false";
    $i2 = 0;
    while (((($i + $i2) < $num) OR (($i - $i2) >= 0)) AND ($Exist == "false"))
    {
      if (($i + $i2) < $num)
      {
      $Body2 = $content.mysql_result($allResult,$i + $i2,"Body");
      if ($Body2 == $Body)
        $Exist = "true";
      }
      if ((($i - $i2) >= 0) AND (($i - $i2) < $num))
      {
      $Body2 = $content.mysql_result($allResult,$i - $i2,"Body");
      if ($Body2 == $Body)
        $Exist = "true";
      }
      ++$i2;
    }

    if ($Exist == "false")
    {
      ++$NumMissing2;
    }
    ++$i;
  }

  echo "<br><br>$NumMissing genes of $num genes in the base genome do not exist in the compared genome.<br>";
  echo "$NumMissing2 genes of $num2 genes in the compared genome do not exist in the base genome.<br>";
  if (($NumMissing2 - $NumMissing) > 0) echo "...So there are " . ($NumMissing2 - $NumMissing) . " genes in the compared genome, which do not exist in the base genome and are not listed above.<br>";
  echo "<br>Comparison finished.";
  }

  $query="DROP TABLE `" . session_id() . "_comp" . "`;";
  mysql_query($query);
  mysql_close();
?>
<hr>
<a href="../interface.php"><b>Back to main screen</b></a>
</body>
</html>
