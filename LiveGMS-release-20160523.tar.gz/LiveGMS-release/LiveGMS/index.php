<html>
  <head>
    <title>LiveGMS</title>
  </head>
  <body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF">
  <p align="center">
  <a href="interface.php"><img border="0" src="logo.jpg"></a></p><br>
  <h2>What is LiveGMS?</h2>
  LiveGMS is a complete online and platform independent gene editor for Creatures 3 and Creatures Docking Station.<br>
  EasyGMS is a simplified wizard-like frontend to LiveGMS, that allows to perform a limited set of genetic modifications.<br>
  See the <a href="screenshots/index.php">screen shot section</a> for some examples.<br>
  <br>
  <p align="center"><table border="2" cellpadding="10"><tr><td bgcolor="#111111" valign="center" align="center"><font size="+2">Start <a href="interface.php">LiveGMS</a></font><br>
  <font size="+2">or use <a href="EasyGMS/">EasyGMS</a></font><br>
  <font size="+1">or read some <a href="documentation/index.php">documentation</a></font></td></tr></table></p>
  <h2>Latest changes/bugs</h2>
  <li>January 4th 2012: LiveGMS was moved to a new server. A few minor glitches got fixed.
  <br><br><br><br><br><hr>
  LiveGMS is provided by <a href="http://dmewes.com">Daniel Mewes</a>
  <br>LiveGMS is also available as source code on sourceforge.net: <a href="http://sourceforge.net/projects/livegms/">http://sourceforge.net/projects/livegms/</a>
  <br><br><font size="-2">
  Creature Labs and CyberLife are registered trademarks and the Creature Labs, CyberLife, Creatures, Creatures 2, Creatures 3 and Creatures Adventures logos are trademarks of CyberLife Technology Ltd in the United Kingdom and other countries. CyberLife, Creatures, Albia, and Norn are also trademarks of CyberLife Technology Ltd which may be registered in other countries.
  </font>
  </body>
</html>
