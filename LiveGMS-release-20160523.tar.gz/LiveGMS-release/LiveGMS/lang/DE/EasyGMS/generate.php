<?
 $title = 'EasyGMS - Vorschau';
 $content00 = 'Die folgende Vorschau ist nur eine Ann&auml;herung. Einige Sprites sind eventuell nicht auf dem Server installiert und werden hier als einfache ChiChi Sprites dargestellt.';
?>