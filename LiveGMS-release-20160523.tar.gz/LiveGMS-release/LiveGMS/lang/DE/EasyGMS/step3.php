<?
 $title = 'EasyGMS - Schritt 3';
 $headline00 = 'EasyGMS Schritt 3/3';
 $content00 = 'Gl&uuml;ckwunsch! Du hast erfolgreich deine eigene Kreatur angepasst.<br>
    Sie steht jetzt zum Download bereit.<br><br>
    Du kannst zwischen verschiedenen Dateiformaten w&auml;hlen.';
 $content01 = 'Agentendatei';
 $content02 = ' zum einf&uuml;gen der Kreatur ins Spiel mit Hilfe der Eierlegemaschine. Die Agentendatei muss in den Ordner &lt;Dein Creatures Ordner&gt;\Eigene Agenten f&uuml;r die Windowsversion des Spiels beziehungsweise /usr/local/games/[dockingstation / creatures3]/My Agents oder $HOME/[.dockingstation / .creatures3]/My Agents f&uuml;r die Linuxversion platziert werden.';
 $content03 = 'Genomdatei';
 $content04 = ' f&uuml;r die weitere Bearbeitung mit einem <a href="http://creatures.wikicities.com/wiki/Category:Genetic_Editors" target="_blank">Geneditor</a> deiner Wahl oder f&uuml;r die Erstellung eines eigenen Eieragenten.';
 $content05 = 'Wie im ersten Schritt versprochen, ist es nun auch m&ouml;glich das Genom jetzt in <a href="../interface.php">LiveGMS</a> zu editieren.<br>
    Um mehr &uuml;ber Genver&auml;nderung mit diesem Editor zu erfahren, empfehle ich einen Besuch im <a href="../documentation/">Official LiveGMS documentation center</a>.';
?>