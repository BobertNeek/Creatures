<?
 $title = 'EasyGMS - Schritt 1';
 $headline00 = 'EasyGMS Schritt 1/3';
 $content00 = 'Hallo! Ich bin Edu der Ettin. Ich war ein Geschenk von <a href="http://www.aliencreatures.de">Alien</a> an N1.<br>
    Weil es auf Dauer langweilig war st&auml;ndig in N1s Zimmer herumzusitzen, mache ich mich jetzt etwas n&uuml;tzlich.<br>
    Ich f&uuml;hre Besucher durch die drei Schritte von EasyGMS. <br><br>
    EasyGMS ist ein Gendienst f&uuml;r jedermann. Du kannst verschiedene Eigenschaften deiner Kreatur konfigurieren und sie dann als eine einfach zu verwendende Agentendatei f&uuml;r deine Creatures 3 oder Docking Station Eiermaschine herunterladen.<br><br>
    Um alles so einfach wie m&ouml;glich zu machen, werde ich jede Option erkl&auml;ren.<br>
    Wenn du noch mehr Dinge an deiner Kreatur ver&auml;ndern m&ouml;chtest, kannst du nach den drei Schritten von EasyGMS mit LiveGMS dem vollst&auml;ndigen online Geneditor weitermachen und alles ver&auml;ndern was du m&ouml;chtest. Leider kann ich dich dann nicht mehr begleiten, denn ich bin nur f&uuml;r EasyGMS zust&auml;ndig.<br>';
 $content01 = 'Dieser erste Schritt dient dazu, einen Ausgangspunkt f&uuml;r die weitere Anpassung auszuw&auml;hlen.<br>
      Dazu gibt es zwei unterschiedliche M&ouml;glichkeiten. Entweder kannst du eines der nachfolgenden Standardgenome ausw&auml;hlen oder dein eigenes hochladen. Die erste M&ouml;glichkeit ist einfacher und au&szlig;erdem der empfohlene Weg. Die aufgef&uuml;hrten Genome wurden auf ihre Funktionsf&auml;higkeit hin getestet.<br><br>
      Vielleicht fragst du jetzt welchen Einfluss deine Auswahl auf die sp&auml;tere Kreatur haben wird?<br>
      Allgemein werden einige der Eigenheiten des ausgew&auml;hlten Genoms ihren Weg in die fertige Kreatur finden. Wenn du zum Beispiel ein Ettingenom ausw&auml;hlst, wird die Kreatur jede erreichbare Maschine stehlen (so bin ich auch an die Diskette auf dem Foto gekommen). Andere spezifische Eigenschaften sind wie viel Energie die Kreatur aus Tieren oder Pflanzen ziehen kann. Bondi Norns zum Beispiel werden Fish ebensoviel wie K&auml;se oder Karotten essen, w&auml;hrend Treehugger Norns diese h&ouml;chstens anfassen werden um mit ihnen zu spielen.<br><br>
      Wenn du ein eigenes Genom verwendest, ist es m&ouml;glich nur die Farbe oder die Sprites f&uuml;r die einzelnen K&ouml;rperteile zu ver&auml;ndern. Um ein Genom aus dem Spiel zu laden, brauchst du erst einmal den "genetic moniker" Namen zu dem gew&uuml;nschen Norn. Du kannst diesen Namen bekommen, indem du die Hand in den Infomodus schaltest (dr&uuml;cke F1), mit der rechten Maustaste auf den Norn klickst und zu dem Norn-Tab wechselst. Das Genom zu diesem Norn kannst du f&uuml;r Windows im Ordner &lt;DEIN-CREATURES-ORDNER&gt;\My Worlds\&lt;WORLD-NAME&gt;\Genetics oder bei der Linuxversion des Spiels im Ordner $HOME/[.dockingstation / .creatures3]/My Worlds/&lt;WORLD-NAME&gt;/Genetics finden. Du kannst auch die Genome zus&auml;tzlich installierter Rassen verwenden. Diese Dateien findest du unter Windows im Ordner &lt;DEIN-CREATURES-ORDNER&gt;\Genetics und unter Linux in $HOME/[.dockingstation / .creatures3]/Genetics oder /usr/local/games/[dockingstation / creatures3]/Genetics.
      <br><br>';
 $content02 = 'W&auml;hle jetzt ein Genom';
 $content03 = '...oder lade dein eigenes hoch';
 $button00 = 'Zu Schritt 2';
?>