<?
 $title = 'EasyGMS - Step 2';
 $headline00 = 'EasyGMS step 2/3';
 $content00 = 'This step is about customising the creature. You can select different colors, Sprites and configure your creature\'s character and habits.';
 $content01 = 'Please pick a color for your creature. Notice that the final color of the creature will also be modified by the "rotation" and "swap" settings below and that each sprite has its own color, too.';
 $content02 = 'Each body part of a creature may have its own Sprite. A Sprite is principally a set of images for each pose. The fact that Grendels and Norns look different can be leaded back to their different Sprite sets. The same is true for most Norn breeds and Ettins. You may now mix the sprites you like to obtain an indiviual looking creature. To get an impression of how the selected sprites will look in the game, you can use the "Preview" button below.<br><br>
      Please bear in mind that only installed Sprites will be shown correctly on your PC. Creatures 3 comes with the Bengal, Bruin, Civet, Ettin and Grendel sprites while Docking Station only has the ChiChi Sprites included. However, loads of Sprites can be <a href="http://creatures.wikicities.com/wiki/Category:C3/DS_Norn_Breeds" target="_blank">downloaded from the Web</a> for free and a few more are available for purchase from <a href="http://www.gamewaredevelopment.co.uk/cart/customer/home.php?cat=1" target="_blank">Creature Labs</a>.';
 $content03 = 'Head:';
 $content04 = 'Body:';
 $content05 = 'Arms:';
 $content06 = 'Legs:';
 $content07 = 'Tail:';
 $content08 = 'The two pigment bleed values "rotation" and "swap" are somewhat complicated to understand and even more complicated to imagine. Since detailed information about this topic and pigmentation in Creatures in general is available at other places in the web (e.g. <a href="http://www.gamewaredevelopment.co.uk/cdn/cdn_more.php?CDN_article_id=11" target="_blank">"How Pigmentation works"</a> in the CDN), I only give a brief explaination here: The rotation value makes the three ground colors rotate in the way -&gt;red&lt;-&gt;green&lt;-&gt;blue&lt;-, while the swap value results in a specific amount of red and blue pigment\'s intensity swapped.<br>
    Happily you don\'t really have to worry about the inner working of Creature\'s pigmentation, since you can test a few combinations using the Preview button.';
 $content09 = 'Rotation:';
 $content10 = 'Swap:';
 $content11 = 'Here you can specify a name for the Egg Creator. This text will be shown there to identify the created Eggs. I recommend a short and descriptive name. Two Egg agents with the same name may result in undesireable behaviour of the Egg Creator.';
 $content12 = 'The next setting affects the aging of the creature. A lower settings will result in faster growing and a shorter lifetime, while a higher value makes the creature live longer and grow more slowly. The total lifetime goes from a few minutes with the lowest setting up to about 20 hours with the highest one. However, diseases and injuries may still lead to an earlier death.';
 $content13 = 'To influence the character and the manner of your creature, it is possible to reduce or increase the production of the different drive chemicals. An increased production of boredom for example will lead to a creature, which is more active and plays more often than an average one to satisfy this drive. In the same way a creature with less production of tiredness and sleepiness will not sleep very often. Please keep in mind that reducing the production of pain does not reduce the injury a Norn takes from a furious Grendel and a lowered production of the Hunger for sth. drives does not reduce the amount of food the creature must eat to stay healthy!<br>
      Also notice that this setting may have greater effect for some drives than for some others, depending on the way each drive is produced.';
 $button00 = 'Preview';
 $button01 = 'To step 3';
?>