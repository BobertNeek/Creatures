<?
 $title = 'EasyGMS - Step 3';
 $headline00 = 'EasyGMS step 3/3';
 $content00 = 'Congratulations! You have successfully customised your creature.<br>
    It is ready for download now.<br><br>
    You can choose between different file formats.';
 $content01 = 'Agent file';
 $content02 = ' for injection of the creature into the game using the Egg Creator. The Agent file is to be placed in the path &lt;YOUR-CREATURE-FOLDER&gt;\My Agents for the Windows version of the game or /usr/local/games/[dockingstation / creatures3]/My Agents resp. $HOME/[.dockingstation / .creatures3]/My Agents for the Linux version.';
 $content03 = 'Genome file';
 $content04 = ' for further editing with a <a href="http://creatures.wikicities.com/wiki/Category:Genetic_Editors" target="_blank">gene editor</a> of your choice or creation of your own Egg Agent.';
 $content05 = 'As promised in step one, it is also possible to edit the genome in <a href="../interface.php">LiveGMS</a> now.<br>
    To learn more about genetic engineering using this editor, I recommend to visit the <a href="../documentation/">Official LiveGMS documentation center</a>.';
?>