<?
 $title = 'EasyGMS - Step 1';
 $headline00 = 'EasyGMS step 1/3';
 $content00 = 'Hello! I am Edu the Ettin. I was a gift from <a href="http://www.aliencreatures.de">Alien</a> to N1.<br>
    \'Cause it was quite boring to just sit around in N1\'s room, I\'m doing something useful now.<br>
    I guide visitors through the three steps of EasyGMS. <br><br>
    EasyGMS is the genetic service usable by everyone. You can configure different attitudes of your creature and download it as a simple to use Agentfile for your Creatures 3 or Docking Station egg maker.<br><br>
    To make everything as easy as possible, I will explain every option.<br>
    If you want to tweak more traits of your creature, it is possible to continue after the three steps of EasyGMS and modify absolutely everything you want in LiveGMS, the fully featured online genetic editor. Sadly without me then, since I am only responsible for EasyGMS.<br>';
 $content01 = 'This first step is about choosing a starting point for doing the customization.<br>
      There are two possible options here. You can either choose one of the following default genomes or upload your own one. The first way is the easiest and recommended one. The listed genomes are tested to be working.<br><br>
      So you may ask how your selection will affect your final creature?<br>
      Basically some of each genome\'s individual traits will get their way into the final creature. For example if you choose an Ettin genome, the created creature will steal every machine it can reach (that\'s how I got the floppy disk on the photo). Other traits are how much energy a creature can get of critters or plants. Bondi Norns for example will eat fishes just as much as cheese or carrots, while Treehuggers will only touch them to play with them.<br><br>
      If using one of your own genomes, it is possible to just change the color of a Norn you\'ve bred or change each body part\'s sprites. To load a genome from the game, you must first find your creature\'s genetic moniker. You can get that by changing the hand into help mode (press F1), right-clicking the creature and switching to the Norn tab. The genome for the creature can be found in the folder &lt;YOUR-CREATURE-FOLDER&gt;\My Worlds\&lt;WORLD-NAME&gt;\Genetics or $HOME/[.dockingstation / .creatures3]/My Worlds/&lt;WORLD-NAME&gt;/Genetics in the Linux versions of the game. You may also use the genomes of additionally installed breeds. These files are located in the path &lt;YOUR-CREATURE-FOLDER&gt;\Genetics for the Windows versions and $HOME/[.dockingstation / .creatures3]/Genetics or /usr/local/games/[dockingstation / creatures3]/Genetics for Linux.
      <br><br>';
 $content02 = 'Now select a genome';
 $content03 = '...or upload your own one';
 $button00 = 'To step 2';
?>