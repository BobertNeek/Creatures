<?
 $title = 'EasyGMS - Preview';
 $content00 = 'The following preview is only an approximation. Some sprite files may not be installed on the server and will be displayed as standard ChiChi sprites below.';
?>