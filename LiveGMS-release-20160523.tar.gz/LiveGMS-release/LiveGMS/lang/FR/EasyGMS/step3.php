<? $title = 'EasyGMS - Etape 3'; 
$headline00 = 'EasyGMS &eacute;tape 3/3'; 
$content00 = 'F&eacute;licitations! Vous avez customis&eacute; votre Cr&eacute;ature.<br>
Elle est pr&ecirc;te a &ecirc;tre t&eacute;l&eacute;charg&eacute;e..<br>
<br>
Vous pouvez choisir entre plusieurs formats de fichier.'; $content01 = 'Fichier 
Agent '; 
$content02 = ' pour l\'injection dans le jeu avec la pondeuse. Le fichier 
Agent doit &ecirc;tre plac&eacute; dans &lt;votre r&eacute;pertoire Creatures&gt;\My 
Agents (Mes Agents dans C3) (pour la version Windows du jeu ou /usr/local/games/[dockingstation 
/ creatures3]/My Agents resp. $HOME/[.dockingstation / .creatures3]/My Agents 
for the Linux version.'; 
$content03 = 'Fichier g&eacute;n&eacute;tique'; 
$content04 = ' pour une &eacute;dition plus pouss&eacute;e avec l\'<a href="http://creatures.wikicities.com/wiki/Category:Genetic_Editors" target="_blank">&eacute;diteur 
de g&eacute;nome</a> de votre choix ou pour la cr&eacute;ation de votre propre 
Agent Oeuf.'; 
$content05 = 'Comme promis a la premi&egrave;re &eacute;tape, il 
est aussi possible d\&eacute;diter le g&eacute;nome dans <a href="../interface.php">LiveGMS</a> 
maintenant.<br>
Pour en apprendre plus sur la g&eacute;n&eacute;tique en utilisant cet &eacute;diteur, 
je vous invite a visiter la <a href="../documentation/">documentation officielle 
du LiveGMS</a>.'; ?>