<?
$title = 'EasyGMS - Etape 1'; 
$headline00 = 'EasyGMS &eacute;tape 1/3'; 
$content00 = 'Bonjour! Je suis Edu L\'Ettin.Je suis un cadeau de la part d\'<a href="http://www.aliencreatures.de">Alien</a> 
&agrave; N1.<br>
  Parce que je m\'ennuyais dans la chambre de N1, j\'ai d&eacute;cid&eacute; de 
  faire quelque chose d\'utile maintenant.<br>
  Je guide les visiteurs au travers des trois &eacute;tapes d\'EasyGMS. <br>
  <br>
  EasyGMS est un service g&eacute;n&eacute;tique utilisable par tous. 
  Vous pouvez &eacute;diter diff&eacute;rents param&egrave;tres de votre cr&eacute;ature 
  et la t&eacute;l&eacute;charger comme un simple fichier agent utilisable dans 
  la pondeuse de Creatures3 ou de Docking Station.<br>
  <br>
  Afin de rendre ceci aussi simple que possible, j\'expliquerai chaque option.<br>
Si vous voulez &eacute;diter plus de param&egrave;tres de votre cr&eacute;ature, 
il est possible de continuer apr&egrave;s les trois &eacute;tapes d\'EasyGMS 
et de modifier tout ce que vous voulez avec le LiveGMS, l\'&eacute;diteur g&eacute;n&eacute;tique 
online. Malheureusement sans moi, snif, car je ne suis responsable que d\'EasyGMS.'; 

$content01 = 'La premi&egrave;re &eacute;tape consiste &agrave; choisir un point 
de d&eacute;part &agrave; la customisation. Vous avez deux choix. Soit choisir 
un des g&eacute;nomes propos&eacute;s par defaut soit uploader un des v&ocirc;tres. 
Le premier choix est le plus facile et recommand&eacute;. Les g&eacute;nomes list&eacute;s 
sont test&eacute;s et fonctionnels.<br>
  <br>
Ainsi vous vous demandez comment votre choix affectera votre cr&eacute;ature?<br>
Fondamentalement certains des comportements sp&eacute;cifiques du g&eacute;nome 
choisi influeront sur votre cr&eacute;ature. Par exemple si vous optez pour un 
g&eacute;nome d\'Ettin, la cr&eacute;ature cr&eacute;&eacute;e volera chaque machine 
qu\'elle pourra atteindre (Comment croyez vous que j\'ai obtenu la disquette sur 
la photo). D\'autres comportements sont par exemple, combien d\'&eacute;nergie, 
une cr&eacute;ature retira d\'une bestiole ou d\'une plante. Les Bondi Norns par 
exemple mangeront des poissons comme d\'autres mangent du fromage ou des carottes, 
alors que les Treehuggers se contenteront de les toucher pour jouer avec eux.<br>
  <br>
Si vous utilisez un de vos g&eacute;nomes, il est possible de ne changer que la 
couleur ou les sprites de chaque partie du corps. Pour uploader un g&eacute;nome 
&agrave; partir du jeu, vous devez en premier trouver le nom du g&eacute;nome 
de votre cr&eacute;ature, appuyez sur F1 dans le jeu puis click droit sur la cr&eacute;ature, 
allez sur l\'onglet repr&eacute;sentant un Norn et notez le nom. Le g&eacute;nome 
de votre cr&eacute;ature se trouve dans le r&eacute;pertoire &lt;votre r&eacute;pertoire 
Creatures &gt;\My Worlds (Mes Mondes dans C3)\&lt;nom de votre monde&gt;\Genetics 
ou $HOME/[.dockingstation / .creatures3]/My Worlds/&lt;nom de votre monde&gt;/Genetics 
pour les versions Linux. Vous pouvez aussi utiliser le g&eacute;nome d\'une race 
que vous avez install&eacute;. Ces fichiers sont situ&eacute;s dans &lt;votre 
r&eacute;pertoire Creatures&gt;\Genetics pour la version Windows et $HOME/[.dockingstation 
/ .creatures3]/Genetics ou /usr/local/games/[dockingstation / creatures3]/Genetics 
pour la version Linux. <br>
  <br>'; 
$content02 = 'S&eacute;lectionnez un g&eacute;nome'; 
$content03 = '...ou uploadez le v&ocirc;tre'; 
$button00 = 'Etape 2'; 
?> 