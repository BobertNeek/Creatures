<? $title = 'EasyGMS - Etape 2'; 
 $headline00 = 'EasyGMS &eacute;tape 2/3'; 
 $content00 = 'Cette &eacute;tape concerne la customisation de la cr&eacute;ature. Vous pouvez 
s&eacute;lectionner diff&eacute;rentes couleurs, sprites, modifier le caract&egrave;re 
et les habitudes de votre cr&eacute;ature.'; 
$content01 = 'Choisissez une couleur 
pour votre cr&eacute;ature. Notez que la couleur de votre cr&eacute;ature sera 
aussi modifi&eacute;e par les r&eacute;glages de "rotation" et "swap" ci-dessous 
et que chaque sprite a aussi sa propre couleur.'; 
$content02 = 'Chaque partie 
du corps d\'une cr&eacute;ature peut avoir son propre sprite. Un sprite est une 
image de chaque pose. Vous pouvez maintenant mixer les sprites selon vos d&eacute;sirs 
afin d\'obtenir une cr&eacute;ature originale. Pour avoir un apercu de ce que vous 
obtiendrez dans le jeu, utilisez le bouton &quot;pr&eacute;visualiser&quot; ci-dessous.<br>
  <br>
Seuls les sprites install&eacute;s (les races de base et celles que vous avez 
install&eacute;es) dans votre jeu seront visibles dans celui-ci. Les Bengal, Bruin, 
Civet, Ettin et Grendel sont inclus dans Creatures3 et les Chichi dans Docking 
Station. D\'autres races peuvent &ecirc;tre <a href="http://creatures.wikicities.com/wiki/Category:C3/DS_Norn_Breeds" target="_blank">t&eacute;l&eacute;charg&eacute;es 
sur le Net</a> gratuitement et les races officielles sont disponibles � l\'achat 
chez <a href="http://www.gamewaredevelopment.co.uk/cart/customer/home.php?cat=1" target="_blank">Creature 
Labs</a>.'; 
$content03 = 'T&ecirc;te:'; 
$content04 = 'Corps:'; 
$content05 = 'Bras:'; 
$content06 = 'Jambes:'; 
$content07 = 'Queue:'; 
$content08 = 'Les deux valeurs 
de pigment bleed "rotation" et"swap" sont compliqu&eacute;es &agrave; comprendre 
et encore plus &agrave; imaginer. Puisque des informations d&eacute;taill&eacute;es, 
&agrave; ce propos et sur la pigmentation dans Creatures, sont diponibles sur 
le Net (par exemple <a href="http://www.gamewaredevelopment.co.uk/cdn/cdn_more.php?CDN_article_id=11" target="_blank">"Comment 
fonctionne la pigmentation (en anglais)"</a> sur le CDN), Je ne donnerais qu\'une 
br&egrave;ve explication ici: La valeur de &quot;rotation&quot; d&eacute;finit 
le cycle des 3 couleurs de bases dans le sens -&gt;rouge&lt;-&gt;vert&lt;-&gt;bleu&lt;-, 
alors que la valeur &quot;swap&quot; permet de sp&eacute;cifier l\'intensit&eacute; 
de la permutation de pigment bleu et rouge. Heureusement vous n\'avez pas besoin 
de vous pr&eacute;occuper en d&eacute;tail du fonctionnement de la pigmentation 
dans Creatures puisque vous pouvez tester diff&eacute;rentes combinaisons en 
utilisant la bouton &quot;pr&eacute;visualiser&quot;.<br>'; 
$content09 = 'Rotation:'; 
$content10 = 'Swap:'; 
$content11 = 'Ici vous pouvez 
sp&eacute;cifier un nom pour la pondeuse. Ce texte s\'affichera l&agrave; pour 
identifier les oeufs cr&eacute;&eacute;s. Je recommande un nom court et descriptif. 
Deux agents avec le m&ecirc;me nom peuvent cr&eacute;er un dysfonctionnement de 
la pondeuse.'; 
$content12 = 'L\'option suivante affecte le vieillissement de la 
cr&eacute;ature. Une valeur basse donnera une croissance rapide et une courte 
dur&eacute;e de vie alors qu\'une valeur haute donnera une croissance lente et 
une longue dur&eacute;e de vie. La dur&eacute;e de vie totale ira de quelques 
minutes pour la valeur la plus basse &agrave; une vingtaine d\'heures pour la 
valeur la plus haute. Cependant les maladies et les blessures peuvent conduire 
&agrave; une mort pr&eacute;matur&eacute;e.'; 
$content13 = 'Pour influencer le 
caract&egrave;re et le comportement de votre cr&eacute;ature, il est possible 
de r&eacute;duire ou d\'augmenter la production de diff&eacute;rentes substances 
chimiques de "commande". Une production &quot;d\'ennui&quot; &eacute;lev&eacute;e par exemple, 
conduira votre cr&eacute;ature &agrave; &ecirc;tre plus active et &agrave; jouer 
plus que de normal afin de satisfaire ce besoin. De m&ecirc;me qu\'une cr&eacute;ature, 
avec une production de &quot;fatigue&quot; et de &quot;somnolence&quot; moindre, 
dormira moins souvent que de normal. Cependant gardez &agrave; l\'esprit qu\'une 
valeur moindre de la production de &quot;douleur&quot; ne r&eacute;duira pas pour 
autant les dommages engendr&eacute;s par un combat avec un Grendel furieux ainsi 
qu\'une production r&eacute;duite de &quot;faim de ...&quot; ne r&eacute;duira 
pas la quantit&eacute; de nourriture qu\'une cr&eacute;ature doit ing&eacute;rer 
pour rester en pleine forme!<br>
Notez aussi que cette option peut avoir un plus grand effet pour certaines &quot;commandes&quot; 
que pour d\'autres, selon la fa&ccedil;on dont la "commande" est produite.'; 
$button00 = 'Pr&eacute;visualiser'; 
$button01 = 'Etape 3'; ?>