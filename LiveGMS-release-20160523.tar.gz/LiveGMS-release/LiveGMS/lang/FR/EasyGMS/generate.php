<? $title = 'EasyGMS - Pr&eacute;visualisation'; 
$content00 = 'Cette pr&eacute;visualisation est une approximation, certains sprites peuvent ne pas &ecirc;tres install&eacute;s sur le serveur et seront affich&eacute;s comme des sprites de Chichi par d&eacute;faut..'; 
?>