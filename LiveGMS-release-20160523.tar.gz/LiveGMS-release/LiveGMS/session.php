<?
session_start();
$ssid = session_id();
$currentPath = getcwd();
if (strstr($currentPath, "EasyGMS"))
  $currentPath .= "/..";
if (!file_exists($currentPath . "/tmp/$ssid"))
{
  mkdir ($currentPath . "/tmp/$ssid");
  mysql_query ("INSERT INTO sessions (`timestamp`, `ssid`) VALUES (NULL, '" . mysql_real_escape_string($ssid) . "')");
}
else
  mysql_query ("UPDATE sessions SET `timestamp` = NULL WHERE `ssid` = '" . mysql_real_escape_string($ssid) . "'");

$sessions = mysql_query("SELECT * FROM sessions WHERE `timestamp` < DATE_SUB(NOW(),INTERVAL 1 DAY)");
while ($row = mysql_fetch_row($sessions))
{
  mysql_query("DELETE FROM sessions WHERE `ssid` = '" . mysql_real_escape_string($row[0]) . "'");
  mysql_query("DROP TABLE `" . mysql_real_escape_string($row[0]) . "`");
  system ("rm -f " . escapeshellarg($currentPath . "/tmp/" . $row[0]) . "/* > /dev/null 2>&1");
  system ("rmdir " . escapeshellarg($currentPath . "/tmp/" . $row[0]) . " > /dev/null 2>&1");
}

// Get/set the current language
global $language;
$language = $_GET['language'];
if (!$language)
  $language = $_SESSION['language'];
if (!$language)
  $language = "EN";
$language = str_replace(".", "", $language);
$language = str_replace("/", "", $language);
$language = str_replace("\\", "", $language);
$_SESSION['language'] = $language;
?>
