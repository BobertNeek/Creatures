<?
include ("admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

include ("session.php");

extract($_GET, EXTR_PREFIX_ALL, 'g');
?>
<html>
  <head>
    <title>LiveGMS</title>
  </head>
  <body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF">
    <p align="center"><img src="logo.jpg"></p>
    <hr>
    <table border="0">
    <tr>
    <form action="ea/perform.php" method="post" enctype="multipart/form-data">
      <td><input type="file" name="geneFile" size=50></td>
      <input type="hidden" name="action" value="readfile">
      <input type="hidden" name="MAX_FILE_SIZE" value="500000">
      <td><input type="submit" value="Load genome file"></td>
    </form>
    </tr>
    <tr>
    <form action="ea/perform.php" method="post">
      <td></td>
      <input type="hidden" name="action" value="writefile">
      <td><input type="submit" value="Save genome file"></td>
    </form>
    </tr>
    </table>
    <hr>
    <table border="0">
    <tr>
    <form action="interface/listDifferences.php" method="post" enctype="multipart/form-data">
      <td><input type="file" name="geneFile" size=50></td>
      <input type="hidden" name="MAX_FILE_SIZE" value="500000">
      <td><input type="submit" value="Compare gene files"></td>
    </form>
    </tr>
    </table>
    <hr>
<?
include("interface/list.php");
if ($g_orderBy == "")
  $g_orderBy = "Index";
if ($g_startNum == "")
  $g_startNum = 1;

echo "<table border=\"0\" width=\"100%\">
    <tr><td align=\"center\"><form action=\"interface.php\" method=\"get\">
    Goto gene: <input type=\"test\" name=\"startNum\" size=\"4\" maxlength=\"4\" value=\"" . ($g_startNum + 100) . "\">
    <input type=\"hidden\" name=\"orderBy\" value=\"$g_orderBy\">
    <input type=\"submit\" value=\"Go!\">
    </form></td>
    <td align=\"center\">
    <form action=\"interface/checkGenome.php\" method=\"get\">
    <input type=\"submit\" value=\"Check genome\">
    </form></td>
    <td align=\"center\">
    <form action=\"forms/createForm.php\" method=\"get\" target=\"_blank\">
    <input type=\"submit\" value=\"Create gene\">
    </form></td>
    </tr>
    </table>
    <hr>";
listGenome(session_id(), mysql_real_escape_string($g_orderBy), mysql_real_escape_string($g_startNum - 1));
?>
  </body>
</html>
<?
mysql_close();
?>
