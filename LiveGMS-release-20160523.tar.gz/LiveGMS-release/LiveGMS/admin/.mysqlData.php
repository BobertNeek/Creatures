<?
// Please replace with your own MySQL user name and password
$user="USERNAME";
$password="PASSWORD";
$database="LiveGMS";
$server="localhost";
?>
