<?
$xSize = 350;
$ySize = 350;

$image = imagecreatetruecolor($xSize, $ySize);
imagecolortransparent($image, 0);

$red = $_GET['r'];
$green = $_GET['g'];
$blue = $_GET['b'];
$swap = (6 * $_GET['sw'] + 128) / 7;
$rot = (6 * $_GET['ro'] + 128) / 7;

$head_species = $_GET['hs'];
$body_species = $_GET['bs'];
$arms_species = $_GET['as'];
$legs_species = $_GET['ls'];
$tail_species = $_GET['ts'];
$head_slot = $_GET['hsl'];
$body_slot = $_GET['bsl'];
$arms_slot = $_GET['asl'];
$legs_slot = $_GET['lsl'];
$tail_slot = $_GET['tsl'];

$species = array(
    'c' => $legs_species,
    'd' => $legs_species,
    'e' => $legs_species,
    'i' => $arms_species,
    'j' => $arms_species,
    'm' => $tail_species,
    'n' => $tail_species,
    'b' => $body_species,
    'a' => $head_species,
    'f' => $legs_species,
    'g' => $legs_species,
    'h' => $legs_species,
    'k' => $arms_species,
    'l' => $arms_species,
);

$slot = array(
    'c' => $legs_slot,
    'd' => $legs_slot,
    'e' => $legs_slot,
    'i' => $arms_slot,
    'j' => $arms_slot,
    'b' => $body_slot,
    'a' => $head_slot,
    'f' => $legs_slot,
    'g' => $legs_slot,
    'h' => $legs_slot,
    'k' => $arms_slot,
    'l' => $arms_slot,
    'm' => $tail_slot,
    'n' => $tail_slot,
);


$koerperteile = array(
    'c',
    'd',
    'e',
    'i',
    'j',
    'b',
    'f',
    'g',
    'h',
    'k',
    'l',
    'm',
    'n',
    'a',
);

foreach ($koerperteile as $koerperteil)
  if(!file_exists("Body Data/" . $koerperteil . $species[$koerperteil]. "4" . $slot[$koerperteil] . ".att"))
  {
    $species[$koerperteil] = '0';
    $slot[$koerperteil] = 'd';
  }


$fhandle = fopen("Body Data/b" . $species['b']. "4" . $slot['b'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_body_x = array();
$att_body_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_body_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_body_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/a" . $species['a'] . "4" . $slot['a'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_head_x = array();
$att_head_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_head_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_head_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/c" . $species['c'] . "4" . $slot['c'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_lUpperLeg_x = array();
$att_lUpperLeg_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_lUpperLeg_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_lUpperLeg_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/f" . $species['f'] . "4" . $slot['f'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_rUpperLeg_x = array();
$att_rUpperLeg_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_rUpperLeg_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_rUpperLeg_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/i" . $species['i'] . "4" . $slot['i'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_lUpperArm_x = array();
$att_lUpperArm_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_lUpperArm_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_lUpperArm_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/k" . $species['k'] . "4" . $slot['k'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_rUpperArm_x = array();
$att_rUpperArm_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_rUpperArm_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_rUpperArm_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/m" . $species['m'] . "4" . $slot['m'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_upperTail_x = array();
$att_upperTail_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_upperTail_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_upperTail_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/n" . $species['n'] . "4" . $slot['n'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_lowerTail_x = array();
$att_lowerTail_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_lowerTail_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_lowerTail_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/j" . $species['j'] . "4" . $slot['j'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_lLowerArm_x = array();
$att_lLowerArm_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_lLowerArm_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_lLowerArm_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/l" . $species['l'] . "4" . $slot['l'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_rLowerArm_x = array();
$att_rLowerArm_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_rLowerArm_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_rLowerArm_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/d" . $species['d'] . "4" . $slot['d'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_lLowerLeg_x = array();
$att_lLowerLeg_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_lLowerLeg_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_lLowerLeg_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/g" . $species['g'] . "4" . $slot['g'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_rLowerLeg_x = array();
$att_rLowerLeg_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_rLowerLeg_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_rLowerLeg_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/e" . $species['e'] . "4" . $slot['e'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_lFoot_x = array();
$att_lFoot_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_lFoot_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_lFoot_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}

$fhandle = fopen("Body Data/h" . $species['h'] . "4" . $slot['h'] . ".att", "r");
$bodyData = fgets($fhandle);
fclose($fhandle);

$att_rFoot_x = array();
$att_rFoot_y = array();
while (strlen($bodyData) > 2)
{
  array_push($att_rFoot_x, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
  array_push($att_rFoot_y, substr($bodyData, 0, strpos($bodyData, " ")));
  $bodyData = substr($bodyData, strpos($bodyData, " ") + 1);
}


$att_x = array(
    'a' => ($att_body_x[0] - $att_head_x[0]),
    'i' => ($att_body_x[3] - $att_lUpperArm_x[0]),
    'k' => ($att_body_x[4] - $att_rUpperArm_x[0]),
    'c' => ($att_body_x[1] - $att_lUpperLeg_x[0]),
    'd' => ($att_body_x[1] - $att_lUpperLeg_x[0]) + ($att_lUpperLeg_x[1] - $att_lLowerLeg_x[0]),
    'e' => ($att_body_x[1] - $att_lUpperLeg_x[0]) + ($att_lUpperLeg_x[1] - $att_lLowerLeg_x[0]) + ($att_lLowerLeg_x[1] - $att_lFoot_x[0]),
    'f' => ($att_body_x[2] - $att_rUpperLeg_x[0]),
    'g' => ($att_body_x[2] - $att_rUpperLeg_x[0]) + ($att_rUpperLeg_x[1] - $att_rLowerLeg_x[0]),
    'h' => ($att_body_x[2] - $att_rUpperLeg_x[0]) + ($att_rUpperLeg_x[1] - $att_rLowerLeg_x[0]) + ($att_rLowerLeg_x[1] - $att_rFoot_x[0]),
    'm' => ($att_body_x[5] - $att_upperTail_x[0]),
    'n' => ($att_body_x[5] - $att_upperTail_x[0]) + ($att_upperTail_x[1] - $att_lowerTail_x[0]),
    'j' => ($att_body_x[3] - $att_lUpperArm_x[0]) + ($att_lUpperArm_x[1] - $att_lLowerArm_x[0]),
    'l' => ($att_body_x[4] - $att_rUpperArm_x[0]) + ($att_rUpperArm_x[1] - $att_rLowerArm_x[0]),
    'b' => 0
);

$att_y = array(
    'a' => ($att_body_y[0] - $att_head_y[0]),
    'i' => ($att_body_y[3] - $att_lUpperArm_y[0]),
    'k' => ($att_body_y[4] - $att_rUpperArm_y[0]),
    'c' => ($att_body_y[1] - $att_lUpperLeg_y[0]),
    'd' => ($att_body_y[1] - $att_lUpperLeg_y[0]) + ($att_lUpperLeg_y[1] - $att_lLowerLeg_y[0]),
    'e' => ($att_body_y[1] - $att_lUpperLeg_y[0]) + ($att_lUpperLeg_y[1] - $att_lLowerLeg_y[0]) + ($att_lLowerLeg_y[1] - $att_lFoot_y[0]),
    'f' => ($att_body_y[2] - $att_rUpperLeg_y[0]),
    'g' => ($att_body_y[2] - $att_rUpperLeg_y[0]) + ($att_rUpperLeg_y[1] - $att_rLowerLeg_y[0]),
    'h' => ($att_body_y[2] - $att_rUpperLeg_y[0]) + ($att_rUpperLeg_y[1] - $att_rLowerLeg_y[0]) + ($att_rLowerLeg_y[1] - $att_rFoot_y[0]),
    'm' => ($att_body_y[5] - $att_upperTail_y[0]),
    'n' => ($att_body_y[5] - $att_upperTail_y[0]) + ($att_upperTail_y[1] - $att_lowerTail_y[0]),
    'j' => ($att_body_y[3] - $att_lUpperArm_y[0]) + ($att_lUpperArm_y[1] - $att_lLowerArm_y[0]),
    'l' => ($att_body_y[4] - $att_rUpperArm_y[0]) + ($att_rUpperArm_y[1] - $att_rLowerArm_y[0]),
    'b' => 0
);

//echo "Head at " . $att_x['a'] . ", " . $att_y['a'];

foreach($koerperteile as $koerperteil)
{
    $File = "Images/$koerperteil" . $species[$koerperteil] . "4" . $slot[$koerperteil] . '_0.png';
    $bild = @imagecreatefrompng($File);
    $ImgNfo = @getimagesize($File);
	
    @imagecopyresampled(
    $image, 
    $bild, 
    $att_x[$koerperteil] * 2 + 75, 
    $att_y[$koerperteil] * 2 + 75, 
    0, 
    0, 
    $ImgNfo[0] * 2, 
    $ImgNfo[1] * 2, 
    $ImgNfo[0], 
    $ImgNfo[1]);
}

for ($x = 0; $x < $xSize; $x++)
  for ($y = 0; $y < $ySize; $y++)
  {
    $color = imagecolorat($image, $x, $y);
    if ($color != 0)
    {
      $r = ($color >> 16) & 0xFF;
      $g = ($color >> 8) & 0xFF;
      $b = $color & 0xFF;
    
      $r = ($r + $red) / 2;
      $g = ($g + $green) / 2;
      $b = ($b + $blue) / 2;

      if ((($rot - 128) / 128) > 0)
      {
        $r2 = $r + $g * (($rot - 128) / 128) - $r * (($rot - 128) / 128);
        $g2 = $g + $b * (($rot - 128) / 128) - $g * (($rot - 128) / 128);
        $b2 = $b + $r * (($rot - 128) / 128) - $b * (($rot - 128) / 128);
      }
      else
      {
        $r2 = $r + $b * -(($rot - 128) / 128) - $r * -(($rot - 128) / 128);
        $g2 = $g + $r * -(($rot - 128) / 128) - $g * -(($rot - 128) / 128);
        $b2 = $b + $g * -(($rot - 128) / 128) - $b * -(($rot - 128) / 128);
      }

      $r = $r2;
      $b = $b2;

      if ((($swap - 128) / 128) > 0)
      {
        $r2 = $r + $b * (($swap - 128) / 128) - $r * (($swap - 128) / 128);
        $b2 = $b + $r * (($swap - 128) / 128) - $b * (($swap - 128) / 128);
      }
      else
      {
        $r2 = $r + $b * -(($swap - 128) / 128) - $r * -(($swap - 128) / 128);
        $b2 = $b + $r * -(($swap - 128) / 128) - $b * -(($swap - 128) / 128);
      }
            
      
      $color = imagecolorallocate($image, $r2, $g2, $b2);
      imagesetpixel($image, $x, $y, $color);
    }
  }

header('Content-Type: image/png');
imagepng($image);

exit();
?>