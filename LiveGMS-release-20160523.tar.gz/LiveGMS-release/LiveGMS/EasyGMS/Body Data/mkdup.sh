#sh
for i in a b c d e f g h i j k l m n
do 
  cp $i$14$2.att $i$14$3.att
done

