#sh
cp "$1"/?$24$3.att ./

