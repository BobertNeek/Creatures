<?
include ("../ea/readfile.php");
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

include ("../session.php");

if (!@include ("../lang/$language/EasyGMS/step2.php"))
  include ("../lang/EN/EasyGMS/step2.php"); // Fall back to English if no translation is available

extract($_POST, EXTR_PREFIX_ALL, 'p');

$query="DROP TABLE `" . session_id() . "`;";
    mysql_query($query);
    $query="CREATE TABLE `" . session_id() . "` (`Index` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `GeneType` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `GeneSubType` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `GeneID` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Generation` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `SwitchOnTime` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Flags` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `MutabilityWeighting` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Variant` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Body` BLOB NOT NULL, INDEX (`Index`));";
    mysql_query($query);
    if ($_FILES['geneFile']['tmp_name'] == "")
    {
      $query = "SELECT `filename` FROM `genomes` WHERE `Name` = '" . mysql_real_escape_string($p_genome) . "'";
      $result = mysql_query($query);
      $errors = readGeneFile("genomes/" . $content.mysql_result($result,$i,"filename"), session_id());
    }
    else
      $errors = readGeneFile($_FILES['geneFile']['tmp_name'], session_id());

?>
<html>
  <head>
    <title><? echo $title; ?></title>
  </head>
  <body bgcolor="#B0B0FF" text="#000000" link="#FFFF99" alink="#FFFFFF" vlink="#FFFF99">
    <p align="center"><img src="logo.jpg"></p>
    <hr>
    <h1><? echo $headline00; ?></h1>
    <table border="0">
    <tr>
    <td><img border="0" src="Edu/configure.jpg"></td>
    <td><? echo $content00; ?><br>
    </td>
    </tr>
    </table>
    <form action="generate.php" method="post" target="_blank" enctype="multipart/form-data">
    <hr>
    <table border="0">
    <tr>
    <td>    
      <table border="0">
      <tr>
      <td><? echo $content01; ?><br><br></td>
      <td>
      <table border="0">
      <tr>
      <?
      $red = 0;
      $green = 0;
      $blue = 0;
      $mult = 32;
      while ($mult <= 64)
      {
        if ($red * $mult < 16)
	  $redHex = "0" . dechex($red * $mult);
	else
          $redHex = dechex($red * $mult - 1);
	if ($green * $mult < 16)
	  $greenHex = "0" . dechex($green * $mult);
	else
	  $greenHex = dechex($green * $mult - 1);
	if ($blue * $mult < 16)
	  $blueHex = "0" . dechex($blue * $mult);
	else
	  $blueHex = dechex($blue * $mult - 1);
	  
        echo "<td bgcolor=\"#$redHex$greenHex$blueHex\"><input type=\"radio\" name=\"color\" value=\"$redHex$greenHex$blueHex\"";
	if ($redHex . $greenHex . $blueHex == "7f7f7f") echo " checked";
	echo "></td>";
	if ($blue == 0 && $red == 0)
	  $blue = 4;
	else if ($red < 4)
	  $red = $red + 1;
	else if ($red == 4 && $blue > 0)
	  $blue = $blue - 1;
	else
	{
	  if ($green >= 4)
	  {
	    $mult = $mult + 32;
	    $green = 0;
	    $red = 0;
	    $blue = 0;
	    echo "</tr>\n<tr>";
	  }
	  else
	  {
	    $green = $green + 1;
	    $red = 0;
	    $blue = 0;
	    echo "</tr>\n<tr>";
	  }
	}
      }
      ?>
      </tr>
      </table>
      </td>
      </tr>
      <tr>
      <td><? echo $content02; ?><br><br></td>
      <td>
        <?
	$query = "SELECT `Name` FROM `spriteSlots` ORDER BY `Name` ASC";
	$spriteResult = mysql_query($query);
	$num=mysql_numrows($spriteResult);
	?>
	<table border="0">
	<tr><td><? echo $content03; ?></td><td><select name="spriteHead"><?
        $i = 0;
        while ($i < $num)
        {
          $spriteName = $content.mysql_result($spriteResult,$i);
          echo "<option value=\"$spriteName\""; 
	  if ($spriteName == "ChiChi") echo " selected";
	  echo ">$spriteName</option>";
          ++$i;
        }?>
        </select></td></tr>
	<tr><td><? echo $content04; ?></td><td><select name="spriteBody"><?
        $i = 0;
        while ($i < $num)
        {
          $spriteName = $content.mysql_result($spriteResult,$i);
	  echo "<option value=\"$spriteName\""; 
	  if ($spriteName == "ChiChi") echo " selected";
	  echo ">$spriteName</option>";
          ++$i;
        }?>
        </select></td></tr>
	<tr><td><? echo $content05; ?></td><td><select name="spriteArms"><?
        $i = 0;
        while ($i < $num)
        {
          $spriteName = $content.mysql_result($spriteResult,$i);
          echo "<option value=\"$spriteName\""; 
	  if ($spriteName == "ChiChi") echo " selected";
	  echo ">$spriteName</option>";
          ++$i;
        }?>
        </select></td></tr>
	<tr><td><? echo $content06; ?></td><td><select name="spriteLegs"><?
        $i = 0;
        while ($i < $num)
        {
          $spriteName = $content.mysql_result($spriteResult,$i);
          echo "<option value=\"$spriteName\""; 
	  if ($spriteName == "ChiChi") echo " selected";
	  echo ">$spriteName</option>";
          ++$i;
        }?>
        </select></td></tr>
	<tr><td><? echo $content07; ?></td><td><select name="spriteTail"><?
        $i = 0;
        while ($i < $num)
        {
          $spriteName = $content.mysql_result($spriteResult,$i);
          echo "<option value=\"$spriteName\""; 
	  if ($spriteName == "ChiChi") echo " selected";
	  echo ">$spriteName</option>";
          ++$i;
        }?>
        </select></td></tr>
      </table>
    </td>
    <td><img border="0" src="Edu/painting.jpg"></td>
    </tr>
    <tr>
    <td><? echo $content08; ?></td>
    <td>
      <table border="0">
      <tr><td><? echo $content09; ?></td>
      <td><select name="pigmentRotation">
      <?
      for ($i = 0; $i <= 8; $i++)
        if ($i == 4)
	  echo "<option selected value=\"$i\">$i</option>";
	else
	  echo "<option value=\"$i\">$i</option>";
      ?>
      </select>
      </td>
      </tr>
      <tr><td><? echo $content10; ?></td>
      <td><select name="pigmentSwap">
      <?
      for ($i = 0; $i <= 8; $i++)
        if ($i == 4)
	  echo "<option selected value=\"$i\">$i</option>";
	else
	  echo "<option value=\"$i\">$i</option>";
      ?>
      </select>
      </td>
      </tr>
      </table></td></tr>
      </table>
      <br><input type="submit" value="<? echo $button00; ?>" name="action">
      <hr>
      <table border="0">
      <tr>
      <td><? echo $content11; ?><br><br></td>
      <td><input name="eggName" value="EasyGMS Eggs"></td>
      </tr>
      <tr><td><? echo $content12; ?><br><br></td>
      <td><select name="lifespan">
      <?
      for ($i = 1; $i <= 10; $i++)
        if ($i == 6)
	  echo "<option selected value=\"$i\">$i</option>";
        else
	  echo "<option value=\"$i\">$i</option>";
      ?>
      </select></td></tr>
      <?
      $query = "SELECT `Name` FROM `chemicalNames` WHERE `Number` >= 148 AND `Number` <= 163";
      $driveResult = mysql_query($query);
      $num=mysql_numrows($driveResult);
      ?>
      <tr><td><? echo $content13; ?></td>
      <td>
      <table border="0">
      <?
      $i = 0;
      while ($i < $num)
      {
        $driveName = $content.mysql_result($driveResult,$i);
	$escapedDriveName = str_replace(" ", "", $driveName);
	echo '<tr><td>' . $driveName . ":</td><td> <select name=\"$escapedDriveName\">" . '
	<option value="+2">+2</option>
	<option value="+1">+1</option>
	<option value="0" selected>0</option>
	<option value="-1">-1</option>
	<option value="-2">-2</option>
	</select></td></tr>';
        ++$i;
      }?>
      </table>
      </td></tr>
      </table>
    <hr>
    <input type="submit" value="<? echo $button01; ?>" name="action">
    </form>
  </body>
</html>
<?
mysql_close();
?>
