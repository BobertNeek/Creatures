<?
include ("../ea/writefile.php");
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

include ("../session.php");

if (!@include ("../lang/$language/EasyGMS/step3.php"))
  include ("../lang/EN/EasyGMS/step3.php"); // Fall back to English if no translation is available

$geneFile = $ssid . "/" . $_GET['eggName'] . ".gen";
$agentFile = $ssid . "/" . $_GET['eggName'] . ".agents";

?>
<html>
  <head>
    <title><? echo $title; ?></title>
  </head>
  <body bgcolor="#B0B0FF" text="#000000" link="#FFFF99" alink="#FFFFFF" vlink="#FFFF99">
    <p align="center"><img src="logo.jpg"></p>
    <hr>
    <h1><? echo $headline00; ?></h1>
    <table border="0">
    <tr>
    <td><img border="0" src="Edu/floppy.jpg"></td>
    <td><? echo $content00; ?><br>
    <ul>
    <li><a href="../tmp/<?echo $agentFile;?>"><? echo $content01; ?></a><? echo $content02; ?></li>
    <li><a href="../tmp/<?echo $geneFile;?>"><? echo $content03; ?></a><? echo $content04; ?></li>
    </ul>
    <br>
    <? echo $content05; ?>
    </td>
    </tr>
    </table>
  </body>
</html>
<?
mysql_close();
?>
