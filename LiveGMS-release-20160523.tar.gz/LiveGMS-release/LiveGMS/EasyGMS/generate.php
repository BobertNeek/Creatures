<?
include ("../ea/writefile.php");
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

include ("../session.php");

if (!@include ("../lang/$language/EasyGMS/generate.php"))
  include ("../lang/EN/EasyGMS/generate.php"); // Fall back to English if no translation is available

extract($_POST, EXTR_PREFIX_ALL, 'p');

if (strstr($p_action, "3"))
{
$query = "DELETE FROM `" . session_id() . "` WHERE 1 AND `GeneType` = '2' AND `GeneSubType` = '6'";
$result = mysql_query($query);

$Color = 0;
while ($Color <= 2)
{
  $Age = 0;
  while ($Age <= 6)
  {
    $GeneId = ($Age + 1) * ($Color + 1) - 1;
    $Amount = hexdec(substr($p_color, $Color * 2, 2));
    $Body = mysql_real_escape_string(chr($Color) . chr($Amount));
    $query = "INSERT INTO `" . session_id() . "` (`GeneType`, `GeneSubType`, `GeneID`, `Generation`, `SwitchOnTime`, `Flags`, `MutabilityWeighting`, `Variant`, `Body`) VALUES ('2', '6', '$GeneID', '0', '$Age', '7', '255', '0', '$Body')";
    $result = mysql_query($query);
    ++$Age;
  }
  ++$Color;
}

$query = "DELETE FROM `" . session_id() . "` WHERE 1 AND `GeneType` = '2' AND `GeneSubType` = '7'";
$result = mysql_query($query);
for ($Count = 0; $Count < 3; $Count ++)
{
$Age = 0;
while ($Age <= 6)
{
  $GeneId = ($Age + 1) * ($Count + 1) - 1;
  $Body = mysql_real_escape_string(chr($p_pigmentRotation * 31 + 1) . chr($p_pigmentSwap * 31 + 1));
  $query = "INSERT INTO `" . session_id() . "` (`GeneType`, `GeneSubType`, `GeneID`, `Generation`, `SwitchOnTime`, `Flags`, `MutabilityWeighting`, `Variant`, `Body`) VALUES ('2', '7', '$GeneID', '0', '$Age', '7', '255', '0', '$Body')";
  $result = mysql_query($query);
  ++$Age;
}
}

$query = "DELETE FROM `" . session_id() . "` WHERE 1 AND `GeneType` = '2' AND `GeneSubType` = '2'";
$result = mysql_query($query);

$query = "SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteHead) . "'";
$spriteResult = mysql_query($query);
$bodyPart = 0;
$slot = (ord($content.mysql_result($spriteResult,0,"Slot")) - 97);
$species = $content.mysql_result($spriteResult,0,"Species");
$Body = mysql_real_escape_string(chr($bodyPart) . chr($slot) . chr($species));
$query = "INSERT INTO `" . session_id() . "` (`GeneType`, `GeneSubType`, `GeneID`, `Generation`, `SwitchOnTime`, `Flags`, `MutabilityWeighting`, `Variant`, `Body`) VALUES ('2', '2', '$bodyPart', '0', '0', '7', '128', '0', '$Body')";
$result = mysql_query($query);

$query = "SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteBody) . "'";
$spriteResult = mysql_query($query);
$bodyPart = 1;
$slot = (ord($content.mysql_result($spriteResult,0,"Slot")) - 97);
$species = $content.mysql_result($spriteResult,0,"Species");
$Body = mysql_real_escape_string(chr($bodyPart) . chr($slot) . chr($species));
$query = "INSERT INTO `" . session_id() . "` (`GeneType`, `GeneSubType`, `GeneID`, `Generation`, `SwitchOnTime`, `Flags`, `MutabilityWeighting`, `Variant`, `Body`) VALUES ('2', '2', '$bodyPart', '0', '0', '7', '128', '0', '$Body')";
$result = mysql_query($query);

$query = "SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteLegs) . "'";
$spriteResult = mysql_query($query);
$bodyPart = 2;
$slot = (ord($content.mysql_result($spriteResult,0,"Slot")) - 97);
$species = $content.mysql_result($spriteResult,0,"Species");
$Body = mysql_real_escape_string(chr($bodyPart) . chr($slot) . chr($species));
$query = "INSERT INTO `" . session_id() . "` (`GeneType`, `GeneSubType`, `GeneID`, `Generation`, `SwitchOnTime`, `Flags`, `MutabilityWeighting`, `Variant`, `Body`) VALUES ('2', '2', '$bodyPart', '0', '0', '7', '128', '0', '$Body')";
$result = mysql_query($query);

$query = "SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteArms) . "'";
$spriteResult = mysql_query($query);
$bodyPart = 3;
$slot = (ord($content.mysql_result($spriteResult,0,"Slot")) - 97);
$species = $content.mysql_result($spriteResult,0,"Species");
$Body = mysql_real_escape_string(chr($bodyPart) . chr($slot) . chr($species));
$query = "INSERT INTO `" . session_id() . "` (`GeneType`, `GeneSubType`, `GeneID`, `Generation`, `SwitchOnTime`, `Flags`, `MutabilityWeighting`, `Variant`, `Body`) VALUES ('2', '2', '$bodyPart', '0', '0', '7', '128', '0', '$Body')";
$result = mysql_query($query);

$query = "SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteTail) . "'";
$spriteResult = mysql_query($query);
$bodyPart = 4;
$slot = (ord($content.mysql_result($spriteResult,0,"Slot")) - 97);
$species = $content.mysql_result($spriteResult,0,"Species");
$Body = mysql_real_escape_string(chr($bodyPart) . chr($slot) . chr($species));
$query = "INSERT INTO `" . session_id() . "` (`GeneType`, `GeneSubType`, `GeneID`, `Generation`, `SwitchOnTime`, `Flags`, `MutabilityWeighting`, `Variant`, `Body`) VALUES ('2', '2', '$bodyPart', '0', '0', '7', '128', '0', '$Body')";
$result = mysql_query($query);

$query = "SELECT `Body` FROM `" . session_id() . "` WHERE 1 AND `GeneType` = '1' AND `GeneSubType` = '3'";
$halflifeResult = mysql_query($query);
$Body = $content.mysql_result($halflifeResult,0);
$Body[125] = chr(70 + $p_lifespan * 5);
$Body = mysql_real_escape_string($Body);
$query = "UPDATE `" . session_id() . "` SET Body='$Body' WHERE 1 AND `GeneType` = '1' AND `GeneSubType` = '3'";
mysql_query($query);


$query = "SELECT `Name` FROM `chemicalNames` WHERE `Number` >= 148 AND `Number` <= 163";
$driveResult = mysql_query($query);
$numDrives=mysql_numrows($driveResult);

$query = "SELECT `Body`,`Index` FROM `" . session_id() . "` WHERE 1 AND `GeneType` = '1' AND `GeneSubType` = '1'";
$emitterResult = mysql_query($query);

$i = 0;
while ($i < $numDrives)
{
  $driveName = str_replace(" ", "", $content.mysql_result($driveResult,$i));
  $relAmount = $_POST[$driveName];
  
  //Check Stimuli
  
  //Update Stimuli since the Body may has been changed in a previous run
  $query = "SELECT `Body`,`Index` FROM `" . session_id() . "` WHERE 1 AND `GeneType` = '2' AND `GeneSubType` = '0'";
  $stimulusResult = mysql_query($query);
  
  for ($i2 = 0; $i2 < mysql_numrows($stimulusResult); $i2++)
  {
    //$Body = chr($Stimulus) . chr($Significance) . chr($Reaction) . chr($Intensity) . chr($Flags) . chr($Chemical0) . chr($Amount0) . chr($Chemical1) . chr($Amount1) . chr($Chemical2) . chr($Amount2) . chr($Chemical3) . chr($Amount3);
    $Body = $content.mysql_result($stimulusResult,$i2,0);
    $Index = $content.mysql_result($stimulusResult,$i2,1);
    for ($i3 = 0; $i3 < 4; $i3++)
      if ($Body[5 + $i3 * 2] == chr($i))
      {
        //echo "Stimulus $i2 matches chemical $driveName<br>";
	//echo "Stimulus #$Index had an amount of " . ord($Body[6 + $i3 * 2]) . " for the chemical $driveName on position $i3";
        if ($relAmount >= 0 && ord($Body[6 + $i3 * 2]) > 124)
          $Body[6 + $i3 * 2] = chr((ord($Body[6 + $i3 * 2]) * 2 + 254 * $relAmount) / ($relAmount + 2));
        else if (ord($Body[6 + $i3 * 2]) > 124)
	  $Body[6 + $i3 * 2] = chr((ord($Body[6 + $i3 * 2]) * 2 + 124 * -$relAmount) / (-$relAmount + 2));
	//echo " which is now " . ord($Body[6 + $i3 * 2]) . "<br>";
      }
    $Body = mysql_real_escape_string($Body);
    mysql_query("UPDATE `" . session_id() . "` SET `Body` = '$Body' WHERE 1 AND `Index` = '" . mysql_real_escape_string($Index) . "'");
  }
  
  //Check Emitters
  
  for ($i2 = 0; $i2 < mysql_numrows($emitterResult); $i2++)
  {
    //$Body = chr($Organ) . chr($Tissue) . chr($Locus) . chr($Chemical) . chr($Threshold) . chr($Rate) . chr($Gain) . chr($Flags);
    $Body = $content.mysql_result($emitterResult,$i2,0);
    $Index = $content.mysql_result($emitterResult,$i2,1);
    if ($Body[3] == chr($i + 148))
    {
      //echo "Emitter $i2 matches chemical $driveName<br>";
      //echo "Emitter #$Index had a rate of " . ord($Body[5]);
      if ($relAmount <= 0)
        $Body[5] = chr((ord($Body[5]) * 15 + 255 * -$relAmount) / (-$relAmount + 15));
      else
	$Body[5] = chr((ord($Body[5]) * 3) / ($relAmount + 3));
      //echo " which is now " . ord($Body[5]) . "<br>";
      $Body = mysql_real_escape_string($Body);
      mysql_query("UPDATE `" . session_id() . "` SET `Body` = '$Body' WHERE 1 AND `Index` = '" . mysql_real_escape_string($Index) . "'");
    }
  }
  
  ++$i;
}


system("rm -f " . escapeshellarg(getcwd() . "/../tmp/$ssid") . "/*");

$eggName = strtolower(str_replace(" ", "", str_replace("/", "", $p_eggName)));

$geneFile = $ssid . "/$eggName.gen";
writeGeneFile(getcwd() . "/../tmp/" . $geneFile, session_id());
$prayFile = '"en-gb"
group EGGS "' . $p_eggName . '"
"Agent Type" 0
"Script Count" 0
"Dependency Count" 2
"Dependency 1" "livegms-' . $ssid . '-' . $eggName . '.gen"
"Dependency Category 1" 3
"Dependency 2" "easygms_eggs.c16"
"Dependency Category 2" 2
"Genetics File" "livegms-' . $ssid . '-' . $eggName . '"
"Egg Glyph File" "easygms_eggs.c16"
"Egg Glyph File 2" "easygms_eggs.c16"
"Egg Gallery male" "easygms_eggs"
"Egg Gallery female" "easygms_eggs"
inline FILE "livegms-' . $ssid . '-' . $eggName . '.gen" "' . $eggName . '.gen"
inline FILE "easygms_eggs.c16" "easygms_eggs.c16"';
$prayFileName = getcwd() . "/../tmp/" . $ssid . "/" . $eggName . ".txt";
$prayFileHandle = fopen($prayFileName , 'w+');
fwrite($prayFileHandle, $prayFile);
fclose($prayFileHandle);

system ("ln -s " . escapeshellarg(getcwd() . "/pray/praybuilder") . " " . escapeshellarg(getcwd() . "/../tmp/$ssid/praybuilder"));
system ("ln -s " . escapeshellarg(getcwd() . "/pray/easygms_eggs.c16") . " " . escapeshellarg(getcwd() . "/../tmp/$ssid/easygms_eggs.c16"));
system ("cd " . escapeshellarg(getcwd() . "/../tmp/$ssid") . " && ./praybuilder " . escapeshellarg($prayFileName) . " > /dev/null");

header ("Location: step3.php?eggName=$eggName");
}
else
{
  echo '<html>
  <head>
    <title>' . $title . '</title>
  </head>
  <body bgcolor="#B0B0FF" text="#000000" link="#FFFF99" alink="#FFFFFF" vlink="#FFFF99">
    ' . $content00 . '<br><br>';
  $red = hexdec(substr($p_color, 0 * 2, 2));
  $green = hexdec(substr($p_color, 1 * 2, 2));
  $blue = hexdec(substr($p_color, 2 * 2, 2));
  $rot = $p_pigmentRotation * 31 + 1;
  $swap = $p_pigmentSwap * 31 + 1;
  
  $spriteResult = mysql_query("SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteHead) . "'");
  $slot_head = $content.mysql_result($spriteResult,0,"Slot");
  $species_head = $content.mysql_result($spriteResult,0,"Species");
  $spriteResult = mysql_query("SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteBody) . "'");
  $slot_body = $content.mysql_result($spriteResult,0,"Slot");
  $species_body = $content.mysql_result($spriteResult,0,"Species");
  $spriteResult = mysql_query("SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteArms) . "'");
  $slot_arms = $content.mysql_result($spriteResult,0,"Slot");
  $species_arms = $content.mysql_result($spriteResult,0,"Species");
  $spriteResult = mysql_query("SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteLegs) . "'");
  $slot_legs = $content.mysql_result($spriteResult,0,"Slot");
  $species_legs = $content.mysql_result($spriteResult,0,"Species");
  $spriteResult = mysql_query("SELECT `Slot`, `Species` FROM `spriteSlots` WHERE `Name` = '" . mysql_real_escape_string($p_spriteTail) . "'");
  $slot_tail = $content.mysql_result($spriteResult,0,"Slot");
  $species_tail = $content.mysql_result($spriteResult,0,"Species");
  
  echo "<img src=\"preview.php?r=$red&g=$green&b=$blue&ro=$rot&sw=$swap&hs=$species_head&bs=$species_body&as=$species_arms&ls=$species_legs&ts=$species_tail&hsl=$slot_head&bsl=$slot_body&asl=$slot_arms&lsl=$slot_legs&tsl=$slot_tail\">";
  echo '</body>
  </html>';
}

mysql_close();

?>
