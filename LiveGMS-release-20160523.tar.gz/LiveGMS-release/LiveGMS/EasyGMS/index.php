<?
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

include ("../session.php");

if (!@include ("../lang/$language/EasyGMS/step1.php"))
  include ("../lang/EN/EasyGMS/step1.php"); // Fall back to English if no translation is available

extract($_GET, EXTR_PREFIX_ALL, 'g');
?>
<html>
  <head>
    <title><? echo $title; ?></title>
  </head>
  <body bgcolor="#B0B0FF" text="#000000" link="#FFFF99" alink="#FFFFFF" vlink="#FFFF99">
    <center>
    <table border = "0" cellspacing="10"><tr><td>Language selector:</td><td bgcolor="#222222"><? if ($language != "EN") echo '<a href="step1.php?language=EN">English</a>'; else echo '<font color="red">English</font>'?></td><td bgcolor="#222222"><? if ($language != "FR") echo '<a href="step1.php?language=FR">French / Fran�ais</a>'; else echo '<font color="red">French / Fran�ais</font>'?></td><td bgcolor="#222222"><? if ($language != "DE") echo '<a href="step1.php?language=DE">German / Deutsch</a>'; else echo '<font color="red">German / Deutsch</font>'?></td></tr></table>
    </center><br>
    <p align="center"><img src="logo.jpg"></p>
    <hr>
    <h1><? echo $headline00; ?></h1>
    <table border="0">
    <tr>
    <td><img border="0" src="Edu/welcome.jpg"></td>
    <td><? echo $content00; ?><br>
    </td>
    </tr>
    </table>
    <form action="step2.php" method="post" enctype="multipart/form-data">
    <hr>
    <table border="0">
    <tr>
    <td>    
      <? echo $content01; ?>
      <table border="0">
      <tr>
      <td><? echo $content02; ?></td>
      <td>
      <select name="genome">
      <?
      $i = 0;
      $query = "SELECT `Name` FROM `genomes` ORDER BY `Name` ASC";
      $result = mysql_query($query);
      $num = mysql_numrows($result);
      while ($i < $num)
      {
        @$name = $content.mysql_result($result,$i,"Name");
	echo "<option value=\"$name\""; 
	if ($name == "ChiChi") echo " selected";
	echo ">$name</option>";
        ++$i;
      }
      ?>
      </select>
      </td>
      </tr>
      <tr>
      <td><? echo $content03; ?></td>
      <td>
      <input type="file" name="geneFile" size=50>
      <input type="hidden" name="action" value="readfile">
      <input type="hidden" name="MAX_FILE_SIZE" value="500000">
      </td>
      </tr>
      </table>
    </td>
    <td><img border="0" src="Edu/floppy.jpg"></td>
    </tr>
    </table>
    <hr>
    <input type="submit" value="<? echo $button00; ?>">
    </form>
  </body>
</html>
<?
mysql_close();
?>
