#sh
cd tmp
cp $1/?$24$3.c16 ./
for i in *.c16; do c16topng -t $i; done
mv ????_0.png ../
rm *.*

