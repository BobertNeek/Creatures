<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");
$query = "SELECT `Index` FROM `" . session_id() . "` WHERE 1 AND `GeneType` = 0 AND `GeneSubType` = 0 ORDER BY `Index` ASC";
$result = mysql_query($query);
#$num=mysql_numrows($result);

$Watermark = $p_Watermark;

$i = 0;
while ($i < 32)
{
  if (substr($Watermark, $i, 1) == "")
    $Watermark = $Watermark . " ";
  ++$i;
}
$query = "SELECT `Index` FROM `" . session_id() . "` WHERE 1";
$result = mysql_query($query);
$num=mysql_numrows($result);

$actChar = 0;
$phase = 0;
$Pointer = 0;
$i = 0;
while ($i < $num)
{
  $Index = $content.mysql_result($result, $i, "Index");
  if ($phase == 0)
    $Variant = chr(255);
  else if ($phase == 3)
  {
    $Variant = chr(ord(substr($Watermark, ($Pointer * 2), 1)) ^ ord(substr($Watermark, ($Pointer * 2) + 1, 1)) ^ 23 ^ $Pointer);
    ++$Pointer;
    if ($Pointer > 16)
      $Pointer = 0;
  }
  else
  {
    $Variant = substr($Watermark, ($Pointer * 2) + $phase - 1, 1);
  }

  $query = "UPDATE `" . session_id() . "` SET `Variant`='" . ord($Variant) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($Index) . "'";
  mysql_query($query);

  ++$phase;
  if ($phase > 3)
    $phase = 0;
  ++$i;
}

mysql_close();
Header("Location: ../interface/close.php");
?>
