<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$Lobe0 = $p_Lobe0;
$Neuron0 = $p_Neuron0;
$Lobe1 = $p_Lobe1;
$Neuron1 = $p_Neuron1;
$Lobe2 = $p_Lobe2;
$Neuron2 = $p_Neuron2;
$Rate = $p_Rate;
$Chemical0 = $p_Chemical0;
$Amount0 = $p_Amount0;
$Chemical1 = $p_Chemical1;
$Amount1 = $p_Amount1;
$Chemical2 = $p_Chemical2;
$Amount2 = $p_Amount2;
$Chemical3 = $p_Chemical3;
$Amount3 = $p_Amount3;

if ($Neuron0 == "")
  $Neuron0 = 0;
else if ($Neuron0 > 255)
  $Neuron0 = 255;
else if ($Neuron0 < 0)
  $Neuron0 = 0;

if ($Neuron1 == "")
  $Neuron1 = 0;
else if ($Neuron1 > 255)
  $Neuron1 = 255;
else if ($Neuron1 < 0)
  $Neuron1 = 0;

if ($Neuron2 == "")
  $Neuron2 = 0;
else if ($Neuron2 > 255)
  $Neuron2 = 255;
else if ($Neuron2 < 0)
  $Neuron2 = 0;

if ($Rate == "")
  $Rate = 128;
else if ($Rate > 255)
  $Rate = 255;
else if ($Rate < 0)
  $Rate = 0;

if ($Amount0 == "")
  $Amount0 = 0;
else if ($Amount0 > 255)
  $Amount0 = 255;
else if ($Amount0 < 0)
  $Amount0 = 0;

if ($Amount1 == "")
  $Amount1 = 0;
else if ($Amount1 > 255)
  $Amount1 = 255;
else if ($Amount1 < 0)
  $Amount1 = 0;

if ($Amount2 == "")
  $Amount2 = 0;
else if ($Amount2 > 255)
  $Amount2 = 255;
else if ($Amount2 < 0)
  $Amount2 = 0;

if ($Amount3 == "")
  $Amount3 = 0;
else if ($Amount3 > 255)
  $Amount3 = 255;
else if ($Amount3 < 0)
  $Amount3 = 0;

$Body = chr($Lobe0) . chr($Neuron0) . chr($Lobe1) . chr($Neuron1) . chr($Lobe2) . chr($Neuron2) . chr($Rate) . chr($Chemical0) . chr($Amount0) . chr($Chemical1) . chr($Amount1) . chr($Chemical2) . chr($Amount2) . chr($Chemical3) . chr($Amount3);

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
