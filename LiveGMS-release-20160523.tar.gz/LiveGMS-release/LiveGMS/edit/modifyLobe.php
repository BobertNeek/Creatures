<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$i = 0;
$LobeId = "";
while ($i < 4)
{
  if (substr($p_LobeId, $i, 1) == "")
    $LobeId = $LobeId . "X";
  else
    $LobeId = $LobeId . substr($p_LobeId, $i, 1);
  ++$i;
}

$UpdateTime = $p_UpdateTime; #!
$X = $p_X; #!
$Y = $p_Y; #!
$Width = $p_Width;
$Height = $p_Height;
$Red = $p_Red;
$Green = $p_Green;
$Blue = $p_Blue;
$Tissue = $p_Tissue;

if ($UpdateTime == "")
  $UpdateTime = 0;
else if ($UpdateTime > ((256 * 256) - 1))
  $UpdateTime = ((256 * 256) - 1);
else if ($UpdateTime < 0)
  $UpdateTime = 0;

if ($X == "")
  $X = 0;
else if ($X > ((256 * 256) - 1))
  $X = ((256 * 256) - 1);
else if ($X < 0)
  $X = 0;

if ($Y == "")
  $Y = 0;
else if ($Y > ((256 * 256) - 1))
  $Y = ((256 * 256) - 1);
else if ($Y < 0)
  $Y = 0;

if ($Width == "")
  $Width = 1;
else if ($Width > 255)
  $Width = 255;
else if ($Width < 0)
  $Width = 0;

if ($Height == "")
  $Height = 1;
else if ($Height > 255)
  $Height = 255;
else if ($Height < 0)
  $Height = 0;

if ($Red == "")
  $Red = 128;
else if ($Red > 255)
  $Red = 255;
else if ($Red < 0)
  $Red = 0;

if ($Green == "")
  $Green = 128;
else if ($Green > 255)
  $Green = 255;
else if ($Green < 0)
  $Green = 0;

if ($Blue == "")
  $Blue = 128;
else if ($Blue > 255)
  $Blue = 255;
else if ($Blue < 0)
  $Blue = 0;

if ($Tissue == "")
  $Tissue = 255;
else if ($Tissue > 255)
  $Tissue = 255;
else if ($Tissue < 0)
  $Tissue = 0;

$Body = $LobeId . chr(($UpdateTime & (255 * 256)) / 256) . chr($UpdateTime & 255) . chr(($X & (255 * 256)) / 256) . chr($X & 255) . chr(($Y & (255 * 256)) / 256) . chr($Y & 255) . chr($Width) . chr($Height) . chr($Red) . chr($Green) . chr($Blue) . chr(0) . chr($Tissue);

$query = "SELECT `Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
$result = mysql_query($query);
  $oldBody = $content.mysql_result($result,0,"Body");
if ($oldBody != "")
  $Body = $Body . substr($oldBody, 17, 8);
else
{
  $i = 0;
  while ($i < 8)
  {
    $Body = $Body . chr(0);
    ++$i;
  }
}


$i = 0;
while ($i < 16)
{
  eval('$Operation = $p_InitOperation' . "$i" . ';');
  eval('$Operand = $p_InitOperand' . "$i" . ';');
  eval('$Value = $p_InitValue' . "$i" . ';');
  $Body = $Body . chr($Operation) . chr($Operand) . chr($Value);
  ++$i;
}

$i = 0;
while ($i < 16)
{
  eval('$Operation = $p_UpdateOperation' . "$i" . ';');
  eval('$Operand = $p_UpdateOperand' . "$i" . ';');
  eval('$Value = $p_UpdateValue' . "$i" . ';');
  $Body = $Body . chr($Operation) . chr($Operand) . chr($Value);
  ++$i;
}

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
