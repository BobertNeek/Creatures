<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$Stimulus = $p_Stimulus;
$Significance = $p_Significance;
$Reaction = $p_Reaction;
$Intensity = $p_Intensity;
$Chemical0 = $p_Chemical0;
$Amount0 = $p_Amount0 + 124;
$Chemical1 = $p_Chemical1;
$Amount1 = $p_Amount1 + 124;
$Chemical2 = $p_Chemical2;
$Amount2 = $p_Amount2 + 124;
$Chemical3 = $p_Chemical3;
$Amount3 = $p_Amount3 + 124;

$Flags = 0;
if ($p_Silent0)
 $Flags = $Flags | 16;
if ($p_Silent1)
 $Flags = $Flags | 32;
if ($p_Silent2)
 $Flags = $Flags | 64;
if ($p_Silent3)
 $Flags = $Flags | 128;
if ($p_UseSensory)
 $Flags = $Flags | 1;
if ($p_Asleep)
 $Flags = $Flags | 4;

if ($Significance == "")
  $Significance = 128;
else if ($Significance > 255)
  $Significance = 255;
else if ($Significance < 0)
  $Significance = 0;

if ($Intensity == "")
  $Intensity = 128;
else if ($Intensity > 255)
  $Intensity = 255;
else if ($Intensity < 0)
  $Intensity = 0;

if ($Amount0 == "")
  $Amount0 = 124;
else if ($Amount0 > 255)
  $Amount0 = 255;
else if ($Amount0 < 0)
  $Amount0 = 0;

if ($Amount1 == "")
  $Amount1 = 124;
else if ($Amount1 > 255)
  $Amount1 = 255;
else if ($Amount1 < 0)
  $Amount1 = 0;

if ($Amount2 == "")
  $Amount2 = 124;
else if ($Amount2 > 255)
  $Amount2 = 255;
else if ($Amount2 < 0)
  $Amount2 = 0;

if ($Amount3 == "")
  $Amount3 = 124;
else if ($Amount3 > 255)
  $Amount3 = 255;
else if ($Amount3 < 0)
  $Amount3 = 0;

$Body = chr($Stimulus) . chr($Significance) . chr($Reaction) . chr($Intensity) . chr($Flags) . chr($Chemical0) . chr($Amount0) . chr($Chemical1) . chr($Amount1) . chr($Chemical2) . chr($Amount2) . chr($Chemical3) . chr($Amount3);

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
