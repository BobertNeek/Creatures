<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$PoseNumber = $p_PoseNumber;

if ($PoseNumber == "")
  $PoseNumber = 0;
else if ($PoseNumber > 255)
  $PoseNumber = 255;
else if ($PoseNumber < 0)
  $PoseNumber = 0;

$i = 0;
while ($i < 17)
{
  if (substr($p_PoseString, $i, 1) == "")
    $PoseString = $PoseString . "X";
  else
    $PoseString = $PoseString . substr($p_PoseString, $i, 1);
  ++$i;
}

$Body = chr($PoseNumber) . $PoseString;

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
