<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$Body = "";

$i = 0;
while ($i < 256)
{
  eval('$chem = $p_chem_' . "$i" . ';');
  if ($chem == "")
    $chem = 0;
  else if ($chem > 255)
    $chem = 255;
  else if ($chem < 0)
    $chem = 0;
  $Body = $Body . chr($chem);
  ++$i;
}

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
