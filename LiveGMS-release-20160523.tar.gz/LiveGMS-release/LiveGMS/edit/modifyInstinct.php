<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$Lobe0 = $p_Lobe0;
$Neuron0 = $p_Neuron0;
$Lobe1 = $p_Lobe1;
$Neuron1 = $p_Neuron1;
$Lobe2 = $p_Lobe2;
$Neuron2 = $p_Neuron2;
$Action = $p_Action;
$ReinforcementDrive = $p_ReinforcementDrive;
$ReinforcementLevel = $p_ReinforcementLevel + 128;

if ($ReinforcementLevel == "")
  $ReinforcementLevel = 128;
else if ($ReinforcementLevel > 255)
  $ReinforcementLevel = 255;
else if ($ReinforcementLevel < 0)
  $ReinforcementLevel = 0;

if ($Neuron0 == "")
  $Neuron0 = 128;
else if ($Neuron0 > 255)
  $Neuron0 = 255;
else if ($Neuron0 < 0)
  $Neuron0 = 0;

if ($Neuron1 == "")
  $Neuron1 = 128;
else if ($Neuron1 > 255)
  $Neuron1 = 255;
else if ($Neuron1 < 0)
  $Neuron1 = 0;

if ($Neuron2 == "")
  $Neuron2 = 128;
else if ($Neuron2 > 255)
  $Neuron2 = 255;
else if ($Neuron2 < 0)
  $Neuron2 = 0;

$Body = chr($Lobe0) . chr($Neuron0) . chr($Lobe1) . chr($Neuron1) . chr($Lobe2) . chr($Neuron2) . chr($Action) . chr($ReinforcementDrive) . chr($ReinforcementLevel);

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
