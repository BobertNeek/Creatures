<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$Organ = $p_Organ;
$Tissue = $p_Tissue;
$Locus = $p_Locus;
$Chemical = $p_Chemical;
$Threshold = $p_Threshold;
$Nominal = $p_Nominal;
$Gain = $p_Gain;
$Flags = 0;
if ($p_Inverted)
 $Flags = $Flags | 1;
if ($p_Digital)
 $Flags = $Flags | 2;

if ($Tissue == "")
  $Tissue = 0;
else if ($Tissue > 255)
  $Tissue = 255;
else if ($Tissue < 0)
  $Tissue = 0;

if ($Locus == "")
  $Locus = 0;
else if ($Locus > 255)
  $Locus = 255;
else if ($Locus < 0)
  $Locus = 0;

if ($Threshold == "")
  $Threshold = 0;
else if ($Threshold > 255)
  $Threshold = 255;
else if ($Threshold < 0)
  $Threshold = 0;

if ($Nominal == "")
  $Nominal = 0;
else if ($Nominal > 255)
  $Nominal = 255;
else if ($Nominal < 0)
  $Nominal = 0;

if ($Gain == "")
  $Gain = 0;
else if ($Gain > 255)
  $Gain = 255;
else if ($Gain < 0)
  $Gain = 0;

$Body = chr($Organ) . chr($Tissue) . chr($Locus) . chr($Chemical) . chr($Threshold) . chr($Nominal) . chr($Gain) . chr($Flags);

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
