<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$ClockRate = $p_ClockRate;

if ($ClockRate == "")
  $ClockRate = 128;
else if ($ClockRate > 255)
  $ClockRate = 255;
else if ($ClockRate < 0)
  $ClockRate = 0;

$RepairRate = $p_RepairRate;

if ($RepairRate == "")
  $RepairRate = 128;
else if ($RepairRate > 255)
  $RepairRate = 255;
else if ($RepairRate < 0)
  $RepairRate = 0;

$LifeForce = $p_LifeForce;

if ($LifeForce == "")
  $LifeForce = 128;
else if ($LifeForce > 255)
  $LifeForce = 255;
else if ($LifeForce < 0)
  $LifeForce = 0;

$BioTickStart = $p_BioTickStart;

if ($BioTickStart == "")
  $BioTickStart = 128;
else if ($BioTickStart > 255)
  $BioTickStart = 255;
else if ($BioTickStart < 0)
  $BioTickStart = 0;

$ATPDamage = $p_ATPDamage;

if ($ATPDamage == "")
  $ATPDamage = 128;
else if ($ATPDamage > 255)
  $ATPDamage = 255;
else if ($ATPDamage < 0)
  $ATPDamage = 0;

$Body = chr($ClockRate) . chr($RepairRate) . chr($LifeForce) . chr($BioTickStart) . chr($ATPDamage);

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
