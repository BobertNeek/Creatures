<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$Reactant0 = $p_Reactant0;
$Quantity0 = $p_Quantity0;
$Reactant1 = $p_Reactant1;
$Quantity1 = $p_Quantity1;
$Product2 = $p_Product2;
$Quantity2 = $p_Quantity2;
$Product3 = $p_Product3;
$Quantity3 = $p_Quantity3;

$Rate = $p_Rate;

if ($Rate == "")
  $Rate = 128;
else if ($Rate > 255)
  $Rate = 255;
else if ($Rate < 0)
  $Rate = 0;

$Body = chr($Quantity0) . chr($Reactant0) . chr($Quantity1) . chr($Reactant1) . chr($Quantity2) . chr($Product2) . chr($Quantity3) . chr($Product3) . chr($Rate);

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
