<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$Rotation = $p_Rotation;

if ($Rotation == "")
  $Rotation = 128;
else if ($Rotation > 255)
  $Rotation = 255;
else if ($Rotation < 0)
  $Rotation = 0;

$Swap = $p_Swap;

if ($Swap == "")
  $Swap = 128;
else if ($Swap > 255)
  $Swap = 255;
else if ($Swap < 0)
  $Swap = 0;

$Body = chr($Rotation) . chr($Swap);

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
