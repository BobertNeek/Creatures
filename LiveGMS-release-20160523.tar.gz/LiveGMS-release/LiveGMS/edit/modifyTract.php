<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$SrcLobeId = "";
$i = 0;
while ($i < 4)
{
  if (substr($p_SrcLobeId, $i, 1) == "")
    $SrcLobeId = $SrcLobeId . "X";
  else
    $SrcLobeId = $SrcLobeId . substr($p_SrcLobeId, $i, 1);
  ++$i;
}
$DestLobeId = "";
$i = 0;
while ($i < 4)
{
  if (substr($p_DestLobeId, $i, 1) == "")
    $DestLobeId = $DestLobeId . "X";
  else
    $DestLobeId = $DestLobeId . substr($p_DestLobeId, $i, 1);
  ++$i;
}
$UpdateTime = $p_UpdateTime;
$SrcLower = $p_SrcLower;
$SrcUpper = $p_SrcUpper;
$DestLower = $p_DestLower;
$DestUpper = $p_DestUpper;
$NoSrc = $p_NoSrc;
$NoDest = $p_NoDest;
if ($p_MigrateFlag) $MigrateFlag = 255; else $MigrateFlag = 0;
if ($p_RandomNoFlag) $RandomNoFlag = 255; else $RandomNoFlag = 0;
$SrcVar = $p_SrcVar;
$DestVar = $p_DestVar;

if ($UpdateTime == "")
  $UpdateTime = 0;
else if ($UpdateTime > ((256 * 256) - 1))
  $UpdateTime = ((256 * 256) - 1);
else if ($UpdateTime < 0)
  $UpdateTime = 0;

if ($SrcLower == "")
  $SrcLower = 0;
else if ($SrcLower > ((256 * 256) - 1))
  $SrcLower = ((256 * 256) - 1);
else if ($SrcLower < 0)
  $SrcLower = 0;

if ($SrcUpper == "")
  $SrcUpper = 0;
else if ($SrcUpper > ((256 * 256) - 1))
  $SrcUpper = ((256 * 256) - 1);
else if ($SrcUpper < 0)
  $SrcUpper = 0;

if ($DestLower == "")
  $DestLower = 0;
else if ($DestLower > ((256 * 256) - 1))
  $DestLower = ((256 * 256) - 1);
else if ($DestLower < 0)
  $DestLower = 0;

if ($DestUpper == "")
  $DestUpper = 0;
else if ($DestUpper > ((256 * 256) - 1))
  $DestUpper = ((256 * 256) - 1);
else if ($DestUpper < 0)
  $DestUpper = 0;

if ($NoSrc == "")
  $NoSrc = 0;
else if ($NoSrc > ((256 * 256) - 1))
  $NoSrc = ((256 * 256) - 1);
else if ($NoSrc < 0)
  $NoSrc = 0;

if ($NoDest == "")
  $NoDest = 0;
else if ($NoDest > ((256 * 256) - 1))
  $NoDest = ((256 * 256) - 1);
else if ($NoDest < 0)
  $NoDest = 0;


$Body = chr(($UpdateTime & (255 * 256)) / 256) . chr($UpdateTime & 255) . $SrcLobeId . chr(($SrcLower & (255 * 256)) / 256) . chr($SrcLower & 255) . chr(($SrcUpper & (255 * 256)) / 256) . chr($SrcUpper & 255) . chr(($NoSrc & (255 * 256)) / 256) . chr($NoSrc & 255) . $DestLobeId . chr(($DestLower & (255 * 256)) / 256) . chr($DestLower & 255) . chr(($DestUpper & (255 * 256)) / 256) . chr($DestUpper & 255) . chr(($NoDest & (255 * 256)) / 256) . chr($NoDest & 255) . chr($MigrateFlag) . chr($RandomNoFlag) . chr($SrcVar) . chr($DestVar);

$query = "SELECT `Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
$result = mysql_query($query);
  $oldBody = $content.mysql_result($result,0,"Body");
if ($oldBody != "")
  $Body = $Body . substr($oldBody, 26, 6);
else
{
  $i = 0;
  while ($i < 6)
  {
    $Body = $Body . chr(0);
    ++$i;
  }
}

$i = 0;
while ($i < 16)
{
  eval('$Operation = $p_InitOperation' . "$i" . ';');
  eval('$Operand = $p_InitOperand' . "$i" . ';');
  eval('$Value = $p_InitValue' . "$i" . ';');
  $Body = $Body . chr($Operation) . chr($Operand) . chr($Value);
  ++$i;
}

$i = 0;
while ($i < 16)
{
  eval('$Operation = $p_UpdateOperation' . "$i" . ';');
  eval('$Operand = $p_UpdateOperand' . "$i" . ';');
  eval('$Value = $p_UpdateValue' . "$i" . ';');
  $Body = $Body . chr($Operation) . chr($Operand) . chr($Value);
  ++$i;
}

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
