<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$GaitNumber = $p_GaitNumber;

$Pose0 = $p_Pose0;
$Pose1 = $p_Pose1;
$Pose2 = $p_Pose2;
$Pose3 = $p_Pose3;
$Pose4 = $p_Pose4;
$Pose5 = $p_Pose5;
$Pose6 = $p_Pose6;
$Pose7 = $p_Pose7;

if ($Pose0 == "")
  $Pose0 = 0;
else if ($Pose0 > 255)
  $Pose0 = 255;
else if ($Pose0 < 0)
  $Pose0 = 0;

if ($Pose1 == "")
  $Pose1 = 0;
else if ($Pose1 > 255)
  $Pose1 = 255;
else if ($Pose1 < 0)
  $Pose1 = 0;

if ($Pose2 == "")
  $Pose2 = 0;
else if ($Pose2 > 255)
  $Pose2 = 255;
else if ($Pose2 < 0)
  $Pose2 = 0;

if ($Pose3 == "")
  $Pose3 = 0;
else if ($Pose3 > 255)
  $Pose3 = 255;
else if ($Pose3 < 0)
  $Pose3 = 0;

if ($Pose4 == "")
  $Pose4 = 0;
else if ($Pose4 > 255)
  $Pose4 = 255;
else if ($Pose4 < 0)
  $Pose4 = 0;

if ($Pose5 == "")
  $Pose5 = 0;
else if ($Pose5 > 255)
  $Pose5 = 255;
else if ($Pose5 < 0)
  $Pose5 = 0;

if ($Pose6 == "")
  $Pose6 = 0;
else if ($Pose6 > 255)
  $Pose6 = 255;
else if ($Pose6 < 0)
  $Pose6 = 0;

if ($Pose7 == "")
  $Pose7 = 0;
else if ($Pose7 > 255)
  $Pose7 = 255;
else if ($Pose7 < 0)
  $Pose7 = 0;

$Body = chr($GaitNumber) . chr($Pose0) . chr($Pose1) . chr($Pose2) . chr($Pose3) . chr($Pose4) . chr($Pose5) . chr($Pose6) . chr($Pose7);

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
