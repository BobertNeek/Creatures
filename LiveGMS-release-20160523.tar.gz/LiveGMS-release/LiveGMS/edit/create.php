<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$GeneType = mysql_real_escape_string(substr($p_GeneType, 0, 1));
$GeneSubType = mysql_real_escape_string(substr($p_GeneType, 1, 1));

$query="SELECT `GeneID` FROM `" . session_id() . "` WHERE 1 AND `GeneType` = '$GeneType' AND `GeneSubType` = '$GeneSubType'";
$result=mysql_query($query);
$num=mysql_numrows($result);
$GeneID = 0;
$Free = "false";
while ($Free == "false")
{
  $Free = "true";
  $i = 0;
  while ($i < $num)
  {
    $ThisID = $content.mysql_result($result,$i,"GeneID");
    if ($ThisID == $GeneID)
      $Free = "false";
    ++$i;
  }
  ++$GeneID;
}

$query = "INSERT INTO `" . session_id() . "` (`GeneType`, `GeneSubType`, `GeneID`, `Generation`, `SwitchOnTime`, `Flags`, `MutabilityWeighting`, `Variant`, `Body`) VALUES ('$GeneType', '$GeneSubType', '$GeneID', '0', '0', '7', '128', '0', '')";
mysql_query($query);

$query = "SELECT `Index` FROM `" . session_id() . "` WHERE 1 AND `Body` = ''";
$result = mysql_query($query);
$Index = $content.mysql_result($result,0,"Index");

mysql_close();
Header("Location: ../forms/modifyBodyForm.php?Index=$Index&Created=true");
?>
