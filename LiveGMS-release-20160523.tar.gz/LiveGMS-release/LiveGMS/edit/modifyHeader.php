<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$query = "SELECT `Flags` FROM `" . session_id() . "` WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
$result = mysql_query($query);
$Flags = $content.mysql_result($result,0,"Flags");
if ($p_Mutable)
  $Flags = ord(chr($Flags) | chr(1));
else
  $Flags = ord(chr($Flags) & chr(254));
if ($p_Duplicable)
  $Flags = ord(chr($Flags) | chr(2));
else
  $Flags = ord(chr($Flags) & chr(253));
if ($p_Deletable)
  $Flags = ord(chr($Flags) | chr(4));
else
  $Flags = ord(chr($Flags) & chr(251));
if ($p_Sex == "Male")
  $Flags = ord(chr($Flags) | chr(8));
else
  $Flags = ord(chr($Flags) & chr(247));
if ($p_Sex == "Female")
  $Flags = ord(chr($Flags) | chr(16));
else
  $Flags = ord(chr($Flags) & chr(239));
if ($p_NotExpressed)
  $Flags = ord(chr($Flags) | chr(32));
else
  $Flags = ord(chr($Flags) & chr(223));

if ($p_SwitchOnTime == "Baby")
  $SwitchOnTime = 0;
else if ($p_SwitchOnTime == "Child")
  $SwitchOnTime = 1;
else if ($p_SwitchOnTime == "Adolescent")
  $SwitchOnTime = 2;
else if ($p_SwitchOnTime == "Youth")
  $SwitchOnTime = 3;
else if ($p_SwitchOnTime == "Adult")
  $SwitchOnTime = 4;
else if ($p_SwitchOnTime == "Old")
  $SwitchOnTime = 5;
else if ($p_SwitchOnTime == "Senile")
  $SwitchOnTime = 6;

$Mutability = $p_Mutability;

if ($Mutability == "")
  $Mutability = 128;
else if ($Mutability > 255)
  $Mutability = 255;
else if ($Mutability < 0)
  $Mutability = 0;

$Variant = $p_Variant;

if ($Variant == "")
  $Variant = 0;
else if ($Variant > 255)
  $Variant = 255;
else if ($Variant < 0)
  $Variant = 0;

$query = "UPDATE `" . session_id() . "` SET Flags='" . mysql_real_escape_string($Flags) . "',SwitchOnTime='" . mysql_real_escape_string($SwitchOnTime) . "',MutabilityWeighting='" . mysql_real_escape_string($Mutability) . "',Variant='" . mysql_real_escape_string($Variant) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
Header("Location: ../interface/closerefresh.php");
?>
