<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$Expression = $p_Expression;
$FactorX = $p_FactorX;
$Weight = $p_Weight;
$Drive0 = $p_Drive0;
$Amount0 = $p_Amount0 + 124;
$Drive1 = $p_Drive1;
$Amount1 = $p_Amount1 + 124;
$Drive2 = $p_Drive2;
$Amount2 = $p_Amount2 + 124;
$Drive3 = $p_Drive3;
$Amount3 = $p_Amount3 + 124;

if ($Expression == "")
  $Expression = 0;
else if ($Expression > 255)
  $Expression = 255;
else if ($Expression < 0)
  $Expression = 0;

if ($Weight == "")
  $Weight = 128;
else if ($Weight > 255)
  $Weight = 255;
else if ($Weight < 0)
  $Weight = 0;

if ($Amount0 == "")
  $Amount0 = 124;
else if ($Amount0 > 255)
  $Amount0 = 255;
else if ($Amount0 < 0)
  $Amount0 = 0;

if ($Amount1 == "")
  $Amount1 = 124;
else if ($Amount1 > 255)
  $Amount1 = 255;
else if ($Amount1 < 0)
  $Amount1 = 0;

if ($Amount2 == "")
  $Amount2 = 124;
else if ($Amount2 > 255)
  $Amount2 = 255;
else if ($Amount2 < 0)
  $Amount2 = 0;

if ($Amount3 == "")
  $Amount3 = 124;
else if ($Amount3 > 255)
  $Amount3 = 255;
else if ($Amount3 < 0)
  $Amount3 = 0;

$Body = chr($Expression) . chr($FactorX) . chr($Weight) . chr($Drive0) . chr($Amount0) . chr($Drive1) . chr($Amount1) . chr($Drive2) . chr($Amount2) . chr($Drive3) . chr($Amount3);

$query = "UPDATE `" . session_id() . "` SET Body='" . mysql_real_escape_string($Body) . "' WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

mysql_close();
if ($p_Created == "true")
  Header("Location: ../forms/modifyHeaderForm.php?Index=$p_Index");
else
  Header("Location: ../interface/close.php");
?>
