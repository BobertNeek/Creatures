<?
session_start();
extract($_POST, EXTR_PREFIX_ALL, 'p');
include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");

$query = "UPDATE `" . session_id() . "` SET `Index`=0 WHERE 1 AND `Index` = '" . mysql_real_escape_string($p_Index) . "'";
mysql_query($query);

if (is_numeric($p_NewIndex) && $p_NewIndex >= 1)
{
  if ($p_NewIndex > $p_Index)
  {
    $query = "UPDATE `" . session_id() . "` SET `Index`=`Index`-1 WHERE 1 AND `Index` > '" . mysql_real_escape_string($p_Index) . "' AND `Index` <= '" . mysql_real_escape_string($p_NewIndex) . "'";
  }
  else
  {
    $query = "UPDATE `" . session_id() . "` SET `Index`=`Index`+1 WHERE 1 AND `Index` < '" . mysql_real_escape_string($p_Index) . "' AND `Index` >= '" . mysql_real_escape_string($p_NewIndex) . "'";
  }
  mysql_query($query);

  $query = "UPDATE `" . session_id() . "` SET `Index`='" . mysql_real_escape_string($p_NewIndex) . "' WHERE 1 AND `Index` = '0'";
  mysql_query($query);
  Header("Location: ../interface/closerefresh.php");
}
else
{
  echo "Invalid index.";
}

mysql_close();
?>
