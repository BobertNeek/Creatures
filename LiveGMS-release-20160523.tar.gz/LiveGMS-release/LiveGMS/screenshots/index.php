<html>
  <head>
    <title>LiveGMS screen shots</title>
  </head>
  <body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF">
  <p align="center"><a href="../index.php"><img border="0" src="../logo.jpg"></a></p>
  You can see LiveGMS (click on images for larger view)...
  <table border="0">
  <tr>
  <td>
  <a href="screenshot00big.jpg" target="_blank"><img src="screenshot00.jpg"></a>
  </td>
  <td>...editing a gene header</td>
  </tr><tr>
  <td>
  <a href="screenshot01big.jpg" target="_blank"><img src="screenshot01.jpg"></a>
  </td>
  <td>...editing an appearance gene</td>
  </tr><tr>
  <td>
  <a href="screenshot02big.jpg" target="_blank"><img src="screenshot02.jpg"></a>
  </td>
  <td>...editing a pigment and a chemical reaction gene</td>
  </tr><tr>
  <td>
  <a href="screenshot03big.jpg" target="_blank"><img src="screenshot03.jpg"></a>
  </td>
  <td>...editing a stimulus gene</td>
  </tr><tr>
  <td>
  <a href="screenshot04big.jpg" target="_blank"><img src="screenshot04.jpg"></a>
  </td>
  <td>...editing the SV rules of a brain lobe gene</td>
  </tr>
  </table>
  <p align="center"><font size="+2"><a href="../index.php">Back to main page</a></font></p>
  </body>
</html>

