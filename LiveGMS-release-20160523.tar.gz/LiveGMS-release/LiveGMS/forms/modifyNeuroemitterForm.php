<?
function neuroemitterForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");
  
  echo "<form action=\"../edit/modifyNeuroemitter.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Lobe1 (default captions):</b></td> <td><select name=\"Lobe0\">";
  echo "<option value=\"255\" "; if ($Lobe0 == 255) echo "selected"; echo ">None</option>
  <option value=\"1\" "; if ($Lobe0 == 1) echo "selected"; echo ">0</option>
  <option value=\"2\" "; if ($Lobe0 == 2) echo "selected"; echo ">1 Verb</option>
  <option value=\"3\" "; if ($Lobe0 == 3) echo "selected"; echo ">2 Noun</option>
  <option value=\"4\" "; if ($Lobe0 == 4) echo "selected"; echo ">3 Stim</option>
  <option value=\"5\" "; if ($Lobe0 == 5) echo "selected"; echo ">4</option>
  <option value=\"6\" "; if ($Lobe0 == 6) echo "selected"; echo ">5 Driv</option>
  <option value=\"7\" "; if ($Lobe0 == 7) echo "selected"; echo ">6 Situ</option>
  <option value=\"8\" "; if ($Lobe0 == 8) echo "selected"; echo ">7 Detl</option>
  <option value=\"9\" "; if ($Lobe0 == 9) echo "selected"; echo ">8</option>
  <option value=\"10\" "; if ($Lobe0 == 10) echo "selected"; echo ">9 Attn</option>
  <option value=\"11\" "; if ($Lobe0 == 11) echo "selected"; echo ">10 Decn</option>";
  $i = 12;
  while ($i < 255)
  {
    echo "<option value=\"$i\" "; if ($Lobe0 == $i) echo "selected"; echo ">" . ($i - 1) . "</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Neuron1:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Neuron0\" value=\"$Neuron0\"></td>
  </tr><tr>
  <td><b>Lobe2 (default captions):</b></td> <td><select name=\"Lobe1\">";
  echo "<option value=\"255\" "; if ($Lobe1 == 255) echo "selected"; echo ">None</option>
  <option value=\"1\" "; if ($Lobe1 == 1) echo "selected"; echo ">0</option>
  <option value=\"2\" "; if ($Lobe1 == 2) echo "selected"; echo ">1 Verb</option>
  <option value=\"3\" "; if ($Lobe1 == 3) echo "selected"; echo ">2 Noun</option>
  <option value=\"4\" "; if ($Lobe1 == 4) echo "selected"; echo ">3 Stim</option>
  <option value=\"5\" "; if ($Lobe1 == 5) echo "selected"; echo ">4</option>
  <option value=\"6\" "; if ($Lobe1 == 6) echo "selected"; echo ">5 Driv</option>
  <option value=\"7\" "; if ($Lobe1 == 7) echo "selected"; echo ">6 Situ</option>
  <option value=\"8\" "; if ($Lobe1 == 8) echo "selected"; echo ">7 Detl</option>
  <option value=\"9\" "; if ($Lobe1 == 9) echo "selected"; echo ">8</option>
  <option value=\"10\" "; if ($Lobe1 == 10) echo "selected"; echo ">9 Attn</option>
  <option value=\"11\" "; if ($Lobe1 == 11) echo "selected"; echo ">10 Decn</option>";
  $i = 12;
  while ($i < 255)
  {
    echo "<option value=\"$i\" "; if ($Lobe1 == $i) echo "selected"; echo ">" . ($i - 1) . "</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Neuron2:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Neuron1\" value=\"$Neuron1\"></td>
  </tr><tr>
  <td><b>Lobe3 (default captions):</b></td> <td><select name=\"Lobe2\">";
  echo "<option value=\"255\" "; if ($Lobe2 == 255) echo "selected"; echo ">None</option>
  <option value=\"1\" "; if ($Lobe2 == 1) echo "selected"; echo ">0</option>
  <option value=\"2\" "; if ($Lobe2 == 2) echo "selected"; echo ">1 Verb</option>
  <option value=\"3\" "; if ($Lobe2 == 3) echo "selected"; echo ">2 Noun</option>
  <option value=\"4\" "; if ($Lobe2 == 4) echo "selected"; echo ">3 Stim</option>
  <option value=\"5\" "; if ($Lobe2 == 5) echo "selected"; echo ">4</option>
  <option value=\"6\" "; if ($Lobe2 == 6) echo "selected"; echo ">5 Driv</option>
  <option value=\"7\" "; if ($Lobe2 == 7) echo "selected"; echo ">6 Situ</option>
  <option value=\"8\" "; if ($Lobe2 == 8) echo "selected"; echo ">7 Detl</option>
  <option value=\"9\" "; if ($Lobe2 == 9) echo "selected"; echo ">8</option>
  <option value=\"10\" "; if ($Lobe2 == 10) echo "selected"; echo ">9 Attn</option>
  <option value=\"11\" "; if ($Lobe2 == 11) echo "selected"; echo ">10 Decn</option>";
  $i = 12;
  while ($i < 255)
  {
    echo "<option value=\"$i\" "; if ($Lobe2 == $i) echo "selected"; echo ">" . ($i - 1) . "</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Neuron3:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Neuron2\" value=\"$Neuron2\"></td>
  </tr>
  <tr>
  <td><b>Rate:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Rate\" value=\"$Rate\"></td>
  </tr><tr>
  <td><b>Chemical1:</b></td> <td><select name=\"Chemical0\">";
  $i = 0;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\""; if ($Chemical0 == $i) echo " selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount1:</b></td> <td><input type=\"text\" name=\"Amount0\" size=\"3\" maxlength=\"3\" value=\"$Amount0\"></td>
  </tr><tr>
  <td><b>Chemical2:</b></td> <td><select name=\"Chemical1\">";
  $i = 0;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\""; if ($Chemical1 == $i) echo " selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount2:</b></td> <td><input type=\"text\" name=\"Amount1\" size=\"3\" maxlength=\"3\" value=\"$Amount1\"></td>
  </tr><tr>
  <td><b>Chemical3:</b></td> <td><select name=\"Chemical2\">";
  $i = 0;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\""; if ($Chemical2 == $i) echo " selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount3:</b></td> <td><input type=\"text\" name=\"Amount2\" size=\"3\" maxlength=\"3\" value=\"$Amount2\"></td>
  </tr><tr>
  <td><b>Chemical4:</b></td> <td><select name=\"Chemical3\">";
  $i = 0;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\""; if ($Chemical3 == $i) echo " selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount4:</b></td> <td><input type=\"text\" name=\"Amount3\" size=\"3\" maxlength=\"3\" value=\"$Amount3\"></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
