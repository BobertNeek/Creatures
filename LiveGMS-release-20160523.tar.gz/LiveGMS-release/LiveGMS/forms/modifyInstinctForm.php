<?
function instinctForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyInstinct.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Lobe1 (default captions):</b></td> <td><select name=\"Lobe0\">";
  echo "<option value=\"255\" "; if ($Lobe0 == 255) echo "selected"; echo ">None</option>
  <option value=\"0\" "; if ($Lobe0 == 0) echo "selected"; echo ">0</option>
  <option value=\"1\" "; if ($Lobe0 == 1) echo "selected"; echo ">1 Verb</option>
  <option value=\"2\" "; if ($Lobe0 == 2) echo "selected"; echo ">2 Noun</option>
  <option value=\"3\" "; if ($Lobe0 == 3) echo "selected"; echo ">3 Stim</option>
  <option value=\"4\" "; if ($Lobe0 == 4) echo "selected"; echo ">4</option>
  <option value=\"5\" "; if ($Lobe0 == 5) echo "selected"; echo ">5 Driv</option>
  <option value=\"6\" "; if ($Lobe0 == 6) echo "selected"; echo ">6 Situ</option>
  <option value=\"7\" "; if ($Lobe0 == 7) echo "selected"; echo ">7 Detl</option>
  <option value=\"8\" "; if ($Lobe0 == 8) echo "selected"; echo ">8</option>
  <option value=\"9\" "; if ($Lobe0 == 9) echo "selected"; echo ">9 Attn</option>
  <option value=\"10\" "; if ($Lobe0 == 10) echo "selected"; echo ">10 Decn</option>";
  $i = 11;
  while ($i < 255)
  {
    echo "<option value=\"$i\" "; if ($Lobe0 == $i) echo "selected"; echo ">$i</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Neuron1:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Neuron0\" value=\"$Neuron0\"></td>
  </tr><tr>
  <td><b>Lobe2 (default captions):</b></td> <td><select name=\"Lobe1\">";
  echo "<option value=\"255\" "; if ($Lobe1 == 255) echo "selected"; echo ">None</option>
  <option value=\"0\" "; if ($Lobe1 == 0) echo "selected"; echo ">0</option>
  <option value=\"1\" "; if ($Lobe1 == 1) echo "selected"; echo ">1 Verb</option>
  <option value=\"2\" "; if ($Lobe1 == 2) echo "selected"; echo ">2 Noun</option>
  <option value=\"3\" "; if ($Lobe1 == 3) echo "selected"; echo ">3 Stim</option>
  <option value=\"4\" "; if ($Lobe1 == 4) echo "selected"; echo ">4</option>
  <option value=\"5\" "; if ($Lobe1 == 5) echo "selected"; echo ">5 Driv</option>
  <option value=\"6\" "; if ($Lobe1 == 6) echo "selected"; echo ">6 Situ</option>
  <option value=\"7\" "; if ($Lobe1 == 7) echo "selected"; echo ">7 Detl</option>
  <option value=\"8\" "; if ($Lobe1 == 8) echo "selected"; echo ">8</option>
  <option value=\"9\" "; if ($Lobe1 == 9) echo "selected"; echo ">9 Attn</option>
  <option value=\"10\" "; if ($Lobe1 == 10) echo "selected"; echo ">10 Decn</option>";
  $i = 11;
  while ($i < 255)
  {
    echo "<option value=\"$i\" "; if ($Lobe1 == $i) echo "selected"; echo ">$i</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Neuron2:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Neuron1\" value=\"$Neuron1\"></td>
  </tr><tr>
  <td><b>Lobe3 (default captions):</b></td> <td><select name=\"Lobe2\">";
  echo "<option value=\"255\" "; if ($Lobe2 == 255) echo "selected"; echo ">None</option>
  <option value=\"0\" "; if ($Lobe2 == 0) echo "selected"; echo ">0</option>
  <option value=\"1\" "; if ($Lobe2 == 1) echo "selected"; echo ">1 Verb</option>
  <option value=\"2\" "; if ($Lobe2 == 2) echo "selected"; echo ">2 Noun</option>
  <option value=\"3\" "; if ($Lobe2 == 3) echo "selected"; echo ">3 Stim</option>
  <option value=\"4\" "; if ($Lobe2 == 4) echo "selected"; echo ">4</option>
  <option value=\"5\" "; if ($Lobe2 == 5) echo "selected"; echo ">5 Driv</option>
  <option value=\"6\" "; if ($Lobe2 == 6) echo "selected"; echo ">6 Situ</option>
  <option value=\"7\" "; if ($Lobe2 == 7) echo "selected"; echo ">7 Detl</option>
  <option value=\"8\" "; if ($Lobe2 == 8) echo "selected"; echo ">8</option>
  <option value=\"9\" "; if ($Lobe2 == 9) echo "selected"; echo ">9 Attn</option>
  <option value=\"10\" "; if ($Lobe2 == 10) echo "selected"; echo ">10 Decn</option>";
  $i = 11;
  while ($i < 255)
  {
    echo "<option value=\"$i\" "; if ($Lobe2 == $i) echo "selected"; echo ">$i</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Neuron3:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Neuron2\" value=\"$Neuron2\"></td>
  </tr><tr>
  <td><b>Action:</b></td> <td><select name=\"Action\">";
  $i = 0;
  while ($i < 14)
  {
    $query = "SELECT `Name` FROM `actions` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$actionName = $content.mysql_result($result2,0,"Name");
    if ($actionName == "")
      $actionName = "Error";
    echo "<option value=\"$i\" "; if ($Action == $i) echo "selected"; echo ">$actionName</option>";
    ++$i;
  }
  echo "<option value=\"14\" "; if ($Action == 14) echo "selected"; echo ">Not used</option>";
  echo "<option value=\"15\" "; if ($Action == 15) echo "selected"; echo ">Not used</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Reinforcement drive:</b></td> <td><select name=\"ReinforcementDrive\">";
  echo "<option value=\"0\" "; if ($ReinforcementDrive == 0) echo "selected"; echo ">Pain</option>";
  echo "<option value=\"1\" "; if ($ReinforcementDrive == 1) echo "selected"; echo ">Hunger for protein</option>";
  echo "<option value=\"2\" "; if ($ReinforcementDrive == 2) echo "selected"; echo ">Hunger for carbohydrate</option>";
  echo "<option value=\"3\" "; if ($ReinforcementDrive == 3) echo "selected"; echo ">Hunger for fat</option>";
  echo "<option value=\"4\" "; if ($ReinforcementDrive == 4) echo "selected"; echo ">Coldness</option>";
  echo "<option value=\"5\" "; if ($ReinforcementDrive == 5) echo "selected"; echo ">Hotness</option>";
  echo "<option value=\"6\" "; if ($ReinforcementDrive == 6) echo "selected"; echo ">Tiredness</option>";
  echo "<option value=\"7\" "; if ($ReinforcementDrive == 7) echo "selected"; echo ">Sleepiness</option>";
  echo "<option value=\"8\" "; if ($ReinforcementDrive == 8) echo "selected"; echo ">Loneliness</option>";
  echo "<option value=\"9\" "; if ($ReinforcementDrive == 9) echo "selected"; echo ">Crowdedness</option>";
  echo "<option value=\"10\" "; if ($ReinforcementDrive == 10) echo "selected"; echo ">Fear</option>";
  echo "<option value=\"11\" "; if ($ReinforcementDrive == 11) echo "selected"; echo ">Boredom</option>";
  echo "<option value=\"12\" "; if ($ReinforcementDrive == 12) echo "selected"; echo ">Anger</option>";
  echo "<option value=\"13\" "; if ($ReinforcementDrive == 13) echo "selected"; echo ">Sex Drive</option>";
  echo "<option value=\"14\" "; if ($ReinforcementDrive == 14) echo "selected"; echo ">Comfort</option>";
  echo "<option value=\"15\" "; if ($ReinforcementDrive == 15) echo "selected"; echo ">Up</option>";
  echo "<option value=\"16\" "; if ($ReinforcementDrive == 16) echo "selected"; echo ">Down</option>";
  echo "<option value=\"17\" "; if ($ReinforcementDrive == 17) echo "selected"; echo ">Exit</option>";
  echo "<option value=\"18\" "; if ($ReinforcementDrive == 18) echo "selected"; echo ">Enter</option>";
  echo "<option value=\"19\" "; if ($ReinforcementDrive == 19) echo "selected"; echo ">Wait</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Reinforcement level (-128 to 128)</b></td> <td><input type=\"text\" size=\"4\" maxlength=\"4\" name=\"ReinforcementLevel\" value=\"$ReinforcementLevel\"></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
