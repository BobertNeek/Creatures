<?
function initialconcentrationForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyInitialconcentration.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Chemical:</b></td> <td><select name=\"Chemical\">";
  $i = 1;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\" "; if ($Chemical == $i) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount:</b></td> <td><input type=\"text\" name=\"Amount\" size=\"3\" maxlength=\"3\" value=\"$Amount\"></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
