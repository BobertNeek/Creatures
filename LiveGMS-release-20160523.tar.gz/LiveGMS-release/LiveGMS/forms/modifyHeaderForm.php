<?
extract($_GET, EXTR_PREFIX_ALL, 'g');
extract($_POST, EXTR_PREFIX_ALL, 'p');

if ($g_Index != "")
  $p_Index = $g_Index;

session_start();

include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");
?>

<html>
<head>
  <title>LiveGMS - Gene <? echo "#$p_Index" ?></title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF" onLoad="window.resizeTo(600,600); window.menubar.visible = false; window.toolbar.visible = false; window.personalbar.visible = false; window.statusbar.visible = false; window.locationbar.visible = false;">
<p align="center"><img src="../logo.jpg"></p>
<hr>

<?
$query = "SELECT `SwitchOnTime`,`Variant`, `MutabilityWeighting`, `Flags`  FROM `" . session_id() . "` WHERE 1 AND `Index` = '$p_Index'";
$result = mysql_query($query);
$SwitchOnTime = $content.mysql_result($result,0,"SwitchOnTime");
$Variant = $content.mysql_result($result,0,"Variant");
$Mutability = $content.mysql_result($result,0,"MutabilityWeighting");

$Flags = $content.mysql_result($result,0,"Flags");
if ((chr($Flags) & chr(1)) == chr(1))
  $Mutable = true;
if ((chr($Flags) & chr(2)) == chr(2))
  $Duplicable = true;
if ((chr($Flags) & chr(4)) == chr(4))
  $Deletable = true;
if ((chr($Flags) & chr(8)) == chr(8))
  $MaleOnly = true;
else if ((chr($Flags) & chr(16)) == chr(16))
  $FemaleOnly = true;
if ((chr($Flags) & chr(32)) == chr(32))
  $NotExpressed = true;

echo "<form action=\"../edit/modifyHeader.php\" method=\"post\">
<table border=\"0\">
<tr>
<td><b>Flags:</b></td><td> Mutable <input type=\"checkbox\" name=\"Mutable\" "; if ($Mutable) echo "checked"; echo ">
Duplicable <input type=\"checkbox\" name=\"Duplicable\" "; if ($Duplicable) echo "checked"; echo ">
Deletable <input type=\"checkbox\" name=\"Deletable\" "; if ($Deletable) echo "checked"; echo ">
Not expressed <input type=\"checkbox\" name=\"NotExpressed\" "; if ($NotExpressed) echo "checked"; echo "></td>
</tr><tr>
<td><b>Mutability:</b></td> <td><input type=\"text\" name=\"Mutability\" size=\"3\" maxlength=\"3\" value=\"$Mutability\"></td>
</tr><tr>
<td><b>Variant:</b></td> <td><input type=\"text\" name=\"Variant\" size=\"3\" maxlength=\"3\" value=\"$Variant\"></td>
</tr><tr>
<td><b>Sex:</b></td> <td><select name=\"Sex\">
<option value=\"Both\" "; if(!($MaleOnly || $FemaleOnly)) echo "selected"; echo ">Both</option>
<option value=\"Male\" "; if($MaleOnly) echo "selected"; echo ">Male</option>
<option value=\"Female\" "; if($FemaleOnly) echo "selected"; echo ">Female</option>
</select></td>
</tr><tr>
<td><b>Switch on:</b></td> <td><select name=\"SwitchOnTime\">
<option value=\"Baby\" "; if($SwitchOnTime == 0) echo "selected"; echo ">Baby</option>
<option value=\"Child\" "; if($SwitchOnTime == 1) echo "selected"; echo ">Child</option>
<option value=\"Adolescent\" "; if($SwitchOnTime == 2) echo "selected"; echo ">Adolescent</option>
<option value=\"Youth\" "; if($SwitchOnTime == 3) echo "selected"; echo ">Youth</option>
<option value=\"Adult\" "; if($SwitchOnTime == 4) echo "selected"; echo ">Adult</option>
<option value=\"Old\" "; if($SwitchOnTime == 5) echo "selected"; echo ">Old</option>
<option value=\"Senile\" "; if($SwitchOnTime == 6) echo "selected"; echo ">Senile</option>
</select></td>
</tr>
</table>
<input type=\"hidden\" name=\"Index\" value=\""; echo $p_Index; echo"\">
<br><br><input type=\"submit\" value=\"Submit changes\">
</form>
";
?>
</body>
</html>

<?
mysql_close();
?>
