<?
extract($_POST, EXTR_PREFIX_ALL, 'p');
?>

<html>
<head>
  <title>LiveGMS - Move gene <? echo "#$p_Index" ?></title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF" onLoad="window.resizeTo(600,400); window.menubar.visible = false; window.toolbar.visible = false; window.personalbar.visible = false; window.statusbar.visible = false; window.locationbar.visible = false;">
<p align="center"><img src="../logo.jpg"></p>
<hr>
Move gene from
<?
echo $p_Index . " ";
?>
to:
<form action="../edit/move.php" method="post">
<input type="text" size="4" maxlength="4" name="NewIndex">
<?
echo "<input type=\"hidden\" name=\"Index\" value=\"" . $p_Index . "\">";
?>
<input type="submit" value="Move!">
</form>
</body>
</html>
