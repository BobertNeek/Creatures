<?
function halflivesForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyHalflives.php\" method=\"post\">
  <table border=\"0\">";
  $i = 1;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<tr><td><b>$chemName:</b></td> <td><input type=\"text\" name=\"chem_$i\" size=\"3\" maxlength=\"3\" value=\"" . ord(substr($Body, $i, 1)) . "\"></td></tr>";
    ++$i;
  }
  echo "
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
