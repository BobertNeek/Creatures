<?
function lobeForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyLobe.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Lobe quad:</b></td> <td><input type=\"text\" name=\"LobeId\" size=\"4\" maxlength=\"4\" value=\"$LobeId\"></td>
  </tr><tr>
  <td><b>Update time:</b></td> <td><input type=\"text\" name=\"UpdateTime\" size=\"5\" maxlength=\"5\" value=\"$UpdateTime\"></td>
  </tr><tr>
  <td><b>X position:</b></td> <td><input type=\"text\" name=\"X\" size=\"5\" maxlength=\"5\" value=\"$X\"></td>
  </tr><tr>
  <td><b>Y position:</b></td> <td><input type=\"text\" name=\"Y\" size=\"5\" maxlength=\"5\" value=\"$Y\"></td>
  </tr><tr>
  <td><b>Width:</b></td> <td><input type=\"text\" name=\"Width\" size=\"3\" maxlength=\"3\" value=\"$Width\"></td>
  </tr><tr>
  <td><b>Height:</b></td> <td><input type=\"text\" name=\"Height\" size=\"3\" maxlength=\"3\" value=\"$Height\"></td>
  </tr><tr>
  <td><b>Red:</b></td> <td><input type=\"text\" name=\"Red\" size=\"3\" maxlength=\"3\" value=\"$Red\"></td>
  </tr><tr>
  <td><b>Green:</b></td> <td><input type=\"text\" name=\"Green\" size=\"3\" maxlength=\"3\" value=\"$Green\"></td>
  </tr><tr>
  <td><b>Blue:</b></td> <td><input type=\"text\" name=\"Blue\" size=\"3\" maxlength=\"3\" value=\"$Blue\"></td>
  </tr><tr>
  <td><b>Tissue (default captions):</b></td> <td><select name=\"Tissue\">";
  echo "<option value=\"255\" "; if ($Tissue == 255) echo "selected"; echo ">None</option>
  <option value=\"0\" "; if ($Tissue == 0) echo "selected"; echo ">0</option>
  <option value=\"1\" "; if ($Tissue == 1) echo "selected"; echo ">1 Verb</option>
  <option value=\"2\" "; if ($Tissue == 2) echo "selected"; echo ">2 Noun</option>
  <option value=\"3\" "; if ($Tissue == 3) echo "selected"; echo ">3 Stim</option>
  <option value=\"4\" "; if ($Tissue == 4) echo "selected"; echo ">4</option>
  <option value=\"5\" "; if ($Tissue == 5) echo "selected"; echo ">5 Driv</option>
  <option value=\"6\" "; if ($Tissue == 6) echo "selected"; echo ">6 Situ</option>
  <option value=\"7\" "; if ($Tissue == 7) echo "selected"; echo ">7 Detl</option>
  <option value=\"8\" "; if ($Tissue == 8) echo "selected"; echo ">8</option>
  <option value=\"9\" "; if ($Tissue == 9) echo "selected"; echo ">9 Attn</option>
  <option value=\"10\" "; if ($Tissue == 10) echo "selected"; echo ">10 Decn</option>";
  $i = 11;
  while ($i < 255)
  {
    echo "<option value=\"$i\" "; if ($Tissue == $i) echo "selected"; echo ">$i</option>";
    ++$i;
  }
  flush();
  echo "
  </select></td>
  </tr><tr>
  <td><b>Initial SV rules:</b></td>
  <td>
  <table border=\"1\">
  <tr>
  <th>Operation</th>
  <th>Operand</th>
  <th>Value/Variable/Chemical</th>
  </tr>
  ";

  $i = 0;
  while ($i < 16)
  {
    echo "<tr>";
    $Operation = ord(substr($Body, 25 + ($i * 3), 1));
    $Operand = ord(substr($Body, 25 + ($i * 3) + 1, 1));
    $Value = ord(substr($Body, 25 + ($i * 3) + 2, 1));

    echo "<td><select name=\"InitOperation$i\">";
    $i2 = 0;
    while ($i2 < 36)
    {
      $query = "SELECT `Name` FROM `SVRules` WHERE 1 AND `Number` = $i2 AND `Type` = 'Opcodes'";
      $result2 = mysql_query($query);
      @$operationName = $content.mysql_result($result2,0,"Name");
      if ($operationName == "")
        $operationName = "Error";
      echo "<option value=\"$i2\" "; if ($Operation == $i2) echo "selected"; echo ">$operationName</option>";
      ++$i2;
    }
    echo "<option value=\"52\" "; if ($Operation == 52) echo "selected"; echo ">goto line</option>";
    echo "<option value=\"50\" "; if ($Operation == 50) echo "selected"; echo ">divide by</option>";
    echo "<option value=\"48\" "; if ($Operation == 48) echo "selected"; echo ">if zero goto</option>";
    echo "<option value=\"44\" "; if ($Operation == 44) echo "selected"; echo ">longterm relax rate</option>";
    echo "<option value=\"45\" "; if ($Operation == 45) echo "selected"; echo ">store abs in</option>";
    echo "<option value=\"43\" "; if ($Operation == 43) echo "selected"; echo ">shortterm relax rate</option>";
    echo "<option value=\"46\" "; if ($Operation == 46) echo "selected"; echo ">stop if zero</option>";
    echo "<option value=\"47\" "; if ($Operation == 47) echo "selected"; echo ">stop if nonzero</option>";
    echo "<option value=\"67\" "; if ($Operation == 67) echo "selected"; echo ">if negative</option>";
    echo "<option value=\"68\" "; if ($Operation == 68) echo "selected"; echo ">if positive</option>";
    echo "<option value=\"53\" "; if ($Operation == 53) echo "selected"; echo ">stop if &lt;</option>";
    echo "<option value=\"54\" "; if ($Operation == 54) echo "selected"; echo ">stop if &gt;</option>";
    echo "<option value=\"55\" "; if ($Operation == 55) echo "selected"; echo ">stop if &lt;=</option>";
    echo "<option value=\"56\" "; if ($Operation == 56) echo "selected"; echo ">stop if &gt;=</option>";
    echo "<option value=\"63\" "; if ($Operation == 63) echo "selected"; echo ">preserve neuron SV</option>";
    echo "<option value=\"66\" "; if ($Operation == 66) echo "selected"; echo ">restore spare neuron</option>";
    echo "</select></td>";

    echo "<td><select name=\"InitOperand$i\">";
    $i2 = 0;
    while ($i2 < 16)
    {
      $query = "SELECT `Name` FROM `SVRules` WHERE 1 AND `Number` = $i2 AND `Type` = 'Operands'";
      $result2 = mysql_query($query);
      @$operandName = $content.mysql_result($result2,0,"Name");
      if ($operandName == "")
        $operandName = "Error";
      echo "<option value=\"$i2\" "; if ($Operand == $i2) echo "selected"; echo ">$operandName</option>";
      ++$i2;
    }
    echo "</select></td>";

    echo "<td><input type=\"text\" name=\"InitValue$i\" size=\"3\" maxlength=\"3\" value=\"$Value\"></td>";

    echo "</tr>";
    ++$i;
  }
  flush();
  echo "
  </table>
  </td>
  </tr><tr>
  <td><b>Update SV rules:</b></td>
  <td>
  <table border=\"1\">
  <tr>
  <th>Operation</th>
  <th>Operand</th>
  <th>Value/Variable/Chemical</th>
  </tr>
  ";

  $i = 0;
  while ($i < 16)
  {
    echo "<tr>";
    $Operation = ord(substr($Body, 73 + ($i * 3), 1));
    $Operand = ord(substr($Body, 73 + ($i * 3) + 1, 1));
    $Value = ord(substr($Body, 73 + ($i * 3) + 2, 1));

    echo "<td><select name=\"UpdateOperation$i\">";
    $i2 = 0;
    while ($i2 < 36)
    {
      $query = "SELECT `Name` FROM `SVRules` WHERE 1 AND `Number` = $i2 AND `Type` = 'Opcodes'";
      $result2 = mysql_query($query);
      @$operationName = $content.mysql_result($result2,0,"Name");
      if ($operationName == "")
        $operationName = "Error";
      echo "<option value=\"$i2\" "; if ($Operation == $i2) echo "selected"; echo ">$operationName</option>";
      ++$i2;
    }
    echo "<option value=\"52\" "; if ($Operation == 52) echo "selected"; echo ">goto line</option>";
    echo "<option value=\"50\" "; if ($Operation == 50) echo "selected"; echo ">divide by</option>";
    echo "<option value=\"48\" "; if ($Operation == 48) echo "selected"; echo ">if zero goto</option>";
    echo "<option value=\"44\" "; if ($Operation == 44) echo "selected"; echo ">longterm relax rate</option>";
    echo "<option value=\"45\" "; if ($Operation == 45) echo "selected"; echo ">store abs in</option>";
    echo "<option value=\"43\" "; if ($Operation == 43) echo "selected"; echo ">shortterm relax rate</option>";
    echo "<option value=\"46\" "; if ($Operation == 46) echo "selected"; echo ">stop if zero</option>";
    echo "<option value=\"47\" "; if ($Operation == 47) echo "selected"; echo ">stop if nonzero</option>";
    echo "<option value=\"67\" "; if ($Operation == 67) echo "selected"; echo ">if negative</option>";
    echo "<option value=\"68\" "; if ($Operation == 68) echo "selected"; echo ">if positive</option>";
    echo "<option value=\"53\" "; if ($Operation == 53) echo "selected"; echo ">stop if &lt;</option>";
    echo "<option value=\"54\" "; if ($Operation == 54) echo "selected"; echo ">stop if &gt;</option>";
    echo "<option value=\"55\" "; if ($Operation == 55) echo "selected"; echo ">stop if &lt;=</option>";
    echo "<option value=\"56\" "; if ($Operation == 56) echo "selected"; echo ">stop if &gt;=</option>";
    echo "<option value=\"63\" "; if ($Operation == 63) echo "selected"; echo ">preserve neuron SV</option>";
    echo "<option value=\"66\" "; if ($Operation == 66) echo "selected"; echo ">restore spare neuron</option>";
    echo "</select></td>";

    echo "<td><select name=\"UpdateOperand$i\">";
    $i2 = 0;
    while ($i2 < 16)
    {
      $query = "SELECT `Name` FROM `SVRules` WHERE 1 AND `Number` = $i2 AND `Type` = 'Operands'";
      $result2 = mysql_query($query);
      @$operandName = $content.mysql_result($result2,0,"Name");
      if ($operandName == "")
        $operandName = "Error";
      echo "<option value=\"$i2\" "; if ($Operand == $i2) echo "selected"; echo ">$operandName</option>";
      ++$i2;
    }
    echo "</select></td>";

    echo "<td><input type=\"text\" name=\"UpdateValue$i\" size=\"3\" maxlength=\"3\" value=\"$Value\"></td>";

    echo "</tr>";
    ++$i;
  }
  echo "
  </table>
  </td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
