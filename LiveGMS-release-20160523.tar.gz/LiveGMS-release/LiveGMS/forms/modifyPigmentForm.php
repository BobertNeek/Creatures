<?
function pigmentForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyPigment.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Color:</b></td> <td><select name=\"Color\">
  <option value=\"Red\" "; if($Color == 0) echo "selected"; echo ">Red</option>
  <option value=\"Green\" "; if($Color == 1) echo "selected"; echo ">Green</option>
  <option value=\"Blue\" "; if($Color == 2) echo "selected"; echo ">Blue</option>
  </select></td>
  </tr><tr>
  <td><b>Amount:</b></td> <td><input type=\"text\" name=\"Amount\" size=\"3\" maxlength=\"3\" value=\"$Amount\"></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
