<?
function poseForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyPose.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Pose number:</b></td> <td><input type=\"text\" name=\"PoseNumber\" size=\"3\" maxlength=\"3\" value=\"$PoseNumber\"></td>
  </tr><tr>
  <td><b>Pose string:</b></td> <td><input type=\"text\" name=\"PoseString\" size=\"16\" maxlength=\"16\" value=\"$PoseString\"></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
