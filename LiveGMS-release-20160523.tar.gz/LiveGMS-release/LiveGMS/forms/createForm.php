<html>
<head>
  <title>LiveGMS - Create gene</title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF" onLoad="window.resizeTo(600,400); window.menubar.visible = false; window.toolbar.visible = false; window.personalbar.visible = false; window.statusbar.visible = false; window.locationbar.visible = false;">
<p align="center"><img src="../logo.jpg"></p>
<hr>

<?
echo "<form action=\"../edit/create.php\" method=\"post\">
<b>Genetype: </b>
<select name=\"GeneType\">
<option value=\"00\">Brain Lobe</option>
<option value=\"01\">Brain Organ</option>
<option value=\"02\">Brain Tract</option>
<option value=\"10\">Biochemistry Receptor</option>
<option value=\"11\">Biochemistry Emitter</option>
<option value=\"12\">Biochemistry Reaction</option>
<option value=\"13\">Biochemistry Half Lives</option>
<option value=\"14\">Biochemistry Initial Concentration</option>
<option value=\"15\">Biochemistry Neuro Emitter</option>
<option value=\"20\">Creature Stimulus</option>
<option value=\"21\">Creature Genus</option>
<option value=\"22\">Creature Appearance</option>
<option value=\"23\">Creature Pose</option>
<option value=\"24\">Creature Gait</option>
<option value=\"25\">Creature Instinct</option>
<option value=\"26\">Creature Pigment</option>
<option value=\"27\">Creature Pigment Bleed</option>
<option value=\"28\">Creature Facial Expression</option>
<option value=\"30\">Organ</option>
</select>
<br><br><input type=\"submit\" value=\"Create gene!\">
</form>
";
?>
</body>
</html>
