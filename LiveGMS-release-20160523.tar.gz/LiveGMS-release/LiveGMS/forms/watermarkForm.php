<html>
<head>
  <title>LiveGMS - Add watermark</title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF" onLoad="window.resizeTo(600,400); window.menubar.visible = false; window.toolbar.visible = false; window.personalbar.visible = false; window.statusbar.visible = false; window.locationbar.visible = false;">
<p align="center"><img src="../logo.jpg"></p>
<hr>
<form action="../edit/watermark.php" method="post">
Add this watermark: <input type="text" size="32" maxlength="32" name="Watermark">
<br><br><input type="submit" value="Add!">
</form>
</body>
</html>
