<?
function appearanceForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");
  
  echo "<form action=\"../edit/modifyAppearance.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Bodypart:</b></td> <td><select name=\"Bodypart\">
  <option value=\"0\" "; if ($Bodypart == 0) echo "selected"; echo ">Head</option>
  <option value=\"1\" "; if ($Bodypart == 1) echo "selected"; echo ">Body</option>
  <option value=\"2\" "; if ($Bodypart == 2) echo "selected"; echo ">Legs</option>
  <option value=\"3\" "; if ($Bodypart == 3) echo "selected"; echo ">Arms</option>
  <option value=\"4\" "; if ($Bodypart == 4) echo "selected"; echo ">Tale</option>
  </select>
  </td>
  </tr><tr>
  <td><b>Genus:</b></td> <td><select name=\"Genus\">
  <option value=\"0\" "; if ($Genus == 0) echo "selected"; echo ">Norn</option>
  <option value=\"1\" "; if ($Genus == 1) echo "selected"; echo ">Grendel</option>
  <option value=\"2\" "; if ($Genus == 2) echo "selected"; echo ">Ettin</option>
  <option value=\"3\" "; if ($Genus == 3) echo "selected"; echo ">Geat</option>
  </select>
  </tr><tr>
  <td><b>Variant:</b></td> <td><input name=\"Variant\" value=\"$Variant\" type=\"text\" size=\"1\" maxlength=\"1\"></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
