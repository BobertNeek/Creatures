<?
function organForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyOrgan.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Clock rate:</b></td> <td><input type=\"text\" name=\"ClockRate\" size=\"3\" maxlength=\"3\" value=\"$ClockRate\"></td>
  </tr><tr>
  <td><b>Repair rate:</b></td> <td><input type=\"text\" name=\"RepairRate\" size=\"3\" maxlength=\"3\" value=\"$RepairRate\"></td>
  </tr><tr>
  <td><b>Life force:</b></td> <td><input type=\"text\" name=\"LifeForce\" size=\"3\" maxlength=\"3\" value=\"$LifeForce\"></td>
  </tr><tr>
  <td><b>Bio tick start:</b></td> <td><input type=\"text\" name=\"BioTickStart\" size=\"3\" maxlength=\"3\" value=\"$BioTickStart\"></td>
  </tr><tr>
  <td><b>ATP damage:</b></td> <td><input type=\"text\" name=\"ATPDamage\" size=\"3\" maxlength=\"3\" value=\"$ATPDamage\"></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
