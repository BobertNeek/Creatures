<?
extract($_POST, EXTR_PREFIX_ALL, 'p');
?>

<html>
<head>
  <title>LiveGMS - Delete gene <? echo "#$p_Index" ?></title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF" onLoad="window.resizeTo(600,400); window.menubar.visible = false; window.toolbar.visible = false; window.personalbar.visible = false; window.statusbar.visible = false; window.locationbar.visible = false;">
<p align="center"><img src="../logo.jpg"></p>
<hr>
Really delete gene
<?
echo "#" . $p_Index . "?";
?>
<form action="../edit/delete.php" method="post">
<?
echo "<input type=\"hidden\" name=\"Index\" value=\"" . $p_Index . "\">";
?>
<input type="submit" value="Yes!">
</form>
</body>
</html>
