<?
function facialexpressionForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyFacialexpression.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Expression:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Expression\" value=\"$Expression\"></td>
  </tr><tr>
  <td><b>Weight:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Weight\" value=\"$Weight\"></td>
  </tr><tr>
  <td><b>Drive1:</b></td> <td><select name=\"Drive0\">";
  echo "<option value=\"255\" "; if ($Drive0 == 255) echo "selected"; echo ">None</option>";
  echo "<option value=\"0\" "; if ($Drive0 == 0) echo "selected"; echo ">Pain</option>";
  echo "<option value=\"1\" "; if ($Drive0 == 1) echo "selected"; echo ">Hunger for protein</option>";
  echo "<option value=\"2\" "; if ($Drive0 == 2) echo "selected"; echo ">Hunger for carbohydrate</option>";
  echo "<option value=\"3\" "; if ($Drive0 == 3) echo "selected"; echo ">Hunger for fat</option>";
  echo "<option value=\"4\" "; if ($Drive0 == 4) echo "selected"; echo ">Coldness</option>";
  echo "<option value=\"5\" "; if ($Drive0 == 5) echo "selected"; echo ">Hotness</option>";
  echo "<option value=\"6\" "; if ($Drive0 == 6) echo "selected"; echo ">Tiredness</option>";
  echo "<option value=\"7\" "; if ($Drive0 == 7) echo "selected"; echo ">Sleepiness</option>";
  echo "<option value=\"8\" "; if ($Drive0 == 8) echo "selected"; echo ">Loneliness</option>";
  echo "<option value=\"9\" "; if ($Drive0 == 9) echo "selected"; echo ">Crowdedness</option>";
  echo "<option value=\"10\" "; if ($Drive0 == 10) echo "selected"; echo ">Fear</option>";
  echo "<option value=\"11\" "; if ($Drive0 == 11) echo "selected"; echo ">Boredom</option>";
  echo "<option value=\"12\" "; if ($Drive0 == 12) echo "selected"; echo ">Anger</option>";
  echo "<option value=\"13\" "; if ($Drive0 == 13) echo "selected"; echo ">Sex Drive</option>";
  echo "<option value=\"14\" "; if ($Drive0 == 14) echo "selected"; echo ">Comfort</option>";
  echo "<option value=\"15\" "; if ($Drive0 == 15) echo "selected"; echo ">Up</option>";
  echo "<option value=\"16\" "; if ($Drive0 == 16) echo "selected"; echo ">Down</option>";
  echo "<option value=\"17\" "; if ($Drive0 == 17) echo "selected"; echo ">Exit</option>";
  echo "<option value=\"18\" "; if ($Drive0 == 18) echo "selected"; echo ">Enter</option>";
  echo "<option value=\"19\" "; if ($Drive0 == 19) echo "selected"; echo ">Wait</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount1 (-124 to 124)</b></td> <td><input type=\"text\" size=\"4\" maxlength=\"4\" name=\"Amount0\" value=\"$Amount0\"></td>
  </tr><tr>
  <td><b>Drive1:</b></td> <td><select name=\"Drive1\">";
  echo "<option value=\"255\" "; if ($Drive1 == 255) echo "selected"; echo ">None</option>";
  echo "<option value=\"0\" "; if ($Drive1 == 0) echo "selected"; echo ">Pain</option>";
  echo "<option value=\"1\" "; if ($Drive1 == 1) echo "selected"; echo ">Hunger for protein</option>";
  echo "<option value=\"2\" "; if ($Drive1 == 2) echo "selected"; echo ">Hunger for carbohydrate</option>";
  echo "<option value=\"3\" "; if ($Drive1 == 3) echo "selected"; echo ">Hunger for fat</option>";
  echo "<option value=\"4\" "; if ($Drive1 == 4) echo "selected"; echo ">Coldness</option>";
  echo "<option value=\"5\" "; if ($Drive1 == 5) echo "selected"; echo ">Hotness</option>";
  echo "<option value=\"6\" "; if ($Drive1 == 6) echo "selected"; echo ">Tiredness</option>";
  echo "<option value=\"7\" "; if ($Drive1 == 7) echo "selected"; echo ">Sleepiness</option>";
  echo "<option value=\"8\" "; if ($Drive1 == 8) echo "selected"; echo ">Loneliness</option>";
  echo "<option value=\"9\" "; if ($Drive1 == 9) echo "selected"; echo ">Crowdedness</option>";
  echo "<option value=\"10\" "; if ($Drive1 == 10) echo "selected"; echo ">Fear</option>";
  echo "<option value=\"11\" "; if ($Drive1 == 11) echo "selected"; echo ">Boredom</option>";
  echo "<option value=\"12\" "; if ($Drive1 == 12) echo "selected"; echo ">Anger</option>";
  echo "<option value=\"13\" "; if ($Drive1 == 13) echo "selected"; echo ">Sex Drive</option>";
  echo "<option value=\"14\" "; if ($Drive1 == 14) echo "selected"; echo ">Comfort</option>";
  echo "<option value=\"15\" "; if ($Drive1 == 15) echo "selected"; echo ">Up</option>";
  echo "<option value=\"16\" "; if ($Drive1 == 16) echo "selected"; echo ">Down</option>";
  echo "<option value=\"17\" "; if ($Drive1 == 17) echo "selected"; echo ">Exit</option>";
  echo "<option value=\"18\" "; if ($Drive1 == 18) echo "selected"; echo ">Enter</option>";
  echo "<option value=\"19\" "; if ($Drive1 == 19) echo "selected"; echo ">Wait</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount2 (-124 to 124)</b></td> <td><input type=\"text\" size=\"4\" maxlength=\"4\" name=\"Amount1\" value=\"$Amount1\"></td>
  </tr><tr>
  <td><b>Drive3:</b></td> <td><select name=\"Drive2\">";
  echo "<option value=\"255\" "; if ($Drive2 == 255) echo "selected"; echo ">None</option>";
  echo "<option value=\"0\" "; if ($Drive2 == 0) echo "selected"; echo ">Pain</option>";
  echo "<option value=\"1\" "; if ($Drive2 == 1) echo "selected"; echo ">Hunger for protein</option>";
  echo "<option value=\"2\" "; if ($Drive2 == 2) echo "selected"; echo ">Hunger for carbohydrate</option>";
  echo "<option value=\"3\" "; if ($Drive2 == 3) echo "selected"; echo ">Hunger for fat</option>";
  echo "<option value=\"4\" "; if ($Drive2 == 4) echo "selected"; echo ">Coldness</option>";
  echo "<option value=\"5\" "; if ($Drive2 == 5) echo "selected"; echo ">Hotness</option>";
  echo "<option value=\"6\" "; if ($Drive2 == 6) echo "selected"; echo ">Tiredness</option>";
  echo "<option value=\"7\" "; if ($Drive2 == 7) echo "selected"; echo ">Sleepiness</option>";
  echo "<option value=\"8\" "; if ($Drive2 == 8) echo "selected"; echo ">Loneliness</option>";
  echo "<option value=\"9\" "; if ($Drive2 == 9) echo "selected"; echo ">Crowdedness</option>";
  echo "<option value=\"10\" "; if ($Drive2 == 10) echo "selected"; echo ">Fear</option>";
  echo "<option value=\"11\" "; if ($Drive2 == 11) echo "selected"; echo ">Boredom</option>";
  echo "<option value=\"12\" "; if ($Drive2 == 12) echo "selected"; echo ">Anger</option>";
  echo "<option value=\"13\" "; if ($Drive2 == 13) echo "selected"; echo ">Sex Drive</option>";
  echo "<option value=\"14\" "; if ($Drive2 == 14) echo "selected"; echo ">Comfort</option>";
  echo "<option value=\"15\" "; if ($Drive2 == 15) echo "selected"; echo ">Up</option>";
  echo "<option value=\"16\" "; if ($Drive2 == 16) echo "selected"; echo ">Down</option>";
  echo "<option value=\"17\" "; if ($Drive2 == 17) echo "selected"; echo ">Exit</option>";
  echo "<option value=\"18\" "; if ($Drive2 == 18) echo "selected"; echo ">Enter</option>";
  echo "<option value=\"19\" "; if ($Drive2 == 19) echo "selected"; echo ">Wait</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount3 (-124 to 124)</b></td> <td><input type=\"text\" size=\"4\" maxlength=\"4\" name=\"Amount2\" value=\"$Amount2\"></td>
  </tr><tr>
  <td><b>Drive4:</b></td> <td><select name=\"Drive3\">";
  echo "<option value=\"255\" "; if ($Drive3 == 255) echo "selected"; echo ">None</option>";
  echo "<option value=\"0\" "; if ($Drive3 == 0) echo "selected"; echo ">Pain</option>";
  echo "<option value=\"1\" "; if ($Drive3 == 1) echo "selected"; echo ">Hunger for protein</option>";
  echo "<option value=\"2\" "; if ($Drive3 == 2) echo "selected"; echo ">Hunger for carbohydrate</option>";
  echo "<option value=\"3\" "; if ($Drive3 == 3) echo "selected"; echo ">Hunger for fat</option>";
  echo "<option value=\"4\" "; if ($Drive3 == 4) echo "selected"; echo ">Coldness</option>";
  echo "<option value=\"5\" "; if ($Drive3 == 5) echo "selected"; echo ">Hotness</option>";
  echo "<option value=\"6\" "; if ($Drive3 == 6) echo "selected"; echo ">Tiredness</option>";
  echo "<option value=\"7\" "; if ($Drive3 == 7) echo "selected"; echo ">Sleepiness</option>";
  echo "<option value=\"8\" "; if ($Drive3 == 8) echo "selected"; echo ">Loneliness</option>";
  echo "<option value=\"9\" "; if ($Drive3 == 9) echo "selected"; echo ">Crowdedness</option>";
  echo "<option value=\"10\" "; if ($Drive3 == 10) echo "selected"; echo ">Fear</option>";
  echo "<option value=\"11\" "; if ($Drive3 == 11) echo "selected"; echo ">Boredom</option>";
  echo "<option value=\"12\" "; if ($Drive3 == 12) echo "selected"; echo ">Anger</option>";
  echo "<option value=\"13\" "; if ($Drive3 == 13) echo "selected"; echo ">Sex Drive</option>";
  echo "<option value=\"14\" "; if ($Drive3 == 14) echo "selected"; echo ">Comfort</option>";
  echo "<option value=\"15\" "; if ($Drive3 == 15) echo "selected"; echo ">Up</option>";
  echo "<option value=\"16\" "; if ($Drive3 == 16) echo "selected"; echo ">Down</option>";
  echo "<option value=\"17\" "; if ($Drive3 == 17) echo "selected"; echo ">Exit</option>";
  echo "<option value=\"18\" "; if ($Drive3 == 18) echo "selected"; echo ">Enter</option>";
  echo "<option value=\"19\" "; if ($Drive3 == 19) echo "selected"; echo ">Wait</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount4 (-124 to 124)</b></td> <td><input type=\"text\" size=\"4\" maxlength=\"4\" name=\"Amount3\" value=\"$Amount3\"></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">
  <input type=\"hidden\" name=\"FactorX\" value=\""; echo $FactorX; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
