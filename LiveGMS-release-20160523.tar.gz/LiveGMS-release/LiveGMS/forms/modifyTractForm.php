<?
function tractForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

   echo "<form action=\"../edit/modifyTract.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Update time:</b></td> <td><input type=\"text\" name=\"UpdateTime\" size=\"5\" maxlength=\"5\" value=\"$UpdateTime\"></td>
  </tr><tr>
  <td><b>Source lobe quad:</b></td> <td><input type=\"text\" name=\"SrcLobeId\" size=\"4\" maxlength=\"4\" value=\"$SrcLobeId\"></td>
  </tr><tr>
  <td><b>Source lobe lower bound:</b></td> <td><input type=\"text\" name=\"SrcLower\" size=\"5\" maxlength=\"5\" value=\"$SrcLower\"></td>
  </tr><tr>
  <td><b>Source lobe upper bound:</b></td> <td><input type=\"text\" name=\"SrcUpper\" size=\"5\" maxlength=\"5\" value=\"$SrcUpper\"></td>
  </tr><tr>
  <td><b>Dendrites per source neuron:</b></td> <td><input type=\"text\" name=\"NoSrc\" size=\"5\" maxlength=\"5\" value=\"$NoSrc\"></td>
  </tr><tr>
  <td><b>Source NGF variable:</b></td> <td><select name=\"SrcVar\">";
  echo "<option value=\"0\" "; if ($SrcVar == 0) echo "selected"; echo ">State</option>";
  echo "<option value=\"1\" "; if ($SrcVar == 1) echo "selected"; echo ">Input</option>";
  echo "<option value=\"2\" "; if ($SrcVar == 2) echo "selected"; echo ">Output</option>";
  echo "<option value=\"3\" "; if ($SrcVar == 3) echo "selected"; echo ">Susceptibility</option>";
  echo "<option value=\"4\" "; if ($SrcVar == 4) echo "selected"; echo ">Susceptibility input</option>";
  echo "<option value=\"5\" "; if ($SrcVar == 5) echo "selected"; echo ">Var 5</option>";
  echo "<option value=\"6\" "; if ($SrcVar == 6) echo "selected"; echo ">Var 6</option>";
  echo "<option value=\"7\" "; if ($SrcVar == 7) echo "selected"; echo ">Neural growth factor</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Destination lobe quad:</b></td> <td><input type=\"text\" name=\"DestLobeId\" size=\"4\" maxlength=\"4\" value=\"$DestLobeId\"></td>
  </tr><tr>
  <td><b>Destination lobe lower bound:</b></td> <td><input type=\"text\" name=\"DestLower\" size=\"5\" maxlength=\"5\" value=\"$DestLower\"></td>
  </tr><tr>
  <td><b>Destination lobe upper bound:</b></td> <td><input type=\"text\" name=\"DestUpper\" size=\"5\" maxlength=\"5\" value=\"$DestUpper\"></td>
  </tr><tr>
  <td><b>Dendrites per destination neuron:</b></td> <td><input type=\"text\" name=\"NoDest\" size=\"5\" maxlength=\"5\" value=\"$NoDest\"></td>
  </tr><tr>
  <td><b>Destination NGF variable:</b></td> <td><select name=\"DestVar\">";
  echo "<option value=\"0\" "; if ($DestVar == 0) echo "selected"; echo ">State</option>";
  echo "<option value=\"1\" "; if ($DestVar == 1) echo "selected"; echo ">Input</option>";
  echo "<option value=\"2\" "; if ($DestVar == 2) echo "selected"; echo ">Output</option>";
  echo "<option value=\"3\" "; if ($DestVar == 3) echo "selected"; echo ">Susceptibility</option>";
  echo "<option value=\"4\" "; if ($DestVar == 4) echo "selected"; echo ">Susceptibility input</option>";
  echo "<option value=\"5\" "; if ($DestVar == 5) echo "selected"; echo ">Var 5</option>";
  echo "<option value=\"6\" "; if ($DestVar == 6) echo "selected"; echo ">Var 6</option>";
  echo "<option value=\"7\" "; if ($DestVar == 7) echo "selected"; echo ">Neural growth factor</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Dendrites migrate:</b></td> <td><input type=\"checkbox\" name=\"MigrateFlag\" "; if ($MigrateFlag == 255) echo "checked"; echo "></td>
  </tr><tr>
  <td><b>Random number of dendrites:</b></td> <td><input type=\"checkbox\" name=\"RandomNoFlag\" "; if ($RandomNoFlag == 255) echo "checked"; echo "></td>
";
  flush();
  echo "
  </tr><tr>
  <td><b>Initial SV rules:</b></td>
  <td>
  <table border=\"1\">
  <tr>
  <th>Operation</th>
  <th>Operand</th>
  <th>Value/Variable/Chemical</th>
  </tr>
  ";

  $i = 0;
  while ($i < 16)
  {
    echo "<tr>";
    $Operation = ord(substr($Body, 32 + ($i * 3), 1));
    $Operand = ord(substr($Body, 32 + ($i * 3) + 1, 1));
    $Value = ord(substr($Body, 32 + ($i * 3) + 2, 1));

    echo "<td><select name=\"InitOperation$i\">";
    $i2 = 0;
    while ($i2 < 36)
    {
      $query = "SELECT `Name` FROM `SVRules` WHERE 1 AND `Number` = $i2 AND `Type` = 'Opcodes'";
      $result2 = mysql_query($query);
      @$operationName = $content.mysql_result($result2,0,"Name");
      if ($operationName == "")
        $operationName = "Error";
      echo "<option value=\"$i2\" "; if ($Operation == $i2) echo "selected"; echo ">$operationName</option>";
      ++$i2;
    }
    echo "<option value=\"52\" "; if ($Operation == 52) echo "selected"; echo ">goto line</option>";
    echo "<option value=\"50\" "; if ($Operation == 50) echo "selected"; echo ">divide by</option>";
    echo "<option value=\"48\" "; if ($Operation == 48) echo "selected"; echo ">if zero goto</option>";
    echo "<option value=\"44\" "; if ($Operation == 44) echo "selected"; echo ">longterm relax rate</option>";
    echo "<option value=\"45\" "; if ($Operation == 45) echo "selected"; echo ">store abs in</option>";
    echo "<option value=\"43\" "; if ($Operation == 43) echo "selected"; echo ">shortterm relax rate</option>";
    echo "<option value=\"46\" "; if ($Operation == 46) echo "selected"; echo ">stop if zero</option>";
    echo "<option value=\"47\" "; if ($Operation == 47) echo "selected"; echo ">stop if nonzero</option>";
    echo "<option value=\"67\" "; if ($Operation == 67) echo "selected"; echo ">if negative</option>";
    echo "<option value=\"68\" "; if ($Operation == 68) echo "selected"; echo ">if positive</option>";
    echo "<option value=\"53\" "; if ($Operation == 53) echo "selected"; echo ">stop if &lt;</option>";
    echo "<option value=\"54\" "; if ($Operation == 54) echo "selected"; echo ">stop if &gt;</option>";
    echo "<option value=\"55\" "; if ($Operation == 55) echo "selected"; echo ">stop if &lt;=</option>";
    echo "<option value=\"56\" "; if ($Operation == 56) echo "selected"; echo ">stop if &gt;=</option>";
    echo "<option value=\"63\" "; if ($Operation == 63) echo "selected"; echo ">preserve neuron SV</option>";
    echo "<option value=\"66\" "; if ($Operation == 66) echo "selected"; echo ">restore spare neuron</option>";
    echo "</select></td>";

    echo "<td><select name=\"InitOperand$i\">";
    $i2 = 0;
    while ($i2 < 16)
    {
      $query = "SELECT `Name` FROM `SVRules` WHERE 1 AND `Number` = $i2 AND `Type` = 'Operands'";
      $result2 = mysql_query($query);
      @$operandName = $content.mysql_result($result2,0,"Name");
      if ($operandName == "")
        $operandName = "Error";
      echo "<option value=\"$i2\" "; if ($Operand == $i2) echo "selected"; echo ">$operandName</option>";
      ++$i2;
    }
    echo "</select></td>";

    echo "<td><input type=\"text\" name=\"InitValue$i\" size=\"3\" maxlength=\"3\" value=\"$Value\"></td>";

    echo "</tr>";
    ++$i;
  }
  flush();
  echo "
  </table>
  </td>
  </tr><tr>
  <td><b>Update SV rules:</b></td>
  <td>
  <table border=\"1\">
  <tr>
  <th>Operation</th>
  <th>Operand</th>
  <th>Value/Variable/Chemical</th>
  </tr>
  ";

  $i = 0;
  while ($i < 16)
  {
    echo "<tr>";
    $Operation = ord(substr($Body, 80 + ($i * 3), 1));
    $Operand = ord(substr($Body, 80 + ($i * 3) + 1, 1));
    $Value = ord(substr($Body, 80 + ($i * 3) + 2, 1));

    echo "<td><select name=\"UpdateOperation$i\">";
    $i2 = 0;
    while ($i2 < 36)
    {
      $query = "SELECT `Name` FROM `SVRules` WHERE 1 AND `Number` = $i2 AND `Type` = 'Opcodes'";
      $result2 = mysql_query($query);
      @$operationName = $content.mysql_result($result2,0,"Name");
      if ($operationName == "")
        $operationName = "Error";
      echo "<option value=\"$i2\" "; if ($Operation == $i2) echo "selected"; echo ">$operationName</option>";
      ++$i2;
    }
    echo "<option value=\"52\" "; if ($Operation == 52) echo "selected"; echo ">goto line</option>";
    echo "<option value=\"50\" "; if ($Operation == 50) echo "selected"; echo ">divide by</option>";
    echo "<option value=\"48\" "; if ($Operation == 48) echo "selected"; echo ">if zero goto</option>";
    echo "<option value=\"44\" "; if ($Operation == 44) echo "selected"; echo ">longterm relax rate</option>";
    echo "<option value=\"45\" "; if ($Operation == 45) echo "selected"; echo ">store abs in</option>";
    echo "<option value=\"43\" "; if ($Operation == 43) echo "selected"; echo ">shortterm relax rate</option>";
    echo "<option value=\"46\" "; if ($Operation == 46) echo "selected"; echo ">stop if zero</option>";
    echo "<option value=\"47\" "; if ($Operation == 47) echo "selected"; echo ">stop if nonzero</option>";
    echo "<option value=\"67\" "; if ($Operation == 67) echo "selected"; echo ">if negative</option>";
    echo "<option value=\"68\" "; if ($Operation == 68) echo "selected"; echo ">if positive</option>";
    echo "<option value=\"53\" "; if ($Operation == 53) echo "selected"; echo ">stop if &lt;</option>";
    echo "<option value=\"54\" "; if ($Operation == 54) echo "selected"; echo ">stop if &gt;</option>";
    echo "<option value=\"55\" "; if ($Operation == 55) echo "selected"; echo ">stop if &lt;=</option>";
    echo "<option value=\"56\" "; if ($Operation == 56) echo "selected"; echo ">stop if &gt;=</option>";
    echo "<option value=\"63\" "; if ($Operation == 63) echo "selected"; echo ">preserve neuron SV</option>";
    echo "<option value=\"66\" "; if ($Operation == 66) echo "selected"; echo ">restore spare neuron</option>";
    echo "</select></td>";

    echo "<td><select name=\"UpdateOperand$i\">";
    $i2 = 0;
    while ($i2 < 16)
    {
      $query = "SELECT `Name` FROM `SVRules` WHERE 1 AND `Number` = $i2 AND `Type` = 'Operands'";
      $result2 = mysql_query($query);
      @$operandName = $content.mysql_result($result2,0,"Name");
      if ($operandName == "")
        $operandName = "Error";
      echo "<option value=\"$i2\" "; if ($Operand == $i2) echo "selected"; echo ">$operandName</option>";
      ++$i2;
    }
    echo "</select></td>";

    echo "<td><input type=\"text\" name=\"UpdateValue$i\" size=\"3\" maxlength=\"3\" value=\"$Value\"></td>";

    echo "</tr>";
    ++$i;
  }
  echo "
  </table>
  </td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
