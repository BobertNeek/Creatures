<?
function emitterForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  if (($Flags & 1) == 1) $Clear = true;
  if (($Flags & 2) == 2) $Inverted = true;

  echo "<form action=\"../edit/modifyEmitter.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Organ:</b></td> <td><select name=\"Organ\">";
  echo "<option value=\"0\" "; if ($Organ == 0) echo "selected"; echo ">Brain</option>
  <option value=\"1\" "; if ($Organ == 1) echo "selected"; echo ">Creature</option>
  <option value=\"2\" "; if ($Organ == 2) echo "selected"; echo ">Current Organ</option>
  <option value=\"3\" "; if ($Organ == 3) echo "selected"; echo ">Current Reaction</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Tissue:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Tissue\" value=\"$Tissue\"></td>
  </tr><tr>
  <td><b>Locus:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Locus\" value=\"$Locus\"></td>
  </tr><tr>
  <td><b>Chemical:</b></td> <td><select name=\"Chemical\">";
  $i = 0;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\""; if ($Chemical == $i) echo " selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Threshold:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Threshold\" value=\"$Threshold\"></td>
  </tr><tr>
  <td><b>Rate:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Rate\" value=\"$Rate\"></td>
  </tr><tr>
  <td><b>Gain:</b></td> <td><input type=\"text\" size=\"3\" maxlength=\"3\" name=\"Gain\" value=\"$Gain\"></td>
  </tr><tr>
  <td><b>Clear input:</b></td> <td><input type=\"checkbox\" name=\"Clear\" "; if ($Clear) echo "checked"; echo "></td>
  </tr><tr>
  <td><b>Inverted:</b></td> <td><input type=\"checkbox\" name=\"Inverted\" "; if ($Inverted) echo "checked"; echo "></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
