<?
function stimulusForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  if (($Flags & 16) == 16) $Silent0 = true;
  if (($Flags & 32) == 32) $Silent1 = true;
  if (($Flags & 64) == 64) $Silent2 = true;
  if (($Flags & 128) == 128) $Silent3 = true;
  if (($Flags & 1) == 1) $UseSensory = true;
  if (($Flags & 4) == 4) $Asleep = true;

  echo "<form action=\"../edit/modifyStimulus.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Stimulus:</b></td> <td><select name=\"Stimulus\">";
  $i = 0;
  while ($i < 99)
  {
    $query = "SELECT `Name` FROM `Stimuli` WHERE 1 AND `Number` = " . ($i + 1);
    $result2 = mysql_query($query);
    @$stimName = $content.mysql_result($result2,0,"Name");
    if ($stimName == "")
      $stimName = "Error";
    echo "<option value=\"$i\""; if ($Stimulus == $i) echo " selected"; echo ">$stimName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Significance:</b></td> <td><input type=\"text\" name=\"Significance\" size=\"3\" maxlength=\"3\" value=\"$Significance\"></td>
  </tr><tr>
  <td><b>Reaction:</b></td> <td><select name=\"Reaction\">";
  $i = 0;
  while ($i < 14)
  {
    $query = "SELECT `Name` FROM `actions` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$actName = $content.mysql_result($result2,0,"Name");
    if ($actName == "")
      $actName = "Error";
    echo "<option value=\"$i\""; if ($Reaction == $i) echo " selected"; echo ">$actName</option>";
    ++$i;
  }
  echo "<option value=\"14\" "; if ($Reaction == 14) echo "selected"; echo ">Not used</option>";
  echo "<option value=\"15\" "; if ($Reaction == 15) echo "selected"; echo ">Not used</option>";
  echo "
  </select></td>
  </tr><tr>
  <td><b>Intensity:</b></td> <td><input type=\"text\" name=\"Intensity\" size=\"3\" maxlength=\"3\" value=\"$Intensity\"></td>
  </tr><tr>
  <td><b>Silent1:</b></td> <td><input type=\"checkbox\" name=\"Silent0\" "; if ($Silent0) echo "checked"; echo "></td>
  </tr><tr>
  <td><b>Chemical1:</b></td> <td><select name=\"Chemical0\">";
  $i = 148;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"" . ($i - 148) . "\" "; if ($Chemical0 == $i - 148) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  $i = 0;
  while ($i < 148)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"" . ($i + 148) . "\" "; if ($Chemical0 == $i + 148) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount1 (-124 to 124):</b></td> <td><input type=\"text\" name=\"Amount0\" size=\"4\" maxlength=\"4\" value=\"$Amount0\"></td>
  </tr><tr>
  <td><b>Silent2:</b></td> <td><input type=\"checkbox\" name=\"Silent1\" "; if ($Silent1) echo "checked"; echo "></td>
  </tr><tr>
  <td><b>Chemical2:</b></td> <td><select name=\"Chemical1\">";
  $i = 148;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"" . ($i - 148) . "\" "; if ($Chemical1 == $i - 148) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  $i = 0;
  while ($i < 148)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"" . ($i + 148) . "\" "; if ($Chemical1 == $i + 148) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount2 (-128 to 128):</b></td> <td><input type=\"text\" name=\"Amount1\" size=\"4\" maxlength=\"4\" value=\"$Amount1\"></td>
  </tr><tr>
  <td><b>Silent3:</b></td> <td><input type=\"checkbox\" name=\"Silent2\" "; if ($Silent2) echo "checked"; echo "></td>
  </tr><tr>
  <td><b>Chemical3:</b></td> <td><select name=\"Chemical2\">";
  $i = 148;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"" . ($i - 148) . "\" "; if ($Chemical2 == $i - 148) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  $i = 0;
  while ($i < 148)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"" . ($i + 148) . "\" "; if ($Chemical2 == $i + 148) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount3 (-124 to 124):</b></td> <td><input type=\"text\" name=\"Amount2\" size=\"4\" maxlength=\"4\" value=\"$Amount2\"></td>
  </tr><tr>
  <td><b>Silent4:</b></td> <td><input type=\"checkbox\" name=\"Silent3\" "; if ($Silent3) echo "checked"; echo "></td>
  </tr><tr>
  <td><b>Chemical4:</b></td> <td><select name=\"Chemical3\">";
  $i = 148;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"" . ($i - 148) . "\" "; if ($Chemical3 == $i - 148) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  $i = 0;
  while ($i < 148)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"" . ($i + 148) . "\" "; if ($Chemical3 == $i + 148) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Amount4 (-124 to 124):</b></td> <td><input type=\"text\" name=\"Amount3\" size=\"4\" maxlength=\"4\" value=\"$Amount3\"></td>
  </tr><tr>
  <td><b>Use sensory input:</b></td> <td><input type=\"checkbox\" name=\"UseSensory\" "; if ($UseSensory) echo "checked"; echo "></td>
  </tr><tr>
  <td><b>Detect if asleep:</b></td> <td><input type=\"checkbox\" name=\"Asleep\" "; if ($Asleep) echo "checked"; echo "></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
