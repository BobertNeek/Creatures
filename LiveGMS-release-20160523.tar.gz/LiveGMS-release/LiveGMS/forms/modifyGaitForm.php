<?
function gaitForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyGait.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Gait number:</b></td> <td><select name=\"GaitNumber\">";
  $i = 0;
  while ($i < 16)
  {
   echo "<option value=\"$i\" "; if ($GaitNumber == $i) echo "selected"; echo ">Gait $i</option>";
   ++$i;
  }
  echo "
  </select></td>
  </tr><tr>";
  $i2 = 0;
  while ($i2 < 8)
  {
    $Pose = ord(substr($Body, ($i2 + 1), 1));
    echo "<tr><td><b>Pose " . ($i2 + 1) . "</b></td> <td><input type=\"text\" name=\"Pose$i2\" size=\"3\" maxlength=\"3\" value=\"$Pose\"></td></tr>";
    ++$i2;
  }
  echo "
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
