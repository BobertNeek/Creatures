<?
function reactionForm($Index, $Created)
{
  $query = "SELECT `GeneType`,`GeneSubType`,`Body` FROM `" . session_id() . "` WHERE 1 AND `Index` = '$Index'";
  $result = mysql_query($query);
  $Body = $content.mysql_result($result,0,"Body");

  include ("loadData.php");

  echo "<form action=\"../edit/modifyReaction.php\" method=\"post\">
  <table border=\"0\">
  <tr>
  <td><b>Reactant1:</b></td> <td><select name=\"Reactant0\">";
  $i = 0;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\""; if ($Reactant0 == $i) echo " selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Reactant1 Quantity:</b></td> <td><input type=\"text\" name=\"Quantity0\" size=\"3\" maxlength=\"3\" value=\"$Quantity0\"></td>
  </tr><tr>
  <td><b>Reactant2:</b></td> <td><select name=\"Reactant1\">";
  $i = 0;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\" "; if ($Reactant1 == $i) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Reactant2 Quantity:</b></td> <td><input type=\"text\" name=\"Quantity1\" size=\"3\" maxlength=\"3\" value=\"$Quantity1\"></td>
  </tr><tr>
  <td><b>Product1:</b></td> <td><select name=\"Product2\">";
  $i = 0;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\" "; if ($Product2 == $i) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Product1 Quantity:</b></td> <td><input type=\"text\" name=\"Quantity2\" size=\"3\" maxlength=\"3\" value=\"$Quantity2\"></td>
  </tr><tr>
  <td><b>Product2:</b></td> <td><select name=\"Product3\">";
  $i = 0;
  while ($i < 256)
  {
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $i";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $i;
    echo "<option value=\"$i\" "; if ($Product3 == $i) echo "selected"; echo ">$chemName</option>";
    ++$i;
  }
  echo "
  </select></td>
  </tr><tr>
  <td><b>Product2 Quantity:</b></td> <td><input type=\"text\" name=\"Quantity3\" size=\"3\" maxlength=\"3\" value=\"$Quantity3\"></td>
  </tr><tr>
  <td><b>Rate (less=faster):</b></td> <td><input type=\"text\" name=\"Rate\" size=\"3\" maxlength=\"3\" value=\"$Rate\"></td>
  </tr>
  </table>
  <input type=\"hidden\" name=\"Index\" value=\""; echo $Index; echo"\">";
  if ($Created == "true") echo "<input type=\"hidden\" name=\"Created\" value=\"true\">"; echo "
  <br><br><input type=\"submit\" value=\"Submit changes\">
  </form>
  ";
}
?>
