<?
extract($_POST, EXTR_PREFIX_ALL, 'p');
extract($_GET, EXTR_PREFIX_ALL, 'g');

if ($g_Index != "")
  $p_Index = $g_Index;

session_start();

include ("../admin/.mysqlData.php");
mysql_connect($server,$user,$password);
@mysql_select_db($database) or die( "Unable to select database");
?>

<html>
<head>
  <title>LiveGMS - Gene <? echo "#$p_Index" ?></title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF" onLoad="window.resizeTo(600,600); window.menubar.visible = false; window.toolbar.visible = false; window.personalbar.visible = false; window.statusbar.visible = false; window.locationbar.visible = false;">
<p align="center"><img src="../logo.jpg"></p>
<hr>

<?
$query = "SELECT `GeneType`,`GeneSubType`  FROM `" . session_id() . "` WHERE 1 AND `Index` = '$p_Index'";
$result = mysql_query($query);
$GeneType = $content.mysql_result($result,0,"GeneType");
$GeneSubType = $content.mysql_result($result,0,"GeneSubType");

$p_Index = mysql_real_escape_string($p_Index);
if (($GeneType == "0") && ($GeneSubType == "0"))
{
  include("modifyLobeForm.php");
  lobeForm($p_Index, $g_Created);
}
else if (($GeneType == "0") && ($GeneSubType == "1")) #Gene Brain Organ is identical with Organ
{
  include("modifyOrganForm.php");
  organForm($p_Index, $g_Created);
}
else if (($GeneType == "0") && ($GeneSubType == "2"))
{
  include("modifyTractForm.php");
  tractForm($p_Index, $g_Created);
}
else if (($GeneType == "1") && ($GeneSubType == "0"))
{
  include("modifyReceptorForm.php");
  receptorForm($p_Index, $g_Created);
}
else if (($GeneType == "1") && ($GeneSubType == "1"))
{
  include("modifyEmitterForm.php");
  emitterForm($p_Index, $g_Created);
}
else if (($GeneType == "1") && ($GeneSubType == "2"))
{
  include("modifyReactionForm.php");
  reactionForm($p_Index, $g_Created);
}
else if (($GeneType == "1") && ($GeneSubType == "3"))
{
  include("modifyHalflivesForm.php");
  halflivesForm($p_Index, $g_Created);
}
else if (($GeneType == "1") && ($GeneSubType == "4"))
{
  include("modifyInitialconcentrationForm.php");
  initialconcentrationForm($p_Index, $g_Created);
}
else if (($GeneType == "1") && ($GeneSubType == "5"))
{
  include("modifyNeuroemitterForm.php");
  neuroemitterForm($p_Index, $g_Created);
}
else if (($GeneType == "2") && ($GeneSubType == "0"))
{
  include("modifyStimulusForm.php");
  stimulusForm($p_Index, $g_Created);
}
else if (($GeneType == "2") && ($GeneSubType == "1"))
{
  include("modifyGenusForm.php");
  genusForm($p_Index, $g_Created);
}
else if (($GeneType == "2") && ($GeneSubType == "2"))
{
  include("modifyAppearanceForm.php");
  appearanceForm($p_Index, $g_Created);
}
else if (($GeneType == "2") && ($GeneSubType == "3"))
{
  include("modifyPoseForm.php");
  poseForm($p_Index, $g_Created);
}
else if (($GeneType == "2") && ($GeneSubType == "4"))
{
  include("modifyGaitForm.php");
  gaitForm($p_Index, $g_Created);
}
else if (($GeneType == "2") && ($GeneSubType == "5"))
{
  include("modifyInstinctForm.php");
  instinctForm($p_Index, $g_Created);
}
else if (($GeneType == "2") && ($GeneSubType == "6"))
{
  include("modifyPigmentForm.php");
  pigmentForm($p_Index, $g_Created);
}
else if (($GeneType == "2") && ($GeneSubType == "7"))
{
  include("modifyPigmentBleedForm.php");
  pigmentBleedForm($p_Index, $g_Created);
}
else if (($GeneType == "2") && ($GeneSubType == "8"))
{
  include("modifyFacialexpressionForm.php");
  facialExpressionForm($p_Index, $g_Created);
}
else if (($GeneType == "3") && ($GeneSubType == "0"))
{
  include("modifyOrganForm.php");
  organForm($p_Index, $g_Created);
}
else
  echo "An error has ocured. If you tried to create a gene, please delete the created gene before saving the genome or creating another one.";

?>

</body>
</html>

<?
mysql_close();
?>
