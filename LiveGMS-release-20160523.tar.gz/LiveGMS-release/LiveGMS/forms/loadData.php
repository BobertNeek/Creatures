<?
  $Description = "";
  $geneType = mysql_result($result,0,"GeneType");
  $geneSubType = mysql_result($result,0,"GeneSubType");
  if (($geneType == 0) && ($geneSubType == 0))
  {
    $LobeId = substr($Body, 0, 4);
    $UpdateTime = ord(substr($Body, 5, 1)) + (ord(substr($Body, 4, 1)) * 256);
    $X = ord(substr($Body, 7, 1)) + (ord(substr($Body, 6, 1)) * 256);
    $Y = ord(substr($Body, 9, 1)) + (ord(substr($Body, 8, 1)) * 256);
    $Width = ord(substr($Body, 10, 1));
    $Height = ord(substr($Body, 11, 1));
    $Red = ord(substr($Body, 12, 1));
    $Green = ord(substr($Body, 13, 1));
    $Blue = ord(substr($Body, 14, 1));
    $Tissue = ord(substr($Body, 16, 1));
    
    $Description = $LobeId . " " . $Width . "x" . $Height;
  }
  else if ((($geneType == 0) && ($geneSubType == 1)) || (($geneType == 3) && ($geneSubType == 0)))
  {
    $ClockRate = ord(substr($Body, 0, 1));
    $RepairRate = ord(substr($Body, 1, 1));
    $LifeForce = ord(substr($Body, 2, 1));
    $BioTickStart = ord(substr($Body, 3, 1));
    $ATPDamage = ord(substr($Body, 4, 1));
    
    $Description = $ClockRate;
  }
  else if (($geneType == 0) && ($geneSubType == 2))
  {
    $UpdateTime = ord(substr($Body, 1, 1)) + (ord(substr($Body, 0, 1)) * 256);
    $SrcLobeId = substr($Body, 2, 4);
    $SrcLower = ord(substr($Body, 7, 1)) + (ord(substr($Body, 6, 1)) * 256);
    $SrcUpper = ord(substr($Body, 9, 1)) + (ord(substr($Body, 8, 1)) * 256);
    $NoSrc = ord(substr($Body, 11, 1)) + (ord(substr($Body, 10, 1)) * 256);
    $DestLobeId = substr($Body, 12, 4);
    $DestLower = ord(substr($Body, 17, 1)) + (ord(substr($Body, 16, 1)) * 256);
    $DestUpper = ord(substr($Body, 19, 1)) + (ord(substr($Body, 18, 1)) * 256);
    $NoDest = ord(substr($Body, 21, 1)) + (ord(substr($Body, 20, 1)) * 256);
    $MigrateFlag = ord(substr($Body, 22, 1));
    $RandomNoFlag = ord(substr($Body, 23, 1));
    $SrcVar = ord(substr($Body, 24, 1));
    $DestVar = ord(substr($Body, 25, 1));
    
    $Description = $SrcLobeId . " -> " . $DestLobeId;
  }
  else if (($geneType == 1) && ($geneSubType == 0))
  {
    $Organ = ord(substr($Body, 0, 1));
    $Tissue = ord(substr($Body, 1, 1));
    $Locus = ord(substr($Body, 2, 1));
    $Chemical = ord(substr($Body, 3, 1));
    $Threshold = ord(substr($Body, 4, 1));
    $Nominal = ord(substr($Body, 5, 1));
    $Gain = ord(substr($Body, 6, 1));
    $Flags = ord(substr($Body, 7, 1));
    
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $Chemical";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $Chemical;
    $Description = $chemName;
  }
  else if (($geneType == 1) && ($geneSubType == 1))
  {
    $Organ = ord(substr($Body, 0, 1));
    $Tissue = ord(substr($Body, 1, 1));
    $Locus = ord(substr($Body, 2, 1));
    $Chemical = ord(substr($Body, 3, 1));
    $Threshold = ord(substr($Body, 4, 1));
    $Rate = ord(substr($Body, 5, 1));
    $Gain = ord(substr($Body, 6, 1));
    $Flags = ord(substr($Body, 7, 1));
    
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $Chemical";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $Chemical;
    $Description = $chemName;
  }
  else if (($geneType == 1) && ($geneSubType == 2))
  {
    $Reactant0 = ord(substr($Body, 1, 1));
    $Quantity0 = ord(substr($Body, 0, 1));
    $Reactant1 = ord(substr($Body, 3, 1));
    $Quantity1 = ord(substr($Body, 2, 1));
    $Product2 = ord(substr($Body, 5, 1));
    $Quantity2 = ord(substr($Body, 4, 1));
    $Product3 = ord(substr($Body, 7, 1));
    $Quantity3 = ord(substr($Body, 6, 1));
    $Rate = ord(substr($Body, 8, 1));
    
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $Reactant0";
    $result2 = mysql_query($query);
    @$chemName0 = $content.mysql_result($result2,0,"Name");
    if ($chemName0 == "")
      $chemName0 = $Reactant0;
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $Reactant1";
    $result2 = mysql_query($query);
    @$chemName1 = $content.mysql_result($result2,0,"Name");
    if ($chemName1 == "")
      $chemName1 = $Reactant1;
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $Product2";
    $result2 = mysql_query($query);
    @$chemName2 = $content.mysql_result($result2,0,"Name");
    if ($chemName2 == "")
      $chemName2 = $Product2;
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $Product3";
    $result2 = mysql_query($query);
    @$chemName3 = $content.mysql_result($result2,0,"Name");
    if ($chemName3 == "")
      $chemName3 = $Product3;
    if (($chemName0 != "None") && ($Quantity0 > 0)) $Description = $Quantity0 . " " . $chemName0;
    if (($chemName1 != "None") && ($Quantity1 > 0)) $Description = $Description . " + " . $Quantity1 . " " . $chemName1;
    $Description = $Description . " -> ";
    if (($chemName2 != "None") && ($Quantity2 > 0)) $Description = $Description . $Quantity2 . " " . $chemName2;
    if (($chemName3 != "None") && ($Quantity3 > 0)) $Description = $Description . " + " . $Quantity3 . " " . $chemName3;
  }
  else if (($geneType == 1) && ($geneSubType == 3))
  {
    //echo "Chemical half lives are not loaded with this module.";
    $Description = "-";
  }
  else if (($geneType == 1) && ($geneSubType == 4))
  {
    $Chemical = ord(substr($Body, 0, 1));
    $Amount = ord(substr($Body, 1, 1));
    
    $query = "SELECT `Name` FROM `chemicalNames` WHERE 1 AND `Number` = $Chemical";
    $result2 = mysql_query($query);
    @$chemName = $content.mysql_result($result2,0,"Name");
    if ($chemName == "")
      $chemName = $Chemical;
    $Description = $Amount . " " . $chemName;
  }
  else if (($geneType == 1) && ($geneSubType == 5))
  {
    $Lobe0 = ord(substr($Body, 0, 1));
    $Neuron0 = ord(substr($Body, 1, 1));
    $Lobe1 = ord(substr($Body, 2, 1));
    $Neuron1 = ord(substr($Body, 3, 1));
    $Lobe2 = ord(substr($Body, 4, 1));
    $Neuron2 = ord(substr($Body, 5, 1));
    $Rate = ord(substr($Body, 6, 1));
    $Chemical0 = ord(substr($Body, 7, 1));
    $Amount0 = ord(substr($Body, 8, 1));
    $Chemical1 = ord(substr($Body, 9, 1));
    $Amount1 = ord(substr($Body, 10, 1));
    $Chemical2 = ord(substr($Body, 11, 1));
    $Amount2 = ord(substr($Body, 12, 1));
    $Chemical3 = ord(substr($Body, 13, 1));
    $Amount3 = ord(substr($Body, 14, 1));
    
    $Description = "-";
  }
  else if (($geneType == 2) && ($geneSubType == 0))
  {
    $Stimulus = ord(substr($Body, 0, 1));
    $Significance = ord(substr($Body, 1, 1));
    $Reaction = ord(substr($Body, 2, 1));
    $Intensity = ord(substr($Body, 3, 1));
    $Amount0 = ord(substr($Body, 6, 1)) - 124;
    $Chemical0 = ord(substr($Body, 5, 1));
    $Amount1 = ord(substr($Body, 8, 1)) - 124;
    $Chemical1 = ord(substr($Body, 7, 1));
    $Amount2 = ord(substr($Body, 10, 1)) - 124;
    $Chemical2 = ord(substr($Body, 9, 1));
    $Amount3 = ord(substr($Body, 12, 1)) - 124;
    $Chemical3 = ord(substr($Body, 11, 1));
    $Flags = ord(substr($Body, 4, 1));
    
    $query = "SELECT `Name` FROM `Stimuli` WHERE 1 AND `Number` = " . ($Stimulus + 1);
    $result2 = mysql_query($query);
    @$stimName = $content.mysql_result($result2,0,"Name");
    if ($stimName == "")
      $stimName = "Error";      
    $Description = $stimName;
  }  
  else if (($geneType == 2) && ($geneSubType == 1))
  {
    $Genus = ord(substr($Body, 0, 1));
    
    if ($Genus == 0) $Description = "Norn";
    else if ($Genus == 1) $Description = "Grendel";
    else if ($Genus == 2) $Description = "Ettin";
    else if ($Genus == 3) $Description = "Geat";
  }
  else if (($geneType == 2) && ($geneSubType == 2))
  {
    $Bodypart = ord(substr($Body, 0, 1));
    $Variant = chr(ord(substr($Body, 1, 1)) + 97);
    $Genus = ord(substr($Body, 2, 1));
    
    if ($Bodypart == 0) $Description = "Head";
    else if ($Bodypart == 1) $Description = "Body";
    else if ($Bodypart == 2) $Description = "Legs";
    else if ($Bodypart == 3) $Description = "Arms";
    else if ($Bodypart == 4) $Description = "Tail";
  }
  else if (($geneType == 2) && ($geneSubType == 3))
  {
    $PoseNumber = ord(substr($Body, 0, 1));
    $PoseString = substr($Body, 1, 16);
    
    $Description = $PoseNumber;
  }
  else if (($geneType == 2) && ($geneSubType == 4))
  {
    $GaitNumber = ord(substr($Body, 0, 1));
    
    $Description = $GaitNumber;
  }
  else if (($geneType == 2) && ($geneSubType == 5))
  {
    $Lobe0 = ord(substr($Body, 0, 1));
    $Neuron0 = ord(substr($Body, 1, 1));
    $Lobe1 = ord(substr($Body, 2, 1));
    $Neuron1 = ord(substr($Body, 3, 1));
    $Lobe2 = ord(substr($Body, 4, 1));
    $Neuron2 = ord(substr($Body, 5, 1));
    $Action = ord(substr($Body, 6, 1));
    $ReinforcementDrive = ord(substr($Body, 7, 1));
    $ReinforcementLevel = ord(substr($Body, 8, 1)) - 128;
    
    $query = "SELECT `Name` FROM `actions` WHERE 1 AND `Number` = $Action";
    $result2 = mysql_query($query);
    @$actionName = $content.mysql_result($result2,0,"Name");
    if ($actionName == "")
      $actionName = "Error";
    $Description = $actionName;
  }
  else if (($geneType == 2) && ($geneSubType == 6))
  {
    $Color = ord(substr($Body, 0, 1));
    $Amount = ord(substr($Body, 1, 1));
    
    if($Color == 0) $Description = $Amount . " Red";
    else if($Color == 1) $Description = $Amount . " Green";
    else if($Color == 2) $Description = $Amount . " Blue";
    else $Description = $Amount . " INVALID";
  }
  else if (($geneType == 2) && ($geneSubType == 7))
  {
    $Rotation = ord(substr($Body, 0, 1));
    $Swap = ord(substr($Body, 1, 1));
    
    $Description = $Rotation . ", " . $Swap;
  }
  else if (($geneType == 2) && ($geneSubType == 8))
  {
    $Expression = ord(substr($Body, 0, 1));
    $FactorX = ord(substr($Body, 1, 1));
    $Weight = ord(substr($Body, 2, 1));
    $Drive0 = ord(substr($Body, 3, 1));
    $Amount0 = ord(substr($Body, 4, 1)) - 124;
    $Drive1 = ord(substr($Body, 5, 1));
    $Amount1 = ord(substr($Body, 6, 1)) - 124;
    $Drive2 = ord(substr($Body, 7, 1));
    $Amount2 = ord(substr($Body, 8, 1)) - 124;
    $Drive3 = ord(substr($Body, 9, 1));
    $Amount3 = ord(substr($Body, 10, 1)) - 124;
    
    $Description = $Expression;
  }
  else
    echo "Wrong gene type supplied.";
?>
