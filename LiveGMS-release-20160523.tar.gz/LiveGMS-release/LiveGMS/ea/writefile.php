<?
  function writeGeneFile ($fileName, $dbTable)
  {
    $outFile = fopen($fileName, "w");
    fwrite ($outFile, "dna3");

    $query="SELECT * FROM `$dbTable` ORDER BY `Index` ASC";
    $result=mysql_query($query);
    $num=mysql_numrows($result);
    $i=0;
    while ($i<$num)
    {
      fwrite ($outFile, "gene" . chr($content.mysql_result($result,$i,"GeneType")) . chr($content.mysql_result($result,$i,"GeneSubType")) . chr($content.mysql_result($result,$i,"GeneID")) . chr($content.mysql_result($result,$i,"Generation")) . chr($content.mysql_result($result,$i,"SwitchOnTime")) . chr($content.mysql_result($result,$i,"Flags")) . chr($content.mysql_result($result,$i,"MutabilityWeighting")) . chr($content.mysql_result($result,$i,"Variant")) . $content.mysql_result($result,$i,"Body"));
      ++$i;
    }

    fwrite ($outFile, "gend");
    fclose($outFile);
  }
?>
