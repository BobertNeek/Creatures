<?
  function readGeneFile ($fileName, $dbTable)
  {
    #Security is important here!
    if ($fileName == "")
    {
      echo "Please select a file using the \"Browse\" button.<br>";
      return -1;
    }
    $failures = 0;
    $content = file_get_contents($fileName);
    $length = strlen($content);
    if (4 < $length)
    {
      if (substr($content, 0, 4) != "dna3")
      {
        echo "This does not seem to be a Creatures 3 genetics file. :-(<br>";
	return -1;
      }
    }
    $i = 0;
    #echo "Size: $length ";
    while ($i < $length)
    {
      if (($i + 6) < $length)
      {
        if (substr($content, $i, 4) == "gene")
	{
	  $geneLength = 0;
	  if (substr($content, $i + 4, 2) == chr(00) . chr(00))
	  {
	    #echo "Brain lobe! ";
	    $geneLength = 121;
	    $geneType = 0;
	    $geneSubType = 0;
	  }
	  else if (substr($content, $i + 4, 2) == chr(00) . chr(01))
	  {
	    #echo "Brain organ! ";
	    $geneLength = 5;
	    $geneType = 0;
	    $geneSubType = 1;
	  }
	  else if (substr($content, $i + 4, 2) == chr(00) . chr(02))
	  {
	    #echo "Brain tract! ";
	    $geneLength = 128;
	    $geneType = 0;
	    $geneSubType = 2;
	  }
	  else if (substr($content, $i + 4, 2) == chr(01) . chr(00))
	  {
	    #echo "Biochemical Receptor! ";
	    $geneLength = 8;
	    $geneType = 1;
	    $geneSubType = 0;
	  }
	  else if (substr($content, $i + 4, 2) == chr(01) . chr(01))
	  {
	    #echo "Biochemical Emitter! ";
	    $geneLength = 8;
	    $geneType = 1;
	    $geneSubType = 1;
	  }
          else if (substr($content, $i + 4, 2) == chr(01) . chr(02))
	  {
	    #echo "Biochemical Reaction! ";
	    $geneLength = 9;
	    $geneType = 1;
	    $geneSubType = 2;
	  }
	  else if (substr($content, $i + 4, 2) == chr(01) . chr(03))
	  {
	    #echo "Biochemical Half Lives! ";
	    $geneLength = 256;
	    $geneType = 1;
	    $geneSubType = 3;
	  }
	  else if (substr($content, $i + 4, 2) == chr(01) . chr(04))
	  {
	    #echo "Biochemical Initial Concentration! ";
	    $geneLength = 2;
	    $geneType = 1;
	    $geneSubType = 4;
	  }
	  else if (substr($content, $i + 4, 2) == chr(01) . chr(05))
	  {
	    #echo "Biochemical Neuro Emitter! ";
	    $geneLength = 15;
	    $geneType = 1;
	    $geneSubType = 5;
	  }
	  else if (substr($content, $i + 4, 2) == chr(02) . chr(00))
	  {
	    #echo "Creature Stimulus! ";
	    $geneLength = 13;
	    $geneType = 2;
	    $geneSubType = 0;
	  }
	  else if (substr($content, $i + 4, 2) == chr(02) . chr(01))
	  {
	    #echo "Creature Genus! ";
	    $geneLength = 65;
	    $geneType = 2;
	    $geneSubType = 1;
	  }
	  else if (substr($content, $i + 4, 2) == chr(02) . chr(02))
	  {
	    #echo "Creature Appearance! ";
	    $geneLength = 3;
	    $geneType = 2;
	    $geneSubType = 2;
	  }
	  else if (substr($content, $i + 4, 2) == chr(02) . chr(03))
	  {
	    #echo "Creature Pose! ";
	    $geneLength = 17;
	    $geneType = 2;
	    $geneSubType = 3;
	  }
	  else if (substr($content, $i + 4, 2) == chr(02) . chr(04))
	  {
	    #echo "Creature Gait! ";
	    $geneLength = 9;
	    $geneType = 2;
	    $geneSubType = 4;
	  }
	  else if (substr($content, $i + 4, 2) == chr(02) . chr(05))
	  {
	    #echo "Creature Instinct! ";
	    $geneLength = 9;
	    $geneType = 2;
	    $geneSubType = 5;
	  }
	  else if (substr($content, $i + 4, 2) == chr(02) . chr(06))
	  {
	    #echo "Creature Pigment! ";
	    $geneLength = 2;
	    $geneType = 2;
	    $geneSubType = 6;
	  }
	  else if (substr($content, $i + 4, 2) == chr(02) . chr(07))
	  {
	    #echo "Creature Pigment Bleed! ";
	    $geneLength = 2;
	    $geneType = 2;
	    $geneSubType = 7;
	  }
	  else if (ord(substr($content, $i + 4, 1)) == 2 & ord(substr($content, $i + 5, 1)) == 8)
	  {
	    #echo "Creature Facial Expression! ";
	    $geneLength = 11;
	    $geneType = 2;
	    $geneSubType = 8;
	  }

	  else if (substr($content, $i + 4, 2) == chr(03) . chr(00))
	  {
	    #echo "Organ! ";
	    $geneLength = 5;
	    $geneType = 3;
	    $geneSubType = 0;
	  }
	  else
	  {
	    ++$failures;
	  }

	  if ($geneLength > 0)
	  {
	  if (($i + 4 + 8 + $geneLength) < $length)
	  {
	    $SwitchOnTime = ord(substr($content, $i + 8, 1));
	    if ($SwitchOnTime > 6)
	    {
	      ++$failures;
	      $SwitchOnTime = 0;
	    }
	    $query="INSERT INTO `$dbTable` (`GeneType`, `GeneSubType`, `GeneID`, `Generation`, `SwitchOnTime`, `Flags`, `MutabilityWeighting`, `Variant`, `Body`) VALUES ('$geneType', '$geneSubType', '" . ord(substr($content, $i + 6, 1)) . "', '" . ord(substr($content, $i + 7, 1)) . "', '" . $SwitchOnTime . "', '" . ord(substr($content, $i + 9, 1)) . "', '" . ord(substr($content, $i + 10, 1)) . "', '" . ord(substr($content, $i + 11, 1)) . "', '" . mysql_real_escape_string(substr($content, $i + 12, $geneLength)) . "');";
            $result=mysql_query($query);
	  }
	  else
	  {
	    ++$failures;
	  }
	  }
	}
      }
      ++$i;
    }
    return $failures;
  }
?>
