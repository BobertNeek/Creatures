<?
session_start();
?>
<html>
<head>
  <title>LiveGMS</title>
</head>
<body bgcolor="black" text="#CCCCCC" link="#9999FF" alink="#FFFFFF" vlink="#9999FF">
<p align="center"><img src="../logo.jpg"></p>
<hr>
<?
  #echo $_REQUEST['username'];
  extract($_POST, EXTR_PREFIX_ALL, 'p');
  include ("readfile.php");
  include ("writefile.php");
  include ("../admin/.mysqlData.php");
  mysql_connect($server,$user,$password);
  @mysql_select_db($database) or die( "Unable to select database");
  if ($p_action == "readfile")
  {
    echo "Reading genome... Please wait<br>";
    flush();
    $query="DROP TABLE `" . session_id() . "`;";
    mysql_query($query);
    $query="CREATE TABLE `" . session_id() . "` (`Index` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `GeneType` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `GeneSubType` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `GeneID` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Generation` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `SwitchOnTime` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Flags` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `MutabilityWeighting` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Variant` TINYINT UNSIGNED DEFAULT '0' NOT NULL, `Body` BLOB NOT NULL, INDEX (`Index`));";
    mysql_query($query);
    $errors = readGeneFile($_FILES['geneFile']['tmp_name'], session_id());
    if ($errors == -1)
      echo "Genome could not be loaded.";
    else
      echo "Genome loaded. $errors genes have been skipped or corrected because of errors.";
  }
  else if ($p_action == "writefile")
  {
    echo "Writing genome... Please wait<br>";
    flush();
    $ssid = session_id();
    if (!file_exists(getcwd() . "/../tmp/$ssid"))
    {
      mkdir (getcwd() . "/../tmp/$ssid");
    }
    $geneFile = $ssid . "/livegms.gen";
    writeGeneFile(getcwd() . "/../tmp/" . $geneFile, session_id());
    echo "Genome saved. Download the genome <a href=\"../tmp/$geneFile\">here</a>.";
  }
  else
  {
    echo "Sorry, incorrect page call. :-(";
  }
  mysql_close();
?>
<hr>
<a href="../interface.php"><b>Back to main screen</b></a>
</body>
</html>
